"""Trusted Linux container execution and explicit local diagnostics.

Production agents have no network, only an authenticated Unix socket mount.
Prediction workers have neither that socket nor the private simulator.  Host
paths/image IDs/resource limits are organizer configuration, never manifest
arguments. Docker command construction is testable without a Docker daemon;
actual GPU/permission deployment must still be checked on the target Linux host.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from uuid import uuid4

PRIVATE = Path(__file__).resolve().parent
PUBLIC = Path(os.environ.get('RIFT_PUBLIC_ROOT', PRIVATE.parent/'DiscoverPhysics')).resolve()
PUBLIC_RUNTIME_FILES=('rift/__init__.py','rift/law.py','rift/prediction.py',
    'rift/observations.py','rift/worker.py','rift/console.py','rift/submission.py',
    'rift_numerics/__init__.py','rift_numerics/rollout.py',
    'rift/model_registry.py','rift/model_catalog.json','rift/strategy.py',
    'scripts/__init__.py','scripts/validate_claims.py','scripts/run_strategy.py')
sys.path.insert(0, str(PUBLIC))
from law_program_evaluation import (InfrastructureError, CandidateExecutionError,
                                    OrganizerConfigurationError, run_law_file)


def _positive(value, name):
    if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value) or value <= 0:
        raise OrganizerConfigurationError(f'{name} must be explicitly positive')
    return value


def immutable_image(value):
    if (not isinstance(value,str) or not value.startswith('sha256:') or len(value)!=71
            or any(c not in '0123456789abcdef' for c in value[7:])):
        raise OrganizerConfigurationError('Resolve the official image to its sha256 image ID first')
    return value


def public_runtime_digest():
    inventory=[{'path':name,'sha256':hashlib.sha256((PUBLIC/name).read_bytes()).hexdigest()}
               for name in PUBLIC_RUNTIME_FILES]
    return hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def stage_public_runtime(destination):
    """Allowlisted SDK only. No repository root, docs, truth or user memory."""
    target = Path(destination).resolve()
    files = {'rift':('__init__.py','law.py','prediction.py','observations.py',
                     'worker.py','console.py','submission.py','model_registry.py','model_catalog.json','strategy.py'),
             'rift_numerics':('__init__.py','rollout.py'),
             'scripts':('__init__.py','validate_claims.py','run_strategy.py')}
    allowed={f'{package}/{name}' for package,names in files.items() for name in names}
    if target.exists():
        for existing in target.rglob('*'):
            if existing.is_symlink() or (existing.is_file() and existing.relative_to(target).as_posix() not in allowed):
                raise OrganizerConfigurationError('SDK staging directory contains unexpected files; use a clean destination')
    for package,names in files.items():
        (target/package).mkdir(parents=True, exist_ok=True)
        for name in names:
            path=PUBLIC/package/name
            if not path.is_file() or path.is_symlink():
                raise OrganizerConfigurationError('Official SDK source is missing or is a symlink')
            shutil.copyfile(path, target/package/path.name)
    return target


@dataclass(frozen=True)
class ContainerLimits:
    cpus: float
    memory: str
    pids: int
    tmp_mb: int

    def arguments(self):
        _positive(self.cpus,'cpus');_positive(self.pids,'pids');_positive(self.tmp_mb,'tmp_mb')
        if type(self.pids) is not int or type(self.tmp_mb) is not int:
            raise OrganizerConfigurationError('pids and tmp_mb must be positive integers')
        if not isinstance(self.memory,str) or not self.memory or not self.memory[-1:].lower() in ('m','g') or not self.memory[:-1].isdigit():
            raise OrganizerConfigurationError('Container memory must be an explicit M/G quantity')
        if not self.memory[:-1].strip('0'):
            raise OrganizerConfigurationError('Container memory must be positive')
        return ['--cpus',str(self.cpus),'--memory',self.memory,'--pids-limit',str(int(self.pids)),
                '--tmpfs',f'/tmp:rw,nosuid,nodev,size={int(self.tmp_mb)}m']


class AgentHandle:
    def __init__(self, process, logs, stop=None, owned_output=None):
        self.process,self.logs,self.stopper = process,logs,stop
        self.owned_output = owned_output

    def poll(self):return self.process.poll()

    def stop(self):
        if self.stopper is not None:
            self.stopper()
        if self.process.poll() is None:
            self.process.terminate()
            try:self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=5)
        for stream in self.logs:
            stream.close()


class LocalDiagnosticBackend:
    """Only for organizer-authored engineering tests, never contestant hosting."""
    production_isolation = False

    def __init__(self, *, explicitly_allow_local=False):
        if not explicitly_allow_local:
            raise OrganizerConfigurationError('Local diagnostic execution must be explicitly enabled')

    def start_agent(self, manifest, *, submission_root, output_dir, log_dir, endpoint, token,
                    socket_directory=None, model_mounts=(), sdk_root=None):
        root=Path(submission_root).resolve();output=Path(output_dir).resolve();logs=Path(log_dir).resolve()
        output.mkdir(parents=True,exist_ok=True);logs.mkdir(parents=True,exist_ok=True)
        env = {key:value for key,value in os.environ.items()
               if key in ('PATH','SYSTEMROOT','WINDIR','LANG','LC_ALL','TMP','TEMP','HOME','USERPROFILE')}
        env.update(RIFT_CONSOLE_URL=endpoint,RIFT_SESSION_TOKEN=token,RIFT_OUTPUT_DIR=str(output),
                   PYTHONPATH=str(PUBLIC),PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
        command=list(manifest['entrypoint'])
        if command[0]=='python':command[0]=sys.executable
        handles=[open(logs/'agent.stdout.log','wb'),open(logs/'agent.stderr.log','wb')]
        try:process=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=handles[0],stderr=handles[1])
        except OSError as exc:
            for stream in handles:stream.close()
            raise InfrastructureError('Unable to start diagnostic agent') from exc
        return AgentHandle(process,handles)

    def execute_law(self,path,case,*,timeout_seconds):
        return run_law_file(path,case,timeout_seconds=timeout_seconds)


class DockerBackend:
    production_isolation = True

    def __init__(self, *, agent_image, candidate_image, agent_limits, candidate_limits,
                 gpu_devices, uid, gid, docker='docker', require_linux=True):
        if require_linux and sys.platform!='linux':
            raise OrganizerConfigurationError('Production container execution requires the target Linux host')
        self.agent_image=immutable_image(agent_image)
        self.candidate_image=immutable_image(candidate_image)
        self.agent_limits,self.candidate_limits=agent_limits,candidate_limits
        self.agent_limits.arguments();self.candidate_limits.arguments()
        if len(gpu_devices)!=4 or len(set(gpu_devices))!=4 or any(not str(v).isdigit() for v in gpu_devices):
            raise OrganizerConfigurationError('Configure exactly four distinct GPU device IDs')
        if any(isinstance(v,bool) or not isinstance(v,int) or v<0 for v in (uid,gid)):
            raise OrganizerConfigurationError('Container UID/GID must be nonnegative integers')
        self.gpus=tuple(str(v) for v in gpu_devices);self.uid,self.gid=uid,gid;self.docker=docker
        self.runtime_sha256=public_runtime_digest()
        self.runtime_root=PRIVATE/'runtime/shared-sdk'/self.runtime_sha256
        stage_public_runtime(self.runtime_root)

    def _base(self, name, limits):
        return [self.docker,'run','--rm','--name',name,'--network','none','--read-only',
                '--cap-drop','ALL','--security-opt','no-new-privileges',
                '--user',f'{self.uid}:{self.gid}',*limits.arguments(),
                '--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONIOENCODING=utf-8']

    @staticmethod
    def _mount(source,target,readonly=True):
        source=Path(source).resolve()
        if not source.exists():raise OrganizerConfigurationError(f'Required organizer mount does not exist: {target}')
        if ',' in str(source):raise OrganizerConfigurationError('Comma in a Docker mount path is unsupported')
        return ['--mount',f'type=bind,src={source},dst={target}'+(',readonly' if readonly else '')]

    def agent_command(self,manifest,*,output_dir,endpoint,token,socket_directory,model_mounts=(),sdk_root=None,name):
        if not endpoint.startswith('unix:///run/rift/') or socket_directory is None:
            raise OrganizerConfigurationError('Production agents require the official Unix socket only')
        command=self._base(name,self.agent_limits)
        command+=['--shm-size','16g']
        command+=['--workdir','/submission']
        command+=['--gpus','"device='+','.join(self.gpus)+'"']
        command+=self._mount(socket_directory,'/run/rift',True)
        command+=self._mount(output_dir,'/output',False)
        command+=self._mount(sdk_root or self.runtime_root,'/opt/rift-sdk',True)
        # Only operator-configured model mounts. Manifest paths never select a
        # host path. Each target is constrained to a single public model area.
        for source,target in model_mounts:
            if not isinstance(target,str) or not target.startswith('/models/') or '..' in Path(target).parts:
                raise OrganizerConfigurationError('Model mount target must be below /models')
            command+=self._mount(source,target,True)
        for key,value in {'RIFT_CONSOLE_URL':endpoint,'RIFT_SESSION_TOKEN':token,
                          'RIFT_OUTPUT_DIR':'/output','PYTHONPATH':'/opt/rift-sdk:/submission',
                          'HOME':'/output','XDG_CACHE_HOME':'/output/.cache',
                          'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}.items():
            command+=['--env',key if key=='RIFT_SESSION_TOKEN' else f'{key}={value}']
        return command+['--entrypoint',manifest['entrypoint'][0],self.agent_image,*manifest['entrypoint'][1:]]

    def _remove(self,name):
        try:subprocess.run([self.docker,'rm','-f',name],capture_output=True,timeout=15,check=False)
        except (OSError,subprocess.TimeoutExpired):pass

    def start_agent(self,manifest,*,submission_root,output_dir,log_dir,endpoint,token,
                    socket_directory=None,model_mounts=(),sdk_root=None):
        logs=Path(log_dir).resolve();logs.mkdir(parents=True,exist_ok=True)
        Path(output_dir).mkdir(parents=True,exist_ok=True)
        name='rift-agent-'+uuid4().hex
        command=self.agent_command(manifest,output_dir=output_dir,endpoint=endpoint,token=token,
            socket_directory=socket_directory,model_mounts=model_mounts,sdk_root=sdk_root,name=name)
        handles=[open(logs/'agent.stdout.log','wb'),open(logs/'agent.stderr.log','wb')]
        child_env=os.environ.copy();child_env['RIFT_SESSION_TOKEN']=token
        try:process=subprocess.Popen(command,env=child_env,stdin=subprocess.DEVNULL,stdout=handles[0],stderr=handles[1])
        except OSError as exc:
            for stream in handles:stream.close()
            raise InfrastructureError('Cannot launch production container runtime') from exc
        return AgentHandle(process,handles,stop=lambda:self._remove(name))

    def candidate_command(self,path,*,name):
        command=self._base(name,self.candidate_limits)+['--interactive']
        # Keep state until the trusted parent classifies OOM/signal exits.
        command.remove('--rm')
        command+=self._mount(self.runtime_root,'/opt/rift-sdk',True)
        command+=self._mount(path,'/candidate/law.py',True)
        return command+['--entrypoint','python',self.candidate_image,'-I','-X','utf8',
                        '/opt/rift-sdk/rift/worker.py','--law','/candidate/law.py']

    def execute_law(self,path,case,*,timeout_seconds):
        from rift.law import validate_law
        from rift.prediction import validate_case
        try:clean=validate_case(case)
        except ValueError as exc:raise OrganizerConfigurationError(str(exc)) from exc
        validate_law(path)  # static only; untrusted source is not executed here
        identity=hashlib.sha256(Path(path).read_bytes()).hexdigest()
        _positive(timeout_seconds,'candidate_timeout_seconds')
        name='rift-law-'+uuid4().hex
        command=self.candidate_command(path,name=name)
        try:
            try:
                process=subprocess.run(command,input=json.dumps(clean,ensure_ascii=False,allow_nan=False),
                    text=True,encoding='utf8',capture_output=True,timeout=timeout_seconds,check=False)
            except subprocess.TimeoutExpired as exc:
                raise CandidateExecutionError('Candidate exceeded the configured execution limit') from exc
            except OSError as exc:raise InfrastructureError('Cannot start official prediction container') from exc
            return self._candidate_response(process,name,identity)
        finally:
            self._remove(name)

    def _candidate_response(self,process,name,identity):
        if process.returncode in (125,126,127):
            raise InfrastructureError('Official prediction container could not start')
        if len(process.stdout)>16*1024*1024:
            raise CandidateExecutionError('Prediction exceeds the transport limit')
        try:response=json.loads(process.stdout)
        except ValueError as exc:
            try:
                state_run=subprocess.run([self.docker,'inspect','--format','{{json .State}}',name],
                    capture_output=True,text=True,encoding='utf8',timeout=15,check=False)
                state=json.loads(state_run.stdout) if state_run.returncode==0 else {}
            except (OSError,ValueError,subprocess.TimeoutExpired):state={}
            # A confirmed container memory limit or native numerical crash is
            # a failed candidate prediction. Unknown worker/protocol failures
            # remain infrastructure errors; never guess scientific failure.
            started=bool(state.get('StartedAt')) and not str(state.get('StartedAt','')).startswith('0001-')
            if state.get('OOMKilled') is True or (started and state.get('ExitCode') in (134,136,139) and not state.get('Error')):
                raise CandidateExecutionError('Candidate exceeded memory or failed in native numerical computation') from exc
            raise InfrastructureError('Official prediction worker returned invalid protocol data') from exc
        if not isinstance(response,dict):raise InfrastructureError('Official prediction worker response is not an object')
        if response.get('status')=='invalid_case':raise OrganizerConfigurationError('Official case rejected by fixed worker')
        if response.get('status') in ('invalid_law','candidate_error'):
            raise CandidateExecutionError('Candidate rejected or failed during fixed prediction')
        if process.returncode!=0 or response.get('status')!='ok':
            raise InfrastructureError('Official prediction worker did not complete')
        if response.get('law_sha256')!=identity:raise InfrastructureError('Frozen source identity mismatch')
        return response


__all__=['LocalDiagnosticBackend','DockerBackend','ContainerLimits','AgentHandle',
         'stage_public_runtime','immutable_image','public_runtime_digest']
