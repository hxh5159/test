"""Accept one strategy ZIP privately, then reuse the fixed strategy evaluator.

Intake and check-only validation never import or execute submitted agent code.
Model weights remain at their declared local paths and are not copied into the
submission.  Only approved evaluation feedback is copied to summary.json.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

# Import the existing entry first: it selects the shipped public/ (or flat)
# runtime before other private modules resolve any fixed public imports.
from evaluate_strategy import evaluate
from contest_job_runner import _write_private
from law_program_evaluation import OrganizerConfigurationError
from rift.submission import SubmissionError
from strategy_zip_intake import accept_strategy_zip


_SCORE_FIELDS = frozenset((
    'job_id', 'team_id', 'accepted_at', 'state', 'total_score', 'world_scores',
    'schema_version', 'execution_mode', 'submission_id', 'error',
))
_CHECK_FIELDS = frozenset((
    'status', 'team_id', 'submission_id', 'model_count', 'world_count', 'model_loaded',
))


def evaluate_submission_zip(submission_zip, output, *, profile_path=None,
                            agent_python=None, run_as=None, check_only=False,
                            max_unpacked_bytes=1024**3, max_members=10000,
                            backend=None):
    """Keep accepted bytes and private evaluation under one new run directory.

    ``backend`` is solely a Python engineering-test injection point.  The CLI
    exposes no same-user or diagnostic execution mode.
    """
    root = Path(output).expanduser().absolute()
    if root.exists() or root.is_symlink():
        raise OrganizerConfigurationError('Choose a new output directory; existing runs are never overwritten')
    root.mkdir(parents=True, mode=0o700)
    root.chmod(0o700)
    accepted = accept_strategy_zip(submission_zip, root/'accepted', check_files=True,
        max_unpacked_bytes=max_unpacked_bytes, max_members=max_members)
    result = evaluate(accepted['agent_dir'], accepted['models_file'], root/'evaluation',
        profile_path=profile_path, agent_python=agent_python, run_as=run_as,
        check_only=check_only, backend=backend)
    fields = _CHECK_FIELDS if check_only else _SCORE_FIELDS
    summary = {key:value for key,value in result.items() if key in fields}
    _write_private(root/'summary.json', summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--submission-zip', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--run-as', required=True)
    parser.add_argument('--agent-python')
    parser.add_argument('--profile', type=Path)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--max-unpacked-bytes', type=int, default=1024**3,
                        help='Organizer intake size limit (default 1 GiB); model weights stay external.')
    parser.add_argument('--max-members', type=int, default=10000,
                        help='Organizer ZIP member limit (default 10000).')
    args = parser.parse_args(argv)
    try:
        result = evaluate_submission_zip(args.submission_zip, args.output,
            profile_path=args.profile, agent_python=args.agent_python,
            run_as=args.run_as, check_only=args.check_only,
            max_unpacked_bytes=args.max_unpacked_bytes, max_members=args.max_members)
    except (OSError, ValueError, RuntimeError) as exc:
        if isinstance(exc, SubmissionError):
            error = exc.as_dict()
        elif isinstance(exc, OrganizerConfigurationError):
            error = {'code':'organizer_configuration_error', 'path':'$', 'message':str(exc)}
        else:
            error = {'code':'startup_or_format_error', 'path':'$', 'message':
                'Check the submission ZIP, declared model paths, evaluation account and organizer profile.'}
        result = {'status':'startup_or_format_error', 'error':error}
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result.get('state', 'completed') == 'completed' else 2


if __name__ == '__main__':
    raise SystemExit(main())
