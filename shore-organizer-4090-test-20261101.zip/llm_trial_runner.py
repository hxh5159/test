"""Private runner for white-listed, self-hosted LLM discovery trials.

No model is downloaded or contacted on import. The CLI requires an explicit
operator-provided self-hosted vLLM base URL. It uses stdlib urllib and a small
JSON-action loop; no mature agent/coding framework or closed-model provider is
used. Only detached public console data reaches the model. Hidden evaluation
cases, simulator fields, per-reading noise samples and scoring truth never enter its context.

The numerical fit tool is an explicit hypothesis-library aid, not unlimited
Python execution. A run with that aid measures the combined tool-supported
system. It is not proof of unrestricted model coding/scientific capability.
By default there is no extra model-turn cap (max_turns=0); the console's
wall-clock window and experiment quotas still apply. A positive max_turns
is an optional calibration-only cap, never an additional contest rule.
Console/model/code must be separated by real permissions for deployment; this
organizer-only calibration runner does not implement production isolation.

HTTP format follows the official vLLM OpenAI-compatible chat server protocol:
https://docs.vllm.ai/en/v0.11.0/serving/openai_compatible_server.html
This does not depend on the OpenAI SDK or call an OpenAI model/provider.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

import numpy as np


WHITE_LIST = (
    "Qwen3.8-27B", "GLM-4.7-Flash", "Qwen3.6-35B-A3B",
    "Kimi-Linear-48B-A3B-Instruct", "GLM-4.5-Air-FP8",
    "Qwen3.5-122B-A10B-FP8", "DeepSeek-V4-Flash", "MiniMax-M2.5",
    "Qwen3.5-397B-A17B-FP8",
)
QUANT_SUFFIXES = ("-W8A8", "-FP8", "-BF16", "-AWQ", "-GPTQ")
WORLDS = ("Adam", "Lilith", "Tabris", "Sachiel", "Ramiel", "Matriel", "Leliel", "Arael", "Lilin")
RUNNER_VERSION = "white-llm-trial-runner-1.1.0"


def json_copy(value):
    return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))


def allowed_model(model):
    if not isinstance(model, str) or not model.strip():
        raise ValueError("A model ID is required.")
    basename = model.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
    choices = set(WHITE_LIST)
    choices.update(name + suffix for name in WHITE_LIST for suffix in QUANT_SUFFIXES)
    if basename not in choices:
        raise ValueError("Model ID/basename is outside the project white list.")
    return basename


class ExplorationDeadlineError(TimeoutError):
    """The known exploration clock expired, rather than a provider diagnosis."""


def inference_socket_timeout(client):
    """Bound socket waits by live remaining time, not total request duration.

    A peer returning data incrementally can take longer overall. The action
    loop rejects late results; the official process watchdog stops agents.
    """
    remaining = getattr(client, "_exploration_remaining_seconds", None)
    if remaining is None:
        return client.timeout
    seconds = float(remaining())
    if not math.isfinite(seconds) or seconds <= 0:
        raise ExplorationDeadlineError("The exploration window ended before or during the inference request.")
    return min(client.timeout, seconds)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # An inference endpoint should not redirect authorization to a new host.
        return None


class VLLMClient:
    """Explicit self-hosted endpoint only; no automatic provider fallback."""
    capability_label = "actual_self_hosted_model_transport"

    def __init__(self, base_url, model, *, api_key=None, timeout=300.):
        self.requested_model = model
        self.basename = allowed_model(model)
        parsed = urlsplit(base_url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError("base_url must be an explicit HTTP(S) self-hosted vLLM URL.")
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("Do not put credentials, query parameters or fragments in base_url.")
        path = parsed.path.rstrip("/")
        if not path.endswith("/v1"):
            path += "/v1"
        self.base_url = urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))
        self._api_key = api_key
        self.timeout = float(timeout)
        if not math.isfinite(self.timeout) or self.timeout <= 0:
            raise ValueError("HTTP timeout must be finite and positive.")
        self._opener = build_opener(NoRedirect())
        self.model = None
        self.metadata = None
        self._exploration_remaining_seconds = None

    def set_exploration_remaining(self, remaining):
        if remaining is not None and not callable(remaining):
            raise ValueError("Exploration remaining time must be a callable or None.")
        self._exploration_remaining_seconds = remaining

    def _request(self, suffix, body=None):
        headers = {"Accept": "application/json"}
        data = None
        if body is not None:
            data = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self._api_key:
            headers["Authorization"] = "Bearer " + self._api_key
        request = Request(self.base_url + suffix, data=data, headers=headers,
                          method="POST" if body is not None else "GET")
        try:
            with self._opener.open(request, timeout=inference_socket_timeout(self)) as response:
                # Keep a bounded response; model output is bounded separately.
                raw = response.read(8 * 1024 * 1024 + 1)
                if len(raw) > 8 * 1024 * 1024:
                    raise RuntimeError("Inference server response exceeds the client size limit.")
            inference_socket_timeout(self)  # Reject data completed past the clock.
        except HTTPError as exc:
            raise RuntimeError(f"Inference endpoint returned HTTP {exc.code}; no provider fallback was attempted.") from None
        except URLError as exc:
            raise RuntimeError("Unable to reach the explicit self-hosted inference endpoint.") from None
        try:
            return json.loads(raw)
        except (ValueError, UnicodeError):
            raise RuntimeError("Inference endpoint returned invalid JSON.") from None

    def discover(self):
        response = self._request("/models")
        models = response.get("data")
        if not isinstance(models, list):
            raise RuntimeError("The self-hosted server did not return a model list.")
        exact = [m for m in models if isinstance(m, dict) and m.get("id") == self.requested_model]
        if exact:
            selected = exact[0]
            allowed_model(selected["id"])
        else:
            selected = []
            for item in models:
                if not isinstance(item, dict) or not isinstance(item.get("id"), str):
                    continue
                try:
                    same = allowed_model(item["id"]) == self.basename
                except ValueError:
                    same = False
                if same:
                    selected.append(item)
            if len(selected) != 1:
                raise RuntimeError("Requested white-listed model is absent or ambiguous in server metadata.")
            selected = selected[0]
        self.model = selected["id"]
        self.metadata = {"base_url": self.base_url, "requested_model": self.requested_model,
                         "served_model": self.model,
                         "server_model_metadata": {k: selected[k] for k in
                             ("id", "object", "created", "owned_by", "root", "parent", "max_model_len") if k in selected},
                         "verification_limit": "Server-reported identity; not cryptographic verification of loaded weights."}
        return json_copy(self.metadata)

    def complete(self, messages, *, seed, max_tokens=2048, temperature=.3):
        if self.model is None:
            raise RuntimeError("Call discover() before generation.")
        return self._request("/chat/completions", {"model": self.model, "messages": messages,
            "seed": int(seed), "max_tokens": int(max_tokens), "temperature": float(temperature), "stream": False})


def parse_action(text):
    """Accept a single JSON action, optionally wrapped by thinking/fences."""
    if not isinstance(text, str):
        raise ValueError("Model message content must be text.")
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.IGNORECASE).strip()
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key.")
            result[key] = value
        return result
    decoder = json.JSONDecoder(object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON number.")))
    matches = []
    for i, character in enumerate(cleaned):
        if character != "{":
            continue
        try:
            value, end = decoder.raw_decode(cleaned[i:])
        except ValueError:
            continue
        if isinstance(value, dict) and isinstance(value.get("action"), str):
            matches.append((i, end, value))
    if len(matches) != 1:
        raise ValueError("Return exactly one JSON object with an action string.")
    return matches[0][2]


def claims_valid(claims):
    if not isinstance(claims, dict) or set(claims) != {"dynamics_order", "hidden_matter", "time_dependence"}:
        raise ValueError("claims must contain exactly the three required scientific fields.")
    order = claims["dynamics_order"]
    if type(order) not in (int,float) or not math.isfinite(order) or order not in (1, 2):
        raise ValueError("dynamics_order must be integer1 or2.")
    if type(claims["hidden_matter"]) is not bool or type(claims["time_dependence"]) is not bool:
        raise ValueError("hidden_matter and time_dependence must be JSON booleans.")
    normalized=json_copy(claims)
    normalized['dynamics_order']=int(order)
    return normalized


class SimpleCandidate:
    """Safe structured baseline law; never executes model-supplied Python."""
    def __init__(self, family, acceleration=None):
        if family not in ("ballistic", "constant_acceleration"):
            raise ValueError("Unsupported simple candidate family.")
        self.family = family
        self.a = np.asarray([0., 0.] if acceleration is None else acceleration, dtype=float)
        if self.a.shape != (2,) or not np.isfinite(self.a).all():
            raise ValueError("acceleration must be a finite two-vector.")
        if family == "ballistic" and np.any(self.a):
            raise ValueError("Ballistic candidate requires zero acceleration.")

    def to_dict(self):
        return {"runner_simple_family": self.family, "acceleration": self.a.tolist()}

    def predict(self, case):
        tau = np.asarray(case["readout"], dtype=float)[:, None, None]
        pos = np.asarray([p["pos"] for p in case["probes"]], dtype=float)
        vel = np.asarray([p["vel"] for p in case["probes"]], dtype=float)
        return pos[None] + tau * vel[None] + .5 * tau * tau * self.a[None, None]


def candidate_from_artifact(data):
    if not isinstance(data, dict):
        raise ValueError("Candidate data must be an object.")
    if "runner_simple_family" in data:
        return SimpleCandidate(data["runner_simple_family"], data.get("acceleration"))
    from blind_numeric_agent import Candidate
    return Candidate.from_dict(data)


def default_fit(mission, transcript):
    from blind_numeric_agent import fit_public_transcript
    # Opaque IDs have no scientific role in the supplied numerical aid.
    def strip_ids(value):
        if isinstance(value, dict):
            return {k: strip_ids(v) for k, v in value.items() if k != "world_id"}
        if isinstance(value, list):
            return [strip_ids(v) for v in value]
        return value
    return fit_public_transcript(strip_ids(mission), strip_ids(transcript))


def preview_payload(payload, record_id):
    """A compact honest preview; all omitted data remains available by record."""
    result = json_copy(payload)
    for field in ("positions", "velocities", "visible_background_positions"):
        values = result.pop(field, None)
        if values is None:
            continue
        n = len(values)
        indices = sorted(set(i for i in (0, 1, 2, n-1) if 0 <= i < n))
        result.setdefault("sample_preview", {})[field] = {"sample_indices": indices,
            "values": [values[i] for i in indices], "total_samples": n, "omitted_samples": n-len(indices)}
    result["public_record_id"] = record_id
    result["full_data_available"] = True
    result["read_full_data"] = {"action": "view_record", "record_id": record_id,
                                 "start": 0, "count": 10}
    return result


SYSTEM_PROMPT = """你是一个开源LLM物理发现智能体，正在一个未知二维宇宙中完成任务。
只使用给你的公开初态、第一束光和工具返回的观测，不知道真实力律、真实参数或隐藏验证轨迹。
每次只输出一个JSON action，不输出Python代码。可用操作：
1 {"action":"mission"} 读取同一缓存任务与第一束光，不重置配额。
2 {"action":"observe","times":[0,1,2]} 免费读取可见背景位置，有独立调用上限。
3 {"action":"launch","t_launch":0,"readout":[0,0.005,0.01],"source_properties":{},"probes":[{"pos":[3,0],"vel":[0,0.2],"properties":{}}]}
   实际属性键/值/合法区域按mission提供；每新探针扣1能量，探针互不作用。投放时间和readout是物理时间。
4 {"action":"fit"} 使用已获得的公开观测运行一个受限数值候选库拟合工具，不读取验证真值，不消耗实验配额但消耗墙钟。
   它返回candidate_id、拟合候选和三条声明建议；并不能保证已发现正确规律。
5 {"action":"view_record","record_id":0,"start":0,"count":10} 读取指定公开数据记录中一段完整位置/速度/时刻，最多50个采样；任何预览省略都可从此读取。
6 {"action":"finish","candidate_id":"fit_1","claims":{"dynamics_order":2,"hidden_matter":false,"time_dependence":false},"report":"依据与局限"}
   也可用candidate代替candidate_id：{"runner_simple_family":"ballistic","acceleration":[0,0]}，
   或{"runner_simple_family":"constant_acceleration","acceleration":[ax,ay]}，或自己调整fit工具返回的结构化候选。
claims只三项：作用决定速度填1、决定加速度填2；是否有位置不可见的作用源；固定完整几何和属性后是否显式依赖物理时间。
位置和探针速度噪声在新实验中独立；速度每坐标标准差为公开初速上限的0.01%，已知投放初态精确。第一束光同规则，旧记录读取不重抽。按公开协议独立设计实验，平衡信息量与能量。
你可使用数值工具，不需要徒手推导；所有候选参数都只能来自公开数据。不会获得隐藏测试分项/真值反馈。
"""


class LLMTrial:
    def __init__(self, console, client, *, seed, out_dir, fit_fn=default_fit,
                 max_turns=0, context_chars=64000, max_tokens=2048, temperature=.3):
        if isinstance(max_turns,bool) or not isinstance(max_turns,(int,np.integer)) or max_turns < 0:
            raise ValueError("max_turns must be0 (no extra turn cap) or a positive diagnostic cap.")
        if context_chars < 8000:
            raise ValueError("context_chars must allow at least8000 characters.")
        self.console, self.client = console, client
        self.seed = int(seed)
        self.out_dir = Path(out_dir)
        self.fit_fn = fit_fn
        self.max_turns, self.context_chars = int(max_turns), int(context_chars)
        self.max_tokens, self.temperature = int(max_tokens), float(temperature)
        self.records, self.events, self.history, self.fits = [], [], [], {}
        self.mission = None
        self.finished = None
        self._candidate = None

    def _write(self, status):
        self.out_dir.mkdir(parents=True, exist_ok=True)
        def save(name, value):
            (self.out_dir/name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf8")
        save("public_records.json", self.records)
        save("model_events.json", self.events)
        save("public_console_transcript.json", self.console.public_transcript)
        save("run.json", {"runner_version": RUNNER_VERSION, "status": status,
            "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "capability_label": getattr(self.client, "capability_label", "injected_transport_protocol_test"),
            "diagnostic_model_turn_cap": self.max_turns,
            "cap_is_contest_rule": False,
            "model_turn_cap_meaning": "0 means no extra model-turn cap; any positive cap is diagnostic only. Console wall-clock/quota rules still apply.",
            "seed": self.seed, "model_turns": len(self.events), "budget": self.console.budget,
            "model_metadata": getattr(self.client, "metadata", None),
            "submission": self.finished,
            "scope": "Tool-supported LLM calibration; no hidden validation feedback returned to the model."})
        if self.finished is not None:
            save("candidate.json", self.finished["candidate"])
            save("claims.json", self.finished["claims"])

    def _store(self, operation, payload):
        record = {"record_id": len(self.records), "operation": operation, "data": json_copy(payload)}
        self.records.append(record)
        return preview_payload(payload, record["record_id"])

    def _context(self, turn):
        # Full model/tool history lives in model_events/public_records on disk.
        # Old context is omitted only with an explicit record directory to view.
        index = [{"record_id": r["record_id"], "operation": r["operation"],
                  "sample_count": len(r["data"].get("times", []))} for r in self.records]
        control = {"turn": turn, "max_turns": self.max_turns,
                   "remaining_model_turns": None if self.max_turns==0 else self.max_turns-turn+1,
                   "cap_is_contest_rule": False,
                   "budget": self.console.budget, "record_directory": index,
                   "available_candidate_ids": list(self.fits),
                   "instruction": ("No extra model-turn cap. Finish within the console wall-clock window; complete observations are available by view_record."
                       if self.max_turns==0 else
                       "This run has an optional diagnostic-only turn cap. Finish within the remaining turns. Complete observations are available by view_record.")}
        fixed = [{"role": "system", "content": SYSTEM_PROMPT},
                 {"role": "user", "content": "任务信息与首次观测：\n"+json.dumps(self.mission,ensure_ascii=False)},
                 {"role": "user", "content": "当前账本与记录索引：\n"+json.dumps(control,ensure_ascii=False)}]
        retained = []
        available = self.context_chars - sum(len(m["content"]) for m in fixed)
        if available < 0:
            raise RuntimeError("Mission metadata exceeds the configured context character budget; increase --context-chars.")
        for message in reversed(self.history):
            size = len(message["content"])
            if size > available:
                break
            retained.append(message)
            available -= size
        fixed[2]["content"] += "\n" + json.dumps({"omitted_history_messages": len(self.history)-len(retained),
            "omitted_history_is_not_lost": True},ensure_ascii=False)
        return fixed+list(reversed(retained))

    def _action(self, action):
        if self.console.budget['wall_clock_remaining_seconds'] <= 0:
            raise TimeoutError("The exploration wall-clock window has ended.")
        name = action.get("action")
        if name == "mission":
            if set(action) != {"action"}: raise ValueError("mission takes no extra keys.")
            return self._store(name,self.console.mission())
        if name == "observe":
            if set(action) != {"action","times"}: raise ValueError("observe requires times only.")
            return self._store(name,self.console.observe(action["times"]))
        if name == "launch":
            if set(action) != {"action","probes","t_launch","readout","source_properties"}:
                raise ValueError("launch requires probes,t_launch,readout,source_properties.")
            return self._store(name,self.console.launch(action["probes"],action["t_launch"],action["readout"],action["source_properties"]))
        if name == "view_record":
            if not {"action","record_id"} <= set(action) or set(action)-{"action","record_id","start","count"}:
                raise ValueError("view_record takes record_id,start,count only.")
            record_id, start, count = action["record_id"],action.get("start",0),action.get("count",10)
            if any(type(x) is not int for x in (record_id,start,count)) or not 0 <= record_id < len(self.records) or start < 0 or not 1 <= count <= 50:
                raise ValueError("Invalid public record slice.")
            data = json_copy(self.records[record_id]["data"])
            if "times" in data:
                n = len(data["times"])
                if start >= n: raise ValueError("Record slice starts after its data.")
                for field in ("times","readout","positions","velocities","visible_background_positions"):
                    if isinstance(data.get(field),list) and len(data[field]) == n:
                        data[field]=data[field][start:start+count]
                data.update(sample_start=start,total_samples=n)
            return {"record_id": record_id, "operation": self.records[record_id]["operation"], "data": data,
                    "budget": self.console.budget}
        if name == "fit":
            if set(action) != {"action"}: raise ValueError("fit takes no extra keys.")
            fitted = self.fit_fn(self.mission,self.console.public_transcript)
            if self.console.budget['wall_clock_remaining_seconds'] <= 0:
                raise TimeoutError("The exploration wall-clock window ended during fitting.")
            candidate=fitted["candidate"]
            model=json_copy(candidate.to_dict())
            candidate_id=f"fit_{len(self.fits)+1}"
            self.fits[candidate_id]=candidate
            return {"candidate_id":candidate_id,"candidate":model,"suggested_claims":claims_valid(fitted["claims"]),
                    "diagnostics_from_public_data_only":json_copy(fitted.get("diagnostics",{})),"budget":self.console.budget}
        if name == "finish":
            if set(action)-{"action","candidate_id","candidate","claims","report"} or "claims" not in action:
                raise ValueError("finish requires candidate_id or candidate, claims and optional report.")
            if ("candidate_id" in action) == ("candidate" in action):
                raise ValueError("Choose exactly one candidate_id or structured candidate.")
            if "candidate_id" in action:
                if action["candidate_id"] not in self.fits: raise ValueError("Unknown fitted candidate ID.")
                candidate=self.fits[action["candidate_id"]]
            else:
                model=action["candidate"]
                if len(json.dumps(model))>256000: raise ValueError("Candidate JSON exceeds calibration limit.")
                candidate=candidate_from_artifact(model)
            claims=claims_valid(action["claims"])
            report=action.get("report","")
            if not isinstance(report,str) or len(report)>16000: raise ValueError("report must be short text.")
            finished={"candidate":json_copy(candidate.to_dict()),"claims":claims,"report":report}
            if self.console.budget['wall_clock_remaining_seconds'] <= 0:
                raise ExplorationDeadlineError("The exploration window ended while validating the final artifacts.")
            self._candidate=candidate
            self.finished=finished
            return {"accepted":True,"submission_saved":True,"budget":self.console.budget}
        raise ValueError("Unknown action; use mission,observe,launch,view_record,fit or finish.")

    def run(self):
        if self.out_dir.exists() and any(self.out_dir.iterdir()):
            raise FileExistsError("Output directory is not empty; choose a new trial directory.")
        self.mission=self.console.mission()
        if callable(getattr(self.client, "set_exploration_remaining", None)):
            self.client.set_exploration_remaining(
                lambda: self.console.budget['wall_clock_remaining_seconds'])
        self._store("initial_mission",self.mission)
        self._write("running")
        status="turn_limit_no_submission"
        turn=1
        while self.max_turns==0 or turn<=self.max_turns:
            if self.console.budget['wall_clock_remaining_seconds'] <= 0:
                status="wall_clock_expired_no_submission"
                break
            try:
                messages=self._context(turn)
                response=self.client.complete(messages,seed=self.seed+turn,max_tokens=self.max_tokens,temperature=self.temperature)
                content=response["choices"][0]["message"].get("content")
                if not isinstance(content,str): raise RuntimeError("Model returned no textual action content.")
            except Exception as exc:
                if isinstance(exc, ExplorationDeadlineError):
                    self.events.append({"turn":turn,"exploration_deadline_expired":str(exc)[:1000]})
                    status="wall_clock_expired_no_submission"
                    break
                self.events.append({"turn":turn,"transport_or_context_error":str(exc)[:1000]})
                status="model_transport_or_context_error"
                break
            event={"turn":turn,"model_request":{"messages":json_copy(messages),"seed":self.seed+turn,
                    "max_tokens":self.max_tokens,"temperature":self.temperature},
                   "model_response":json_copy(response)}
            if self.console.budget['wall_clock_remaining_seconds'] <= 0:
                event["late_model_response_rejected"] = True
                self.events.append(event)
                status="wall_clock_expired_no_submission"
                break
            try:
                action=parse_action(content)
                answer=self._action(action)
                event.update(action=action,tool_response=answer)
            except Exception as exc:
                answer={"action_error":str(exc)[:1000],"budget":self.console.budget}
                event["tool_response"]=answer
            self.events.append(event)
            self.history.extend([{"role":"assistant","content":content},
                                 {"role":"user","content":"工具结果：\n"+json.dumps(answer,ensure_ascii=False)}])
            if self.finished is not None:
                status="submitted"
                self._write(status)
                break
            self._write("running")
            turn+=1
        if self.finished is None and self.console.budget['wall_clock_remaining_seconds'] <= 0:
            status="wall_clock_expired_no_submission"
        self._write(status)
        return {"status":status,"candidate":self._candidate,
                "claims":None if self.finished is None else self.finished["claims"],
                "energy_used":self.console.budget["energy_used"],"observe_used":self.console.budget["observe_used"],
                "model_turns":len(self.events),"out_dir":str(self.out_dir)}


def weight_metadata(path):
    if path is None:
        return {"provided":False,"loaded_weight_files_verified":False}
    path=Path(path)
    config_path=path/"config.json"
    if not config_path.is_file() or config_path.stat().st_size>2*1024*1024:
        raise ValueError("--model-path must contain a reasonably sized config.json.")
    raw=config_path.read_bytes()
    config=json.loads(raw)
    keys=("model_type","architectures","hidden_size","num_hidden_layers","num_attention_heads","num_key_value_heads","num_experts","num_experts_per_tok")
    quantization=config.get("quantization_config") or {}
    if not isinstance(quantization,dict):
        raise ValueError("quantization_config must be an object or null.")
    return {"provided":True,"model_path":str(path),"config_sha256":hashlib.sha256(raw).hexdigest(),
            "config_summary":{k:config[k] for k in keys if k in config},
            "quantization_config":{k:quantization[k] for k in
                ("quant_method","bits","group_size","weight_block_size") if k in quantization},
            "loaded_weight_files_verified":False}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--base-url',required=True,help='Explicit self-hosted vLLM URL, e.g. http://127.0.0.1:8000/v1')
    parser.add_argument('--model',required=True,help='White-listed model ID or matching served path basename')
    parser.add_argument('--model-path',help='Optional existing remote weight directory for config metadata; never downloads')
    parser.add_argument('--worlds',nargs='+',choices=WORLDS,default=list(WORLDS))
    parser.add_argument('--seeds',nargs='+',type=int,default=[0])
    parser.add_argument('--out-dir',required=True)
    parser.add_argument('--noise-rule',choices=['legacy05','launch01','launch02'],default='launch01')
    parser.add_argument('--max-turns',type=int,default=0,
        help='Optional diagnostic cap only:0(default) means no extra model-turn limit; positive values do not change contest rules')
    parser.add_argument('--context-chars',type=int,default=64000)
    parser.add_argument('--max-tokens',type=int,default=2048)
    parser.add_argument('--temperature',type=float,default=.3)
    parser.add_argument('--http-timeout',type=float,default=300.)
    parser.add_argument('--api-key-env',default='TRIAL_VLLM_API_KEY',help='Environment variable name only; value is never logged')
    args=parser.parse_args(argv)
    if any(seed<0 for seed in args.seeds): parser.error('seeds must be nonnegative')
    if args.max_turns < 0: parser.error('max-turns must be0 (no extra limit) or a positive diagnostic cap')
    if args.context_chars < 8000: parser.error('context-chars must be at least8000')
    if args.max_tokens <= 0: parser.error('max-tokens must be positive')
    if not math.isfinite(args.temperature) or args.temperature < 0: parser.error('temperature must be finite and nonnegative')
    out=Path(args.out_dir)
    if out.exists() and any(out.iterdir()): parser.error('out-dir must be absent or empty; do not overwrite earlier trials')
    allowed_model(args.model)
    weights=weight_metadata(args.model_path)
    from trial_console import TrialConsole
    from trial_catalog import trial_config,calibrate_world
    client=VLLMClient(args.base_url,args.model,api_key=os.environ.get(args.api_key_env),timeout=args.http_timeout)
    server=client.discover()
    out.mkdir(parents=True,exist_ok=True)
    manifest={'runner_version':RUNNER_VERSION,'created_utc':datetime.now(timezone.utc).isoformat(),
        'model_metadata':server,'weight_metadata':weights,'noise_rule':args.noise_rule,'worlds':args.worlds,'seeds':args.seeds,
        'limits':{'max_turns':args.max_turns,'cap_is_contest_rule':False,
            'max_turns_meaning':'0=no extra turn cap; positive values are optional diagnostic caps; console wall-clock and quota rules still apply',
            'context_chars':args.context_chars,'max_tokens_per_turn':args.max_tokens},
        'run_scope':'actual self-hosted white-model tool-supported discovery; no hidden evaluation in model loop',
        'results':[]}
    def save_manifest():
        (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    save_manifest()
    for world in args.worlds:
        config=trial_config(world)
        if args.noise_rule=='legacy05': sigma=.05*math.sqrt(float(calibrate_world(world)['global_V']))
        else:
            region=config['launch_region']
            scale=math.sqrt((region['radius_min']**2+region['radius_max']**2)/2)
            sigma=(.01 if args.noise_rule=='launch01' else .02)*scale
        for seed in args.seeds:
            console=TrialConsole(world,sigma,seed,config)
            trial=LLMTrial(console,client,seed=seed,out_dir=out/world/f'seed_{seed}',max_turns=args.max_turns,
                context_chars=args.context_chars,max_tokens=args.max_tokens,temperature=args.temperature)
            result=trial.run()
            manifest['results'].append({k:v for k,v in result.items() if k!='candidate'})
            save_manifest()
            print(json.dumps({k:v for k,v in result.items() if k not in ('candidate','claims')},ensure_ascii=False),flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
