#!/usr/bin/env bash
# PRIVATE organizer environment; source this file from the extracted bundle.
umask 077
export SHORE_TEST_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export SHORE_PROJECT_ROOT='/inspire/hdd/project/urbanlowaltitude/fengkairui-25026/houwenzhe/test/DiscoverPhysics'
export RIFT_PUBLIC_ROOT="$SHORE_TEST_ROOT"
export PYTHONPATH="$SHORE_TEST_ROOT${PYTHONPATH:+:$PYTHONPATH}"
export UV_CACHE_DIR="$SHORE_TEST_ROOT/.cache/uv"
export HF_HOME="$SHORE_TEST_ROOT/.cache/huggingface"
export VLLM_CACHE_ROOT="$SHORE_TEST_ROOT/.cache/vllm"
export TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS=8
export NO_PROXY="127.0.0.1,localhost${NO_PROXY:+,$NO_PROXY}"
export no_proxy="$NO_PROXY"
# This workflow deliberately uses an unauthenticated loopback-only server.
unset VLLM_API_KEY TRIAL_VLLM_API_KEY
# Preserve CUDA_VISIBLE_DEVICES supplied by the GPU scheduler.
