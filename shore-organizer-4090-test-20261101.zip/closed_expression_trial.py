"""PRIVATE closed-model calibration using model-authored acceleration expressions.

This organizer experiment is not a contest-permitted model route. The model
gets detached public observations and generic expression mathematics only.
There is no supplied physical hypothesis library, private validation feedback,
world-name lookup, or automatic scientific-claim suggestion. Importing this
module never contacts a network endpoint. Billing caps belong to the injected
transport. A default16 action cap is a calibration spending cap, not a rule.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import uuid

from llm_trial_runner import (LLMTrial, WORLDS, claims_valid, json_copy, preview_payload,
                              ExplorationDeadlineError)


RUNNER_VERSION = "private-closed-expression-trial-1.0.0"

EXPRESSION_SYSTEM_PROMPT = """你是指挥部为校准任务难度而调用的物理发现模型，正在未知二维宇宙中设计实验。
只使用任务信息、第一束光和你请求的公开观测；你不知道真实作用公式、真实系数、隐藏物体或验证轨迹。
每次只输出一个JSON action。可用操作：
1 {"action":"mission"} 读取缓存任务，不重置时钟或配额。
2 {"action":"observe","times":[0,1]} 观测可见背景位置；合法范围及调用上限在mission中。
3 {"action":"launch","t_launch":0,"readout":[0,0.005,0.01],"source_properties":{},"probes":[{"pos":[3,0],"vel":[0,0],"properties":{}}]}
   用mission所允许的属性键和值。每新探针扣1点能量，每批至多8枚，readout至多50个，所有请求时间须在0.005网格。
   pos、vel是在t_launch的初态；相对readout加t_launch才是绝对模拟时刻；实验调用顺序不推进模拟时间。
4 {"action":"view_record","record_id":0,"start":0,"count":10} 读取某条已获得公开记录的完整切片。
5 {"action":"fit_expression","spec":{"ax":"p0","ay":"p1","parameters":{"p0":{"initial":0,"bounds":[-10,10]},"p1":{"initial":0,"bounds":[-10,10]}}}}
   你自行提出两个加速度表达式，并可声明至多5个待拟合标量p0..p4；这是表达格式示例，不是推荐规律。
   工具仅对已获得公开观测进行有界参数拟合，不会搜索或推荐物理函数族，不查询隐藏验证。
   参数也可没有。你可以反复提出不同表达式，比较各自对公开数据的拟合残差。
   可选center_id指定一个已知可见背景对象ID作为表达式参考；可选center_accel为两个只含常量/参数的表达式，用于推演该参考对象。
   表达式变量：x,y是待预测物体位置，t为共同原点下的模拟时间；cx,cy是参考对象位置；dx=x-cx,dy=y-cy；
   r=sqrt(dx*dx+dy*dy)，rho=sqrt(r*r+eps*eps)，eps=0.05为公开软化值，pi为圆周率。
   source_ratio、probe_ratio分别是本次公开输入属性相对mission默认值的比值，真实物理作用角色需要你判断。
   可用常量、参数、+ - * / **及exp/log/sqrt/sin/cos/tanh/abs/k1/minimum/maximum/where函数；不允许Python语句、导入、文件、网络或任意函数。
   当前诊断表达工具不支持依赖速度的加速度表达式，这是工具限制，不是对未知宇宙真实规律的提示。
6 {"action":"finish","candidate_id":"expr_1","claims":{"dynamics_order":2,"hidden_matter":false,"time_dependence":false},"report":"观测证据与局限"}
   可用spec代替candidate_id，届时先执行相同的公开数据拟合再提交。不得自己覆写候选绑定的初态或实验属性。
claims必须由你填写，仅三项：作用决定速度填1、决定加速度填2；是否存在位置不可见的作用源；固定完整几何/属性后是否显式依赖模拟时间。
工具不会推荐这些声明的答案，也不会返回任何真实评分、正确答案或隐藏轨迹。
初始位置/速度是精确的已知实验输入；后续位置和探针速度均含独立零均值高斯观测噪声。
速度每坐标噪声标准差为本宇宙公开初速上限的0.01%；第一束光同规则，读取缓存不重抽。
第一束光/旧记录读取不重抽噪声；探索能量与observe限额按mission。通用数学和数值拟合是辅助，实验与函数表达由你决定。
"""


def _default_expression_fit(mission, transcript, spec):
    from expression_candidate import fit_expression
    return fit_expression(mission, transcript, spec)


class ClosedExpressionTrial(LLMTrial):
    """A model-authored expression loop; no automatic physical family search."""
    def __init__(self, console, client, *, seed, out_dir, max_turns=16,
                 context_chars=64000, max_tokens=3072, temperature=.3,
                 expression_fit_fn=None):
        # Passing a rejecting fit_fn makes accidental fallback fail closed.
        def disabled_library(*args, **kwargs):
            raise ValueError("The predefined hypothesis-library tool is unavailable in this calibration.")
        super().__init__(console, client, seed=seed, out_dir=out_dir,
            fit_fn=disabled_library,max_turns=max_turns,context_chars=context_chars,
            max_tokens=max_tokens,temperature=temperature)
        self.expression_fit_fn=expression_fit_fn or _default_expression_fit
        self.opaque_world_id="U-"+uuid.uuid4().hex[:16]

    def _anonymous(self, value):
        if isinstance(value,dict):
            return {key:(self.opaque_world_id if key in ("world_id","universe_id") else self._anonymous(item))
                    for key,item in value.items()}
        if isinstance(value,list):return [self._anonymous(item) for item in value]
        if isinstance(value,str):
            # Defensive against IDs embedded in session/experiment labels.
            for name in WORLDS:value=value.replace(name,self.opaque_world_id)
            return value
        return value

    def _public_transcript(self):
        return self._anonymous(json_copy(self.console.public_transcript))

    def _store(self, operation, payload):
        clean=self._anonymous(json_copy(payload))
        if operation in ("initial_mission","mission"):
            self.mission=json_copy(clean)
        record={"record_id":len(self.records),"operation":operation,"data":clean}
        self.records.append(record)
        return preview_payload(clean,record["record_id"])

    def _context(self, turn):
        # Parent implements explicit history trimming and data-record access.
        self.mission=self._anonymous(json_copy(self.mission))
        messages=super()._context(turn)
        messages[0]={"role":"system","content":EXPRESSION_SYSTEM_PROMPT}
        # Recheck using the actual, longer expression prompt.
        while sum(len(m['content']) for m in messages)>self.context_chars and len(messages)>3:
            messages.pop(3)
        if sum(len(m['content']) for m in messages)>self.context_chars:
            raise RuntimeError("Public mission exceeds the configured expression context budget.")
        return self._anonymous(messages)

    def _fit_expression(self, spec):
        if not isinstance(spec,dict) or len(json.dumps(spec,ensure_ascii=False))>32000:
            raise ValueError("spec must be a bounded expression object.")
        fitted=self.expression_fit_fn(self._anonymous(json_copy(self.mission)),self._public_transcript(),json_copy(spec))
        if self.console.budget['wall_clock_remaining_seconds']<=0:
            raise TimeoutError("The exploration wall-clock window ended during expression fitting.")
        candidate=fitted['candidate']
        model=json_copy(candidate.to_dict())
        candidate_id=f"expr_{len(self.fits)+1}"
        self.fits[candidate_id]=candidate
        return {"candidate_id":candidate_id,"candidate":model,
                "fitted_parameters":json_copy(fitted.get('fitted_parameters',{})),
                "diagnostics_from_public_data_only":json_copy(fitted.get('diagnostics',{})),
                "budget":self.console.budget}

    def _action(self, action):
        if self.console.budget['wall_clock_remaining_seconds']<=0:
            raise TimeoutError("The exploration wall-clock window has ended.")
        name=action.get('action')
        if name in ('mission','observe','launch','view_record'):
            return self._anonymous(super()._action(action))
        if name=='fit_expression':
            if set(action)!={'action','spec'}:raise ValueError("fit_expression requires spec only.")
            return self._anonymous(self._fit_expression(action['spec']))
        if name=='finish':
            if set(action)-{'action','candidate_id','spec','claims','report'} or 'claims' not in action:
                raise ValueError("finish requires candidate_id or spec, claims and optional report.")
            if ('candidate_id' in action)==('spec' in action):raise ValueError("Choose exactly one candidate_id or spec.")
            if 'spec' in action:
                answer=self._fit_expression(action['spec']);candidate_id=answer['candidate_id']
            else:candidate_id=action['candidate_id']
            if candidate_id not in self.fits:raise ValueError("Unknown fitted expression candidate ID.")
            candidate=self.fits[candidate_id]
            claims=claims_valid(action['claims'])
            report=action.get('report','')
            if not isinstance(report,str) or len(report)>16000:raise ValueError("report must be short text.")
            finished={'candidate':json_copy(candidate.to_dict()),'claims':claims,'report':report}
            if self.console.budget['wall_clock_remaining_seconds'] <= 0:
                raise ExplorationDeadlineError("The exploration window ended while validating the final artifacts.")
            self._candidate=candidate
            self.finished=finished
            return {'accepted':True,'submission_saved':True,'budget':self.console.budget}
        raise ValueError("Unknown action; use mission,observe,launch,view_record,fit_expression or finish.")

    def _write(self,status):
        """Store the model-visible experiment under opaque IDs; never raw truth."""
        self.out_dir.mkdir(parents=True,exist_ok=True)
        def save(name,value):
            (self.out_dir/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
        save('public_records.json',self._anonymous(self.records))
        # Requests already contain anonymized console payloads. Preserve the
        # exact transport responses rather than rewriting model-authored text.
        save('model_events.json',self.events)
        save('public_console_transcript.json',self._public_transcript())
        metadata=getattr(self.client,'metadata',None)
        save('run.json',{'runner_version':RUNNER_VERSION,'status':status,
            'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'capability_label':getattr(self.client,'capability_label','protocol_mock_only_not_model_capability'),
            'contest_permitted':False,'world_id':self.opaque_world_id,
            'diagnostic_model_turn_cap':self.max_turns,'cap_is_contest_rule':False,
            'seed':self.seed,'model_turns':len(self.events),'budget':self.console.budget,
            'model_metadata':metadata,'api_budget':getattr(self.client,'budget',None),
            'submission':self.finished,
            'scope':'Closed-model organizer calibration with model-authored expressions. No predefined physical family fit or private validation feedback.',
            'limitations':['Restricted mathematical expression interface, not unrestricted coding',
                'No separate HIDDEN object field in this minimal calibration interface',
                'Positive model-turn/API caps are spending controls, not contest rules']})
        if self.finished is not None:
            save('candidate.json',self.finished['candidate']);save('claims.json',self.finished['claims'])


__all__=['ClosedExpressionTrial','EXPRESSION_SYSTEM_PROMPT','RUNNER_VERSION']
