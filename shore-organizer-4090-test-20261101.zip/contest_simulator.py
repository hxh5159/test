"""Organizer-only numerical core for the nine contest worlds.

This module and its adjacent definition JSON must never enter the contestant
SDK or a public repository.  It implements clean true trajectories, not the
HTTP service, quota accounting, noisy observation cache, candidate rollout,
or an official validation-set selection.  Returned arrays are INTERNAL data:
in particular launch(include_background=True) is a diagnostic, not a response
that may bypass the separately metered observe operation.

All positions are laboratory-frame two-vectors.  The common epoch is t=0;
launch time does not reset a moving source or a periodic force.  Public sample
requests follow numerics 1.1 (0.005-aligned ticks), with a smaller dt override
reserved for organizer convergence diagnostics.  The core validates syntax
and physical masses; unfrozen world input ranges are not invented here.
It is not a global stability proof, a deployed service, or an LLM benchmark.

Reference implementation reviewed: PhysicsSchool/physchool/worlds/force_laws.py,
nbody_sampler.py:_make_step and ScienceAgent/scienceagent/executor.py.  This
private NumPy adaptation preserves their applicable force/attribute/initial-
state conventions and drift/kick ordering; it does not claim a JAX runtime
validation.  Historical DP kernels remain unchanged in the public repository.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Callable

import numpy as np

try:
    from rift_numerics.rollout import diagnostic_rollout as _shared_integrate
    from rift_numerics.rollout import YOSHIDA_C, YOSHIDA_D
    from rift_numerics.rollout import __file__ as _shared_numerics_file
except ModuleNotFoundError as exc:
    if exc.name != "rift_numerics":
        raise
    # An organizer bundle may carry rift_numerics alongside this private file.
    # A local development checkout can instead provide its PUBLIC math package.
    # This fallback never imports the research simulator or a true force law.
    configured = os.environ.get("RIFT_PUBLIC_ROOT")
    public_root = (Path(configured).expanduser().resolve() if configured
                   else Path(__file__).resolve().parent.parent / "DiscoverPhysics")
    sys.path.insert(0, str(public_root))
    from rift_numerics.rollout import diagnostic_rollout as _shared_integrate
    from rift_numerics.rollout import YOSHIDA_C, YOSHIDA_D
    from rift_numerics.rollout import __file__ as _shared_numerics_file


DT = 0.005
EPSILON = 0.05
NUMERICS_VERSION = "1.1"
IMPLEMENTATION_VERSION = "private-nine-world-core-1.1.0"
ALIGNMENT_TOLERANCE_TICKS = 1e-9
W4 = 1.0 / (2.0 - 2.0 ** (1.0 / 3.0))
SINGLE_CENTER = frozenset(("Adam", "Lilith", "Tabris", "Leliel"))
CUSTOM = frozenset(("Matriel", "Arael", "Lilin"))


def _finite_scalar(value, name):
    if isinstance(value, (bool, str, bytes)) or np.ndim(value) != 0:
        raise ValueError(f"{name} must be a finite scalar.")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite scalar.") from exc
    if not np.isfinite(result):
        raise ValueError(f"{name} must be finite.")
    return result


def _tick(value, name, *, dt=DT):
    number = _finite_scalar(value, name)
    if number < 0:
        raise ValueError(f"{name} must be nonnegative.")
    ratio = number / dt
    if not np.isfinite(ratio):
        raise ValueError(f"{name} is out of range.")
    result = round(ratio)
    if abs(ratio - result) > ALIGNMENT_TOLERANCE_TICKS:
        raise ValueError(f"{name} must lie on the {dt} time grid.")
    return result


def _sample_ticks(times, name, *, limit=50):
    if isinstance(times, (str, bytes)):
        raise ValueError(f"{name} must be a sequence of times.")
    try:
        values = list(times)
    except TypeError as exc:
        raise ValueError(f"{name} must be a sequence of times.") from exc
    if not 1 <= len(values) <= limit:
        raise ValueError(f"{name} requires 1 to {limit} entries.")
    ticks = np.array([_tick(t, name) for t in values], dtype=np.int64)
    if np.any(np.diff(ticks) <= 0):
        raise ValueError(f"{name} must be strictly increasing.")
    return ticks


def _state_array(value, name):
    try:
        array = np.array(value, dtype=np.float64, copy=True)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must have shape (N, 2).") from exc
    if array.ndim != 2 or array.shape[1] != 2 or not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must be finite with shape (N, 2).")
    return array


def _geometry(positions, sources):
    delta = positions[:, None, :] - sources[None, :, :]
    r = np.linalg.norm(delta, axis=-1)
    rho = np.sqrt(r * r + EPSILON * EPSILON)
    unit = np.divide(delta, r[..., None], out=np.zeros_like(delta),
                     where=r[..., None] > 0)
    return rho, unit


class ContestSimulator:
    """One fixed private world definition; no agent/candidate code is executed.

    Numerical constants are loaded from the adjacent JSON, but formula text
    is documentation only and is never evaluated.  `cache_token` changes with
    the definitions, numerical convention and implementation file.  External
    artifact caches must include it, rather than reusing historical DP data.
    """

    def __init__(self, world: str, *, definition_path=None):
        path = (Path(__file__).with_name("contest_world_definitions.json")
                if definition_path is None else Path(definition_path))
        raw = path.read_bytes()
        definition = json.loads(raw)
        matches = [w for w in definition["worlds"] if w["name"] == world]
        if len(matches) != 1:
            raise ValueError(f"Unknown or duplicated world: {world}")
        self.world = world
        self.definition = matches[0]
        self.parameters = self.definition["fixed_parameters"].copy()
        self.definition_version = definition["schema_version"]
        self.definition_digest = hashlib.sha256(raw).hexdigest()
        self.implementation_digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        shared_path = Path(_shared_numerics_file)
        self.numerics_implementation_digest = hashlib.sha256(
            shared_path.read_bytes() + shared_path.with_name("__init__.py").read_bytes()).hexdigest()
        self.cache_token = hashlib.sha256(json.dumps({
            "definition": self.definition_digest,
            "implementation": self.implementation_digest,
            "shared_numerics_implementation": self.numerics_implementation_digest,
            "numerics": NUMERICS_VERSION, "dt": DT, "epsilon": EPSILON,
        }, sort_keys=True).encode()).hexdigest()
        self._validate_definition()

    def _validate_definition(self):
        """Fail on stale kernels instead of silently interpreting old metadata."""
        if self.world == "Adam" and (self.definition.get("law_revision") != "adam-saturating-central-v1"
                                     or self.parameters.get("ell", 0) <= 0):
            raise ValueError("This core requires the revised Adam definition.")
        if self.world == "Tabris":
            if self.definition.get("force_magnitude") != "G*c_i*s_j*exp(-rho/lambda)/(2*pi*rho)":
                raise ValueError("This core requires the exponential Tabris definition.")
            if self.parameters["lambda"] <= 0:
                raise ValueError("The screening length must be positive.")
        if self.world == "Leliel":
            if self.parameters["n_images"] != 20 or self.parameters["R_compact"] <= 0:
                raise ValueError("The current definition requires 41 image terms.")
        if self.world in CUSTOM:
            for source in self.definition["sources"]:
                if source["response"] != 0 or not source["fixed"] or np.any(source["vel"]):
                    raise ValueError("The custom-world sources must remain fixed and nonresponding.")

    def _properties(self, n, source_properties, probe_properties):
        source = {} if source_properties is None else source_properties
        if not isinstance(source, dict):
            raise ValueError("source_properties must be an object.")
        expected_source = {"p1"} if self.world in SINGLE_CENTER else set()
        if set(source) != expected_source:
            raise ValueError(f"source_properties requires exactly {sorted(expected_source)}.")
        p1 = _finite_scalar(source["p1"], "p1") if expected_source else None
        if isinstance(probe_properties, dict):
            properties = [probe_properties] * n
        elif isinstance(probe_properties, (list, tuple)) and len(probe_properties) == n:
            properties = probe_properties
        else:
            raise ValueError("probe_properties requires an object or one object per probe.")
        key = "p2" if self.world in SINGLE_CENTER else "mass"
        values = np.empty(n, dtype=np.float64)
        for i, item in enumerate(properties):
            if not isinstance(item, dict) or set(item) != {key}:
                raise ValueError(f"Probe properties require exactly {key}.")
            values[i] = _finite_scalar(item[key], key)
        # Lilith p2 is a signed attribute mapped through -abs, not inertia.
        if self.world != "Lilith" and np.any(values <= 0):
            raise ValueError(f"{key} is inertia here and must be strictly positive.")
        return p1, values

    def _source_positions(self, t):
        if self.world in CUSTOM:
            return np.array([s["pos"] for s in self.definition["sources"]], dtype=np.float64)
        if self.world == "Sachiel":
            return np.array([[0., .5 * self.parameters["ether_alpha"] * t * t]])
        return np.zeros((1, 2), dtype=np.float64)

    def _test_acceleration(self, t, positions, p1, values, *, center_position=None):
        """Private low-overhead field evaluation after input validation."""
        p = self.parameters
        sources = (self._source_positions(t) if center_position is None
                   else np.asarray(center_position, dtype=np.float64)[None, :])
        rho, unit = _geometry(positions, sources)
        if self.world in SINGLE_CENTER:
            r = rho[:, 0]
            if self.world == "Adam":
                displacement = positions-sources[0]
                scale = np.sqrt(p["ell"]**2+np.sum(displacement*displacement,axis=1)+EPSILON**2)
                return -(p["kappa"]*p1/values/scale)[:,None]*displacement
            elif self.world == "Lilith":
                amplitude = p["k"] * abs(p1) * np.abs(values) / r**2
            elif self.world == "Tabris":
                amplitude = p["G"] * p1 * np.exp(-r / p["lambda"]) / (2 * np.pi * values * r)
            else:
                length = 2 * np.pi * p["R_compact"]
                images = np.arange(-p["n_images"], p["n_images"] + 1, dtype=np.float64)
                image_sum = np.sum(r[:, None] / (r[:, None]**2 + (images * length)**2)**1.5, axis=1)
                amplitude = p["G"] * p1 * length * image_sum / (4 * np.pi * values)
            return -amplitude[:, None] * unit[:, 0]
        if self.world in ("Sachiel", "Ramiel"):
            amplitude = p["G"] * p["anchor_source"] / (2 * np.pi * rho[:, 0])
            central = -amplitude[:, None] * unit[:, 0]
            if self.world == "Sachiel":
                return central + np.array([0., p["ether_alpha"]])
            return central + p["H"] * positions
        strength = np.array([s["source"] for s in self.definition["sources"]], dtype=np.float64)
        amplitude = p["mu"] * strength[None, :] / rho
        if self.world in ("Matriel", "Lilin"):
            amplitude *= 1 + p["eta"] * np.sin(2 * np.pi * t / p["period"] + p["phase"])
        if self.world == "Lilin":
            amplitude /= np.sqrt(1 + (rho / p["ell"])**2)
        return -np.sum(amplitude[..., None] * unit, axis=1)

    def acceleration(self, t, positions, *, source_properties=None, probe_properties=None):
        """Acceleration of independent test particles, not source bodies.

        `probe_properties` is a dictionary broadcast over N particles or a
        list of N dictionaries.  Callers must supply p1/p2 or mass explicitly.
        A source at the same position is not thereby a test particle: fixed
        source response is handled separately by background integration.
        """
        pos = _state_array(positions, "positions")
        # Instantaneous private field queries accept any finite time; public
        # experiment sample times have their own nonnegative tick validation.
        instant = _finite_scalar(t, "t")
        p1, values = self._properties(len(pos), source_properties, probe_properties)
        result = self._test_acceleration(instant, pos, p1, values)
        if not np.all(np.isfinite(result)):
            raise FloatingPointError("Nonfinite acceleration.")
        return result

    def background_initial_state(self):
        """Clean visible t=0 positions/velocities/IDs, with no hidden objects."""
        if self.world in SINGLE_CENTER:
            return {"positions": np.zeros((1, 2)), "velocities": np.zeros((1, 2)), "ids": ["N0"]}
        if self.world in CUSTOM:
            visible_sources = [s for s in self.definition["sources"] if s["visible"]]
            entries = visible_sources + self.definition["background_baseline"]["tracers"]
            return {"positions": np.array([e["pos"] for e in entries], dtype=np.float64),
                    "velocities": np.array([e["vel"] for e in entries], dtype=np.float64),
                    "ids": [e["id"] for e in entries]}
        base, p = self.definition["background_baseline"], self.parameters
        count, radius = base["ring_count"], base["ring_radius"]
        angle = np.arange(count, dtype=np.float64) * (2 * np.pi / count)
        ring = radius * np.column_stack((np.cos(angle), np.sin(angle)))
        speed2 = p["G"] * p["anchor_source"] / (2 * np.pi)
        if self.world == "Ramiel":
            speed2 -= p["H"] * radius**2
        if speed2 <= 0:
            raise ValueError("The background initial speed is not real and positive.")
        velocity = np.sqrt(speed2) * np.column_stack((-np.sin(angle), np.cos(angle)))
        return {"positions": np.vstack((np.array(base.get("anchor_initial_position", [0., 0.])), ring)),
                "velocities": np.vstack((np.array(base.get("anchor_initial_velocity", [0., 0.])), velocity)),
                "ids": [f"N{i}" for i in range(count + 1)]}

    def _background_acceleration(self, t, positions):
        if self.world in SINGLE_CENTER:
            return np.zeros_like(positions)
        # Ring and custom tracer source=0, response=mass, so all their inertias
        # cancel; the documented 1/2/4 ring pattern therefore needs no factors.
        center = positions[0] if self.world in ("Sachiel", "Ramiel") else None
        result = self._test_acceleration(t, positions, None, np.ones(len(positions)),
                                         center_position=center)
        if self.world == "Sachiel":
            result[0] = [0., self.parameters["ether_alpha"]]
        elif self.world == "Ramiel":
            # Zero response to other bodies, but not artificially pinned.
            result[0] = self.parameters["H"] * positions[0]
        else:
            source_count = sum(s["visible"] for s in self.definition["sources"])
            result[:source_count] = 0.0
        return result

    @staticmethod
    def _integrate(acceleration: Callable, positions, velocities, t_launch, duration, dt):
        """Use the exact public pure-numerical implementation for all paths.

        Formal calls retain DT; dt is kept here only for the organizer's
        convergence checks. No physics is supplied by the shared package.
        """
        return _shared_integrate(acceleration, positions, velocities,
                                 t_launch=t_launch, duration=duration, dt=dt)

    def integrate(self, positions, velocities, *, t_launch=0., duration=1.,
                  source_properties=None, probe_properties=None, dt=DT):
        """Internal full-history probe integration; dt override is diagnostic.

        It accepts no source-body state; independent probes cannot alter the
        true background or each other.  A candidate implementation must NOT
        call this private true-field function to obtain its predictions.
        """
        pos = _state_array(positions, "positions")
        p1, values = self._properties(len(pos), source_properties, probe_properties)
        if self.world not in ("Sachiel", "Ramiel"):
            return self._integrate(lambda t, x: self._test_acceleration(t, x, p1, values),
                                   pos, velocities, t_launch, duration, dt)
        # Match DP's coupled drift/kick ordering: the center participates in
        # the SAME Yoshida substages as the probes.  Analytic b(t) is correct
        # for instantaneous field queries but must not replace the substage
        # center position inside this discrete coupled-system integration.
        initial = self.background_initial_state()
        center_history = self._integrate(self._background_acceleration,
            initial["positions"][:1], initial["velocities"][:1], 0., t_launch, dt)
        center_pos = center_history["positions"][-1]
        center_vel = center_history["velocities"][-1]
        vel = _state_array(velocities, "velocities")
        if vel.shape != pos.shape:
            raise ValueError("Positions and velocities must have identical shape.")

        def coupled(t, state):
            return self._background_acceleration(t, state)

        history = self._integrate(coupled, np.vstack((center_pos, pos)),
                                  np.vstack((center_vel, vel)), t_launch, duration, dt)
        return {"times": history["times"], "positions": history["positions"][:, 1:],
                "velocities": history["velocities"][:, 1:]}

    def background(self, times, *, dt=DT):
        """Internal clean background samples at absolute global-epoch times.

        Call order does not advance physical time.  Fresh integration from
        t=0 is intentionally deterministic; a service may cache by cache_token.
        No hidden-source states or physical-role metadata are returned.
        """
        ticks = _sample_ticks(times, "times")
        actual = ticks * DT
        initial = self.background_initial_state()
        history = self._integrate(self._background_acceleration,
                                  initial["positions"], initial["velocities"],
                                  0., float(actual[-1]), dt)
        indices = np.array([_tick(t, "sample", dt=dt) for t in actual], dtype=np.int64)
        return {"times": actual, "positions": history["positions"][indices],
                "velocities": history["velocities"][indices], "ids": initial["ids"]}

    def launch(self, probes, t_launch, readout, source_properties=None, *,
               dt=DT, include_background=False):
        """Internal clean experiment, returning arrays of shape (T,N,2).

        Background data is omitted by default to avoid accidental observe
        quota bypass.  `include_background=True` is organizer diagnostics only.
        Noise, first-light caching, quota debits and world-specific frozen
        launch/time/attribute bounds belong to the future service wrapper.
        """
        if not isinstance(probes, (list, tuple)) or not 1 <= len(probes) <= 8:
            raise ValueError("A launch requires 1 to 8 probes.")
        for item in probes:
            if not isinstance(item, dict) or set(item) != {"pos", "vel", "properties"}:
                raise ValueError("Each probe requires exactly pos, vel and properties.")
        launch_tick = _tick(t_launch, "t_launch")
        offsets = _sample_ticks(readout, "readout")
        actual_launch = launch_tick * DT
        relative_times = offsets * DT
        history = self.integrate([p["pos"] for p in probes], [p["vel"] for p in probes],
            t_launch=actual_launch, duration=float(relative_times[-1]),
            source_properties=source_properties, probe_properties=[p["properties"] for p in probes], dt=dt)
        indices = np.array([_tick(t, "sample", dt=dt) for t in relative_times], dtype=np.int64)
        result = {"times": (launch_tick + offsets) * DT, "t_launch": actual_launch,
                  "readout": relative_times, "positions": history["positions"][indices],
                  "velocities": history["velocities"][indices]}
        if include_background:
            bg = self.background(result["times"], dt=dt)
            result.update(background_positions=bg["positions"], background_velocities=bg["velocities"],
                          background_ids=bg["ids"])
        return result
