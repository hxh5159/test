"""PRIVATE intake binding between an immutable image and its declared manifest.

Only docker create/cp/rm are used. No command starts the created container or
executes an image entrypoint. The copied archive is bounded and inspected in
memory; archive members are never extracted or followed as filesystem links.
"""
from __future__ import annotations

import io
import re
import subprocess
import tarfile
import threading

from contest_execution import immutable_image
from law_program_evaluation import InfrastructureError
from rift.submission import SubmissionError, manifest_digest, parse_manifest, validate_manifest


MAX_COPY_BYTES = 8 * 1024 * 1024
MAX_MANIFEST_BYTES = 1024 * 1024
DOCKER_OPERATION_TIMEOUT = 30.0  # Intake transport guard, not scientific scoring time.
_CONTAINER_ID = re.compile(r"[0-9a-f]{64}\Z")


def _docker_run(arguments, docker):
    try:
        return subprocess.run([docker, *arguments], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              check=False, timeout=DOCKER_OPERATION_TIMEOUT)
    except (OSError, subprocess.SubprocessError) as exc:
        raise InfrastructureError("Docker intake operation could not complete") from exc


def _copied_tar(container_id, docker):
    try:
        process = subprocess.Popen([docker, 'cp', container_id + ':/submission/submission.json', '-'],
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    except OSError as exc:
        raise InfrastructureError("Unable to start the Docker manifest copy") from exc
    expired = threading.Event()
    def terminate():
        expired.set()
        try: process.kill()
        except OSError: pass
    timer = threading.Timer(DOCKER_OPERATION_TIMEOUT, terminate)
    timer.daemon = True
    timer.start()
    chunks, length = [], 0
    try:
        if process.stdout is None:
            raise InfrastructureError("Docker copy supplied no archive stream")
        while True:
            chunk = process.stdout.read(min(65536, MAX_COPY_BYTES + 1 - length))
            if not chunk:
                break
            chunks.append(chunk)
            length += len(chunk)
            if length > MAX_COPY_BYTES:
                raise SubmissionError('$', 'Image manifest archive exceeds the intake size guard.', 'image_manifest_invalid')
        try:
            code = process.wait(timeout=5)
        except subprocess.TimeoutExpired as exc:
            raise InfrastructureError("Docker copy did not finish after closing its output") from exc
        if expired.is_set():
            raise InfrastructureError("Docker manifest copy exceeded the intake transport guard")
        if code != 0:
            raise InfrastructureError("Unable to copy /submission/submission.json from the image")
        return b''.join(chunks)
    finally:
        timer.cancel()
        if process.stdout is not None:
            process.stdout.close()
        if process.poll() is None:
            try:
                process.kill()
                process.wait(timeout=5)
            except (OSError, subprocess.SubprocessError):
                pass


def _manifest_from_tar(raw):
    try:
        with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
            members = archive.getmembers()
            if len(members) != 1:
                raise SubmissionError('$', 'Expected exactly one regular manifest file in the copied archive.', 'image_manifest_invalid')
            member = members[0]
            if (member.type not in (tarfile.REGTYPE, tarfile.AREGTYPE)
                    or member.name not in ('submission.json', './submission.json')
                    or not 0 < member.size <= MAX_MANIFEST_BYTES):
                raise SubmissionError('$', 'Copied manifest must be one bounded regular submission.json file.', 'image_manifest_invalid')
            stream = archive.extractfile(member)
            if stream is None:
                raise SubmissionError('$', 'Copied manifest has no file content.', 'image_manifest_invalid')
            with stream:
                content = stream.read(MAX_MANIFEST_BYTES + 1)
            if len(content) != member.size:
                raise SubmissionError('$', 'Copied manifest file is truncated.', 'image_manifest_invalid')
            return parse_manifest(content.decode('utf-8-sig'))
    except SubmissionError:
        raise
    except (tarfile.TarError, OSError, UnicodeError, ValueError, RecursionError) as exc:
        raise SubmissionError('$', 'Copied image manifest is not a valid bounded UTF-8 manifest archive.', 'image_manifest_invalid') from exc


def verify_image_manifest(image_digest, manifest, docker='docker'):
    """Return verified image/manifest identities before accepting a submission.

    ``image_digest`` is a local immutable sha256 image ID. The external manifest
    and image's embedded manifest must normalize to the same canonical digest.
    This checks their binding; it does not establish model weight provenance.
    """
    image_digest = immutable_image(image_digest)
    external = validate_manifest(manifest)
    expected = manifest_digest(external)
    if not isinstance(docker, str) or not docker:
        raise ValueError('A trusted Docker executable is required')
    created = _docker_run(['create', '--pull=never', '--network=none', '--read-only',
                           '--entrypoint=/bin/true', image_digest], docker)
    if created.returncode != 0:
        raise InfrastructureError('Unable to create an unstarted intake container from the immutable image')
    try:
        container_id = created.stdout.decode('ascii').strip()
    except (UnicodeError, AttributeError) as exc:
        raise InfrastructureError('Docker returned an invalid container identity') from exc
    if not _CONTAINER_ID.fullmatch(container_id):
        raise InfrastructureError('Docker returned an invalid container identity')
    try:
        embedded = _manifest_from_tar(_copied_tar(container_id, docker))
        actual = manifest_digest(embedded)
        if actual != expected:
            raise SubmissionError('$', 'The image manifest does not match the accepted external manifest.', 'image_manifest_mismatch')
        return {'verified': True, 'image_digest': image_digest, 'manifest_sha256': expected,
                'image_manifest_sha256': actual, 'image_manifest': embedded}
    finally:
        # Only this newly created, never-started container and its anonymous
        # volumes are removed. Caller-supplied container names are not accepted.
        removed = _docker_run(['rm', '-v', container_id], docker)
        if removed.returncode != 0:
            raise InfrastructureError('Unable to remove the unstarted intake container')


__all__ = ['verify_image_manifest']
