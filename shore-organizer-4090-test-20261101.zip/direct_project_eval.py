"""Organizer entry: evaluate the team's current project in one instance.

The explicitly chosen contest operating model pauses participant edits during
the run. This backend is not a filesystem or network isolation boundary.
Scientific scoring, paired drafts and time limits reuse the existing runner.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
from uuid import uuid4

PRIVATE = Path(__file__).resolve().parent


def _select_public_root(private, environment=None):
    """A shipped evaluator always uses its own frozen fixed integrator."""
    private = Path(private).resolve()
    if (private/'public').is_dir():
        return (private/'public').resolve()
    if (private/'rift/worker.py').is_file():
        return private  # flat organizer calibration package
    env = os.environ if environment is None else environment
    return Path(env.get('RIFT_PUBLIC_ROOT', private.parent/'DiscoverPhysics')).resolve()


PUBLIC = _select_public_root(PRIVATE)
os.environ['RIFT_PUBLIC_ROOT'] = str(PUBLIC)
sys.path.insert(0, str(PUBLIC))
sys.path.insert(0, str(PRIVATE))

from contest_execution import AgentHandle
from contest_job_runner import JobRunner, _write_private
from contest_platform import read_profile, make_world_factory
from contest_scoreboard import Scoreboard, WORLDS
from law_program_evaluation import OrganizerConfigurationError, run_law_file
from rift.submission import load_manifest, manifest_digest, SubmissionError


def _enable_child_subreaper():
    """Adopt this evaluator's orphaned descendants; never scan other jobs."""
    if sys.platform != 'linux':
        return
    import ctypes
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OrganizerConfigurationError('Cannot enable cleanup of this run\'s orphaned model processes')


def _process_identity(pid):
    """Read Linux PID start ticks so a recycled PID is never signalled."""
    try:
        raw = Path('/proc', str(pid), 'stat').read_text()
        fields = raw[raw.rfind(')')+2:].split()
        return {'state': fields[0], 'parent': int(fields[1]),
                'group': int(fields[2]), 'start': int(fields[19])}
    except (OSError, ValueError, IndexError):
        return None


def _process_children(pid):
    """Only visit this known process's tasks; no whole-machine PID scan."""
    children = set()
    try:
        tasks = list(Path('/proc', str(pid), 'task').iterdir())
    except OSError:
        return children
    for task in tasks:
        try:
            children.update(int(value) for value in (task/'children').read_text().split())
        except (OSError, ValueError):
            pass
    return children


class _OwnedProcessTree:
    """Track only this agent's descendants, including independent sessions."""
    KEY = 'SHORE_DIRECT_RUN_OWNER'

    def __init__(self, process, token):
        self.process, self.token = process, token
        self.records = {}
        self.lock = threading.Lock()
        self.finished = threading.Event()
        self.refresh()
        self.thread = threading.Thread(target=self._track, name='shore-owned-processes', daemon=True)
        self.thread.start()

    def _same_owner(self, pid):
        try:
            # Candidates here are only this evaluator's direct children, not
            # arbitrary host processes. No environment values are logged.
            target = (self.KEY+'='+self.token).encode()
            return target in Path('/proc', str(pid), 'environ').read_bytes().split(b'\0')
        except OSError:
            return False

    def refresh(self):
        with self.lock:
            pending = []
            root = _process_identity(self.process.pid)
            if root is not None and (self.process.pid not in self.records or
                    self.records[self.process.pid] == root['start']):
                self.records[self.process.pid] = root['start']
            for pid, start in list(self.records.items()):
                identity = _process_identity(pid)
                if identity is not None and identity['start'] == start:
                    pending.append(pid)
            # A naturally exited agent's setsid child may already have been
            # reparented. Subreaper adoption plus this unique inherited token
            # recovers it without touching an existing shared model service.
            for pid in _process_children(os.getpid()):
                if pid not in self.records and self._same_owner(pid):
                    identity = _process_identity(pid)
                    if identity is not None:
                        self.records[pid] = identity['start']
                        pending.append(pid)
            seen = set()
            while pending:
                parent = pending.pop()
                if parent in seen:
                    continue
                seen.add(parent)
                for child in _process_children(parent):
                    identity = _process_identity(child)
                    if identity is not None and identity['parent'] == parent:
                        self.records[child] = identity['start']
                        pending.append(child)

    def _track(self):
        while not self.finished.wait(.25):
            self.refresh()

    def _live(self):
        live = []
        with self.lock:
            records = list(self.records.items())
        for pid, start in records:
            identity = _process_identity(pid)
            if identity is None or identity['start'] != start:
                continue
            if identity['state'] == 'Z':
                if pid != self.process.pid and identity['parent'] == os.getpid():
                    try:
                        os.waitpid(pid, os.WNOHANG)
                    except (ChildProcessError, OSError):
                        pass
                continue
            live.append((pid, start))
        return live

    def _signal(self, entries, signum):
        for pid, start in entries:
            identity = _process_identity(pid)
            if identity is not None and identity['start'] == start:
                try:
                    os.kill(pid, signum)
                except ProcessLookupError:
                    pass

    def stop(self):
        try:
            self.refresh()
            initial = self._live()
            self._signal(initial, signal.SIGTERM)
            # The baseline's managed server permits 15+10 seconds for TP
            # teardown. New detached descendants are discovered and stopped.
            deadline = time.monotonic()+30
            terminated = set(initial)
            while time.monotonic() < deadline:
                self.refresh()
                live = self._live()
                if not live:
                    break
                self._signal([item for item in live if item not in terminated], signal.SIGTERM)
                terminated.update(live)
                time.sleep(.05)
            self.refresh()
            self._signal(self._live(), signal.SIGKILL)
            deadline = time.monotonic()+5
            while time.monotonic() < deadline:
                self.process.poll()  # Reap the root through its Popen owner.
                self.refresh()
                live = self._live()
                if not live:
                    break
                self._signal(live, signal.SIGKILL)
                time.sleep(.05)
            if self._live():
                raise OrganizerConfigurationError('A process owned by this evaluation could not be stopped')
        finally:
            self.finished.set()
            self.thread.join(timeout=1)


def default_profile():
    for relative in ('profiles/direct-v1-r3/profile.json', 'profiles/direct-v1-r3.json',
                     'profiles/direct-v1-r2/profile.json', 'profiles/direct-v1-r2.json',
                     'profiles/direct-v1/profile.json', 'profiles/direct-v1.json'):
        path = PRIVATE/relative
        if path.is_file():
            return path
    raise OrganizerConfigurationError('The complete organizer environment with its direct-project profile is required')


class DirectProjectBackend:
    """Approved direct host process, distinct from engineering diagnostics."""
    production_isolation = False
    official_direct_execution = True

    def __init__(self, *, agent_python=None, environment=None):
        self.agent_python = str(Path(agent_python).expanduser().absolute()) if agent_python else None
        self.environment = dict(os.environ if environment is None else environment)

    def command(self, manifest, *, project_root=None):
        command = list(manifest['entrypoint'])
        if self.agent_python:
            name = Path(command[0]).name.lower()
            if not (name.startswith('python') or name == 'py'):
                raise OrganizerConfigurationError('--agent-python requires a Python agent entrypoint')
            command[0] = self.agent_python
        elif project_root is not None and not Path(command[0]).is_absolute() and '/' in command[0]:
            command[0] = str((Path(project_root)/command[0]).expanduser().absolute())
        # Without an explicit override, preserve the actual interpreter or
        # executable named by the team, including its currently active PATH.
        if not (Path(command[0]).is_file() or shutil.which(command[0], path=self.environment.get('PATH'))):
            raise OrganizerConfigurationError('The configured agent executable is unavailable')
        return command

    def start_agent(self, manifest, *, submission_root, output_dir, log_dir, endpoint, token,
                    socket_directory=None, model_mounts=(), sdk_root=None):
        if model_mounts:
            raise OrganizerConfigurationError('Direct projects use their actual model paths, not container model mounts')
        root = Path(submission_root).resolve()
        output, logs = Path(output_dir).resolve(), Path(log_dir).resolve()
        output.mkdir(parents=True, exist_ok=True)
        logs.mkdir(parents=True, exist_ok=True)
        env = dict(self.environment)
        ownership_token = uuid4().hex
        env[_OwnedProcessTree.KEY] = ownership_token
        env.update(RIFT_CONSOLE_URL=endpoint, RIFT_SESSION_TOKEN=token,
                   RIFT_OUTPUT_DIR=str(output), PYTHONIOENCODING='utf-8',
                   PYTHONDONTWRITEBYTECODE='1')
        # Team modules/configurations resolve from this real project. The
        # official candidate worker separately uses -I and the fixed SDK.
        env['PYTHONPATH'] = os.pathsep.join([str(root), str(PUBLIC)] +
                                          ([env['PYTHONPATH']] if env.get('PYTHONPATH') else []))
        handles = [open(logs/'agent.stdout.log', 'wb'), open(logs/'agent.stderr.log', 'wb')]
        try:
            _enable_child_subreaper()
            process = subprocess.Popen(self.command(manifest, project_root=root), cwd=root, env=env,
                stdin=subprocess.DEVNULL, stdout=handles[0], stderr=handles[1],
                start_new_session=os.name != 'nt')
        except (OSError, OrganizerConfigurationError) as exc:
            for stream in handles:
                stream.close()
            if isinstance(exc, OrganizerConfigurationError):
                raise
            raise OrganizerConfigurationError('Unable to start the configured team entrypoint') from exc

        if sys.platform == 'linux':
            owner = _OwnedProcessTree(process, ownership_token)
            return AgentHandle(process, handles, stop=owner.stop)

        def stop_group():
            if os.name != 'nt':
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    return
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
                # Clean up model/tool children even if the parent exited.
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        return AgentHandle(process, handles, stop=stop_group)

    def execute_law(self, path, case, *, timeout_seconds):
        return run_law_file(path, case, timeout_seconds=timeout_seconds)


def prepare_inputs(project_root, manifest_path, profile_path, *, agent_python=None):
    project = Path(project_root).expanduser().resolve()
    if not project.is_dir():
        raise OrganizerConfigurationError('The team project directory is unavailable')
    manifest_file = Path(manifest_path).expanduser()
    if not manifest_file.is_absolute():
        manifest_file = project/manifest_file
    manifest = load_manifest(manifest_file)
    profile_file = Path(profile_path).resolve()
    profile = read_profile(profile_file, require_released=True)
    if profile.get('execution_mode') != 'direct_project':
        raise OrganizerConfigurationError('Use the organizer-approved direct-project profile')
    if profile.get('policies', {}).get('hidden_run_artifacts') != 'organizer_retained_no_contest_export':
        raise OrganizerConfigurationError('Hidden-run artifacts must stay with the organizer')
    if agent_python and not Path(agent_python).is_absolute():
        agent_python = project/agent_python
    backend = DirectProjectBackend(agent_python=agent_python)
    backend.command(manifest, project_root=project)
    for model in manifest['models']:
        path = Path(model['path']).expanduser()
        if not path.is_absolute():
            path = project/path
        if not path.exists():
            raise OrganizerConfigurationError('A declared model or training artifact is missing')
    # Verify every physics/reference identity before starting any team process.
    factory = make_world_factory(profile)
    for world in WORLDS:
        factory(world)
    return project, manifest_file.resolve(), manifest, profile, backend, factory


def evaluate(project_root, manifest_path, output, *, profile_path=None, agent_python=None, check_only=False):
    project, manifest_file, manifest, profile, backend, factory = prepare_inputs(
        project_root, manifest_path, profile_path or default_profile(), agent_python=agent_python)
    if check_only:
        return {'status': 'direct_project_inputs_checked', 'execution_mode': 'direct_project',
                'team_id': manifest['team_id'], 'submission_id': manifest['submission_id'],
                'world_count': len(profile.get('evaluation_worlds', WORLDS)), 'actual_model_loaded': False,
                'file_isolation_claimed': False}
    root = Path(output).expanduser().resolve()
    if root.exists():
        raise OrganizerConfigurationError('Choose a new output directory; existing runs are never overwritten')
    root.mkdir(parents=True, exist_ok=False)
    private = root/'private'
    private.mkdir(mode=0o700)
    # Explicit permissions apply to our new run, never chmod a team project.
    if os.name != 'nt':
        os.chmod(root, 0o700)
    accepted = datetime.now(timezone.utc).isoformat()
    board = Scoreboard(private/'scores.sqlite', scope='official',
                       evaluation_worlds=profile.get('evaluation_worlds', WORLDS))
    receipt = board.enqueue_direct(manifest, project_root=project, accepted_at=accepted,
        private_spec={'manifest_file': str(manifest_file), 'agent_python': backend.agent_python,
                      'execution_mode': 'direct_project', 'model_paths': [item['path'] for item in manifest['models']]})
    _write_private(private/'acceptance.json', {'job_id': receipt['job_id'], 'accepted_at': accepted,
        'manifest_sha256': manifest_digest(manifest), 'project_root': str(project),
        'execution_mode': 'direct_project', 'file_isolation_claimed': False,
        'models_verified': 'declared paths exist; this is not model provenance or generation verification'})
    with JobRunner(board, backend, factory, run_root=private/'runs', profile=profile) as runner:
        result = runner.run_next('direct-project-worker')
    summary = {key: result[key] for key in ('job_id','team_id','accepted_at','state','total_score','world_scores')
               if key in result}
    summary.update(schema_version='shore-direct-feedback-1.0', execution_mode='direct_project',
                   submission_id=manifest['submission_id'])
    if summary['state'] != 'completed':
        summary['error'] = 'Organizer execution failed; private diagnostics are retained for repair and re-evaluation.'
    _write_private(root/'summary.json', summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, default=Path.cwd())
    parser.add_argument('--manifest', type=Path, default=Path('submission.json'))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--profile', type=Path)
    parser.add_argument('--agent-python', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args(argv)
    fresh_output = not args.output.expanduser().resolve().exists()
    try:
        result = evaluate(args.project_root, args.manifest, args.output,
            profile_path=args.profile, agent_python=args.agent_python, check_only=args.check_only)
    except (OSError, ValueError, RuntimeError) as exc:
        if fresh_output and not args.check_only:
            try:
                diagnostic_root = args.output.expanduser().resolve()
                diagnostic_root.mkdir(parents=True, exist_ok=True)
                private = diagnostic_root/'private'
                private.mkdir(mode=0o700, exist_ok=True)
                if os.name != 'nt':
                    os.chmod(diagnostic_root, 0o700)
                _write_private(private/('startup_error-'+uuid4().hex+'.private.json'),
                    {'error_type': type(exc).__name__, 'error': str(exc),
                     'traceback': traceback.format_exc(), 'scientific_score_published': False})
            except OSError:
                pass
        # Do not publish tracebacks, reference paths or source-derived messages.
        result = {'status': 'startup_or_format_error', 'error':
            ('Invalid submission manifest: '+exc.message) if isinstance(exc, SubmissionError)
            else str(exc) if isinstance(exc, OrganizerConfigurationError)
            else 'Check the project, interpreter, model paths and matching complete organizer profile.'}
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result.get('state', 'completed') == 'completed' else 2


if __name__ == '__main__':
    raise SystemExit(main())
