"""PRIVATE organizer smoke check; never starts a scientific trial on import."""
from __future__ import annotations

import argparse
import json
import time
from urllib.error import URLError
from urllib.request import ProxyHandler, Request, build_opener


def check_service(base_url, model, *, timeout=120., wait_seconds=0., opener=None):
    base = base_url.rstrip("/")
    if not base.endswith("/v1"):
        raise ValueError("Use the vLLM API base URL ending in /v1.")
    transport = opener or build_opener(ProxyHandler({}))

    def request(url, body=None):
        raw = None if body is None else json.dumps(body).encode("utf-8")
        call = Request(url, data=raw, headers={"Content-Type": "application/json"})
        with transport.open(call, timeout=timeout) as response:
            return json.loads(response.read(8*1024*1024))

    deadline = time.monotonic() + wait_seconds
    while True:
        try:
            advertised = request(base + "/models")
            break
        except URLError:
            if time.monotonic() >= deadline:
                raise RuntimeError("vLLM is not ready. Read its log; check the model before starting discovery.") from None
            time.sleep(min(5., max(0., deadline-time.monotonic())))
    ids = [item.get("id") for item in advertised.get("data", [])]
    if model not in ids:
        raise ValueError(f"Expected model {model!r} is not advertised. Available IDs: {ids!r}")
    messages = [{"role": "user", "content": 'Return exactly this JSON object: {"ok": true}'}]
    tokenized = request(base[:-3] + "/tokenize", {
        "model": model, "messages": messages, "add_generation_prompt": True,
        "return_token_strs": False, "chat_template_kwargs": {"enable_thinking": False}})
    if type(tokenized.get("count")) is not int or tokenized["count"] <= 0:
        raise ValueError("The server did not provide a valid chat-template token count.")
    # Disable thinking only for this connectivity check. Scientific trials keep
    # their documented, common reasoning configuration.
    result = request(base + "/chat/completions", {
        "model": model, "messages": messages, "temperature": 0,
        "max_tokens": 128, "stream": False,
        "response_format": {"type": "json_object"},
        "chat_template_kwargs": {"enable_thinking": False}})
    content = result["choices"][0]["message"].get("content")
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Chat endpoint returned no nonempty final content.")
    if result["choices"][0].get("finish_reason") == "length" or json.loads(content) != {"ok": True}:
        raise ValueError("The smoke JSON response was truncated or did not match the requested object.")
    return {"scope": "organizer_only_connectivity_check", "model_requested": model,
        "server_model": result.get("model"), "tokenize_count": tokenized["count"],
        "max_model_len": tokenized.get("max_model_len"), "content": content,
        "scientific_trials_started": 0, "model_identity_independently_verified": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000/v1")
    parser.add_argument("--model", required=True)
    parser.add_argument("--timeout", type=float, default=120.)
    parser.add_argument("--wait-seconds", type=float, default=0.)
    args = parser.parse_args(argv)
    print(json.dumps(check_service(args.base_url, args.model,
        timeout=args.timeout, wait_seconds=args.wait_seconds), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
