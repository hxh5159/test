"""Hidden-run artifact export is disabled; public development is separate."""
from __future__ import annotations
import argparse
import json
import sys
from contest_scoreboard import QueueError
ALLOWED_FILES=()
def export_own(board,job_id,team_id,run_root,output,*,include_agent_output=False):
    raise QueueError('Hidden-run artifact export is disabled during the competition; only approved score feedback is available')
def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('db','job-id','team-id','run-root','output'):parser.add_argument('--'+name)
    parser.add_argument('--include-agent-output',action='store_true')
    parser.parse_args(argv)
    print(json.dumps({'ok':False,'code':'hidden_artifact_export_disabled',
        'error':'赛中不归还隐藏运行的观测、对话、候选、日志、记忆或更新权重；仅提供规定成绩反馈。'},ensure_ascii=False),file=sys.stderr)
    return 2
if __name__=='__main__':raise SystemExit(main())
