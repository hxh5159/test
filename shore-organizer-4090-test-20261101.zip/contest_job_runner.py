"""PRIVATE complete-submission orchestration, not a contestant framework.

The real console and calibration remain in the trusted parent. Each world has
its own authenticated session, output directory and paired artifact store.
Only the independent candidate backend evaluates frozen law.py source. Local
execution with HTTP is also supported by the explicitly approved direct-project
backend. Ordinary LocalDiagnosticBackend remains internal-validation only.
"""
from __future__ import annotations

import copy
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import time
from uuid import uuid4

PRIVATE = Path(__file__).resolve().parent
PUBLIC = Path(os.environ.get('RIFT_PUBLIC_ROOT', PRIVATE.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0, str(PUBLIC))

from contest_console_service import (ConsoleSession, ConsoleService,
                                     ConsoleInfrastructureError,
                                     make_http_server, make_unix_server)
from contest_scoreboard import WORLDS, QueueError, validate_evaluation_worlds
from law_program_evaluation import (OrganizerConfigurationError, InfrastructureError,
                                    evaluate_frozen_submission)
from rift.submission import manifest_digest, validate_manifest


def _positive(value, name):
    try:
        valid = (not isinstance(value, bool) and isinstance(value, (int, float))
                 and math.isfinite(value) and value > 0)
    except OverflowError:
        valid = False
    if not valid:
        raise OrganizerConfigurationError(name+' must be explicitly positive and finite')
    return float(value)


def _write_private(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name('.'+path.name+'.'+uuid4().hex+'.tmp')
    with temporary.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, sort_keys=True,
                                 allow_nan=False, indent=2)+'\n').encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


class JobRunner:
    """Consume one accepted complete configured-world submission at a time.

    world_factory(world) is trusted and returns (private_console, calibration).
    profile supplies startup_seconds/candidate_timeout_seconds/shutdown_seconds
    and profile_id/status explicitly. They are organizer settings, not new
    scientific rules or defaults that silently become contest limits.
    """

    def __init__(self, scoreboard, backend, world_factory, *, run_root, profile,
                 model_mounts=(), require_released=True, clock=time.monotonic,
                 poll_seconds=.02):
        if not isinstance(profile, dict):
            raise OrganizerConfigurationError('An explicit organizer runtime profile is required')
        self.profile = copy.deepcopy(profile)
        try:
            self.worlds = validate_evaluation_worlds(profile.get('evaluation_worlds', WORLDS))
        except QueueError as exc:
            raise OrganizerConfigurationError(str(exc)) from exc
        if getattr(scoreboard, 'worlds', None) != self.worlds:
            raise OrganizerConfigurationError('Queue and runtime profile must use the same evaluation worlds')
        for key in ('profile_id', 'status'):
            if not isinstance(profile.get(key), str) or not profile[key]:
                raise OrganizerConfigurationError('Profile '+key+' is required')
        if profile['status'] not in ('internal_validation', 'released'):
            raise OrganizerConfigurationError('Unsupported organizer profile status')
        if require_released and (profile['status'] != 'released' or profile.get('release_approved') is not True):
            raise OrganizerConfigurationError('This profile has not been released; explicitly opt into internal validation')
        if require_released:
            if (profile.get('runtime_limits_approved') is not True
                    or profile.get('domains_and_validation_approved') is not True):
                raise OrganizerConfigurationError('Official runtime limits and domains must be explicitly approved')
            policies=profile.get('policies',{})
            if (policies.get('cross_submission_memory')!='allow_own_legal_artifacts'
                    or policies.get('deadline')!='accepted_at'
                    or policies.get('tie_break')!='weighted_saving_ascending'):
                raise OrganizerConfigurationError('Official runner must use the confirmed persistence and deadline policies')
        self.expected_scope = 'official' if require_released else 'internal_validation'
        if getattr(scoreboard, 'scope', None) != self.expected_scope:
            raise OrganizerConfigurationError('Queue scope does not match the explicitly selected runner mode')
        direct = (getattr(backend, 'official_direct_execution', False)
                  and profile.get('execution_mode') == 'direct_project')
        if self.expected_scope == 'official' and not (getattr(backend, 'production_isolation', False) or direct):
            raise OrganizerConfigurationError('Official queues cannot use diagnostic local execution')
        self.startup_seconds = _positive(profile.get('startup_seconds'), 'startup_seconds')
        self.candidate_seconds = _positive(profile.get('candidate_timeout_seconds'), 'candidate_timeout_seconds')
        self.shutdown_seconds = _positive(profile.get('shutdown_seconds'), 'shutdown_seconds')
        self.poll_seconds = _positive(poll_seconds, 'poll_seconds')
        if not callable(world_factory) or not callable(clock):
            raise OrganizerConfigurationError('Trusted world factory and monotonic clock required')
        if not hasattr(backend, 'production_isolation'):
            raise OrganizerConfigurationError('An explicit execution backend is required')
        self.scoreboard, self.backend, self.world_factory = scoreboard, backend, world_factory
        self.run_root = Path(run_root).resolve()
        self.run_root.mkdir(parents=True, exist_ok=True)
        self.model_mounts, self.clock = tuple(model_mounts), clock
        self.service = ConsoleService()
        self._server = self._server_thread = self._socket_temp = None
        self.endpoint = self.socket_directory = None
        self._run_lock = threading.Lock()

    def start(self):
        if self._server is not None:
            return self
        if self.backend.production_isolation:
            if sys.platform != 'linux':
                raise OrganizerConfigurationError('Production runner requires Linux Unix-domain transport')
            # A short, newly owned path avoids AF_UNIX's small path limit. This
            # directory contains only the socket, never truth/logs/calibration.
            self._socket_temp = tempfile.TemporaryDirectory(prefix='rift-console-')
            self.socket_directory = Path(self._socket_temp.name).resolve()
            os.chmod(self.socket_directory, 0o750)
            socket_path = self.socket_directory/'console.sock'
            self._server = make_unix_server(self.service, socket_path)
            gid = getattr(self.backend, 'gid', None)
            if gid is not None and hasattr(os, 'chown'):
                try:
                    os.chown(self.socket_directory, -1, gid)
                    os.chown(socket_path, -1, gid)
                except OSError as exc:
                    self._server.server_close()
                    self._server = None
                    self._socket_temp.cleanup()
                    self._socket_temp = None
                    raise OrganizerConfigurationError('Cannot set the designated socket group for the agent') from exc
            self.endpoint = 'unix:///run/rift/console.sock'
        else:
            self._server = make_http_server(self.service, host='127.0.0.1', port=0)
            self.endpoint = 'http://127.0.0.1:%d/v1/console' % self._server.server_address[1]
        self._server_thread = threading.Thread(target=self._server.serve_forever,
            kwargs={'poll_interval': self.poll_seconds}, name='rift-private-console', daemon=True)
        self._server_thread.start()
        return self

    def close(self):
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server_thread.join(timeout=self.shutdown_seconds)
            self._server = self._server_thread = None
        if self._socket_temp is not None:
            # This is the newly created, owned socket-only TemporaryDirectory.
            self._socket_temp.cleanup()
            self._socket_temp = None
        self.endpoint = self.socket_directory = None

    def __enter__(self):
        return self.start()

    def __exit__(self, *_):
        self.close()

    def _job_identity(self, job, worker_id):
        if (not isinstance(job, dict) or not re.fullmatch(r'[A-Za-z0-9_-]+', str(job.get('job_id', '')))
                or job.get('state') != 'running' or job.get('worker_id') != worker_id
                or job.get('execution_scope') != self.expected_scope):
            raise OrganizerConfigurationError('A claimed job owned by this worker is required')
        manifest = validate_manifest(job.get('manifest'))
        if manifest_digest(manifest) != job.get('manifest_sha256'):
            raise InfrastructureError('Accepted manifest identity does not match its frozen digest')
        if job.get('team_id') != manifest['team_id']:
            raise InfrastructureError('Accepted team identity does not match its manifest')
        if self.backend.production_isolation and getattr(self.backend, 'agent_image', None) != job.get('image_digest'):
            raise OrganizerConfigurationError('Backend must execute the accepted immutable image')
        if getattr(self.backend, 'official_direct_execution', False) and job.get('execution_mode') != 'direct_project':
            raise OrganizerConfigurationError('Direct execution requires an accepted direct-project job')
        return manifest

    @staticmethod
    def _watchdog_snapshot(session):
        read = getattr(session, 'watchdog_snapshot', None)
        if not callable(read):
            raise OrganizerConfigurationError('Session must expose the nonblocking watchdog_snapshot API')
        return read()

    def _finalize(self, session, reason):
        event, result = threading.Event(), {}
        def finish():
            try:
                session.close(reason)
                session.raise_if_failed()
                result.update(record=session.finalized_record(), mission=session.public_mission(),
                              frozen=session.frozen_submission())
            except BaseException as exc:
                result['error'] = exc
            finally:
                event.set()
        # A stuck private simulator must not pin the trusted worker forever.
        # It is an infrastructure failure, not a zero-score candidate result.
        thread = threading.Thread(target=finish, name='rift-session-finalize', daemon=True)
        thread.start()
        if not event.wait(timeout=self.shutdown_seconds):
            raise InfrastructureError('Private session did not finalize within the explicit organizer shutdown guard')
        if 'error' in result:
            raise InfrastructureError('Private session failed during finalization') from result['error']
        return result

    def _world(self, job, manifest, world, directory):
        console, calibration = self.world_factory(world)
        if not isinstance(calibration, dict) or calibration.get('world') != world:
            raise OrganizerConfigurationError('Trusted world factory returned a mismatched calibration')
        directory.mkdir(parents=True, exist_ok=False)
        session = ConsoleSession(console, directory/'store', job_id=job['job_id'],
                                 clock=self.clock, wall_seconds=600)
        token = self.service.register(session)
        handle, reason = None, 'agent_exited'
        try:
            specification = job.get('private_spec', {})
            if not isinstance(specification, dict):
                raise OrganizerConfigurationError('Malformed trusted private job specification')
            submission_root = specification.get('submission_root')
            if submission_root is None:
                if not self.backend.production_isolation:
                    raise OrganizerConfigurationError('Diagnostic execution requires a trusted submission_root')
                submission_root = directory/'unused-image-input'
            launched_at = self.clock()
            handle = self.backend.start_agent(manifest, submission_root=submission_root,
                output_dir=directory/'output', log_dir=directory/'logs', endpoint=self.endpoint,
                token=token, socket_directory=self.socket_directory, model_mounts=self.model_mounts)
            while True:
                snapshot = self._watchdog_snapshot(session)
                if snapshot['failed'] or snapshot['state'] == 'FAILED':
                    reason = 'infrastructure_error'
                    break
                if snapshot['state'] == 'CLOSED':
                    reason = 'submitted_or_closed'
                    break
                if snapshot['started_at'] is None:
                    if self.clock()-launched_at >= self.startup_seconds:
                        reason = 'startup_timeout'
                        break
                elif snapshot['deadline_remaining'] <= 0:
                    reason = 'timeout'
                    break
                exit_code = handle.poll()
                if exit_code is not None:
                    if self.backend.production_isolation and exit_code == 125:
                        raise InfrastructureError('Official agent container failed to start')
                    reason = 'agent_exited'
                    break
                time.sleep(self.poll_seconds)
            handle.stop()
            handle = None
            finalized = self._finalize(session, reason)
            record, mission, frozen = finalized['record'], finalized['mission'], finalized['frozen']
            if not isinstance(record, dict) or record.get('infrastructure_failed'):
                raise InfrastructureError('The private session has no valid finalization record')
            if mission is not None and mission.get('world_id') != world:
                raise OrganizerConfigurationError('Public mission and trusted job world do not agree')
            _write_private(directory/'session.json', record)
            if mission is not None:
                _write_private(directory/'mission.json', mission)
            if frozen is None:
                score = {'world': world, 'total': 0., 'saving': 0., 'has_valid_submission': False,
                         'end_reason': record.get('reason')}
            else:
                if mission is None:
                    raise InfrastructureError('Frozen artifacts exist without a public mission')
                score = evaluate_frozen_submission(frozen, mission, calibration, record['energy_used'],
                    timeout_seconds=self.candidate_seconds, executor=self.backend.execute_law)
                score['has_valid_submission'] = True
                report = session.report_bytes()
                if report is not None:
                    (directory/'report.md').write_bytes(report)
            _write_private(directory/'score.private.json', score)
            # Hidden-run observations, dialogues, generated law/claims, logs,
            # memories and model updates remain in the private attempt only.
            # Public development artifacts are managed by its separate driver.
            if mission is not None:
                _write_private(directory/'archive.private.json', session.dispatch('archive', {}))
            return score
        finally:
            self.service.revoke(token)
            if handle is not None:
                handle.stop()

    def _run_claimed(self, job, worker_id):
        attempt = None
        try:
            manifest = self._job_identity(job, worker_id)
            self.start()
            attempt = self.run_root/job['job_id']/('attempt-'+uuid4().hex)
            attempt.mkdir(parents=True, exist_ok=False)
            _write_private(attempt/'job.json', {
                'job_id': job['job_id'], 'team_id': job['team_id'],
                'manifest': manifest, 'manifest_sha256': job['manifest_sha256'],
                'image_digest': job.get('image_digest') or None, 'accepted_at': job['accepted_at'],
                'execution_mode': job.get('execution_mode', 'container'),
                'profile': self.profile, 'production_isolation': self.backend.production_isolation,
                'world_order': list(self.worlds), 'persistence_policy': 'allow_own_legal_artifacts',
            })
            results = {}
            for world in self.worlds:
                results[world] = self._world(job, manifest, world, attempt/world)
            _write_private(attempt/'results.private.json', results)
            public = self.scoreboard.complete(job['job_id'],
                {world: results[world]['total'] for world in self.worlds}, worker_id=worker_id,
                world_savings={world: results[world]['saving'] for world in self.worlds})
            # The scoreboard transaction is the authoritative public result.
            # Do not fail a completed score because a redundant export failed.
            return public
        except Exception as exc:
            if attempt is not None:
                try:
                    _write_private(attempt/'infrastructure_error.private.json', {
                        'type': type(exc).__name__, 'message': str(exc),
                        'note': 'No partial total is published; repair/re-evaluate this immutable submission.'})
                except OSError:
                    pass  # Database failure state still must be recorded.
            self.scoreboard.fail_infrastructure(job['job_id'], worker_id=worker_id,
                                               private_error=type(exc).__name__+': '+str(exc))
            return self.scoreboard.status(job['job_id'], team_id=job['team_id'])

    def run_job(self, job, *, worker_id):
        """Trusted-worker entry; callers normally use run_next()."""
        if (not isinstance(job, dict) or job.get('state') != 'running' or job.get('worker_id') != worker_id
                or job.get('execution_scope') != self.expected_scope):
            raise OrganizerConfigurationError('A claimed job owned by this worker is required')
        with self._run_lock:
            return self._run_claimed(job, worker_id)

    def run_next(self, worker_id='worker-1'):
        with self._run_lock:
            job = self.scoreboard.claim_next(worker_id)
            if job is None:
                return None
            return self._run_claimed(job, worker_id)


__all__ = ['JobRunner']
