"""Organizer queue daemon. Every accepted job is still one full evaluation."""
from __future__ import annotations
import argparse
import math
import time

from contest_platform import main as run_platform


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,add_help=False)
    parser.add_argument('--idle-seconds',type=float,default=5.)
    parser.add_argument('--max-iterations',type=int,help='Engineering/service guard, never an LLM or experiment limit')
    options,remaining=parser.parse_known_args(argv)
    if not math.isfinite(options.idle_seconds) or options.idle_seconds<=0:
        raise ValueError('idle-seconds must be positive and finite')
    if options.max_iterations is not None and options.max_iterations<=0:
        raise ValueError('max-iterations must be positive')
    if '--help' in remaining or '-h' in remaining:
        parser.print_help()
        print('\nRemaining arguments are passed to contest_platform.py work-once.\n')
        return run_platform(['work-once','--help'])
    count=0
    try:
        while options.max_iterations is None or count<options.max_iterations:
            # work-once atomically claims at most one job. A completed or
            # failed job keeps its immutable accepted identity and full score.
            status=run_platform(['work-once',*remaining])
            if status:return status
            count+=1
            if options.max_iterations is None or count<options.max_iterations:
                time.sleep(options.idle_seconds)
    except KeyboardInterrupt:
        return 130
    return 0


if __name__=='__main__':raise SystemExit(main())
