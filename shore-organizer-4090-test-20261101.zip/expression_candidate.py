"""Private safe expression proposals and public-data parameter fitting.

Expressions are interpreted by a strict AST allowlist, never Python eval/exec.
No true simulator, world definition, world-ID dispatch, hidden validation or
preselected scientific model family is imported here. A proposing model must
supply the acceleration expression. Its at-most-five constants are fitted
only to previously obtained public short-trajectory velocity records.
"""
from __future__ import annotations

import ast
import copy
import math
import os
from pathlib import Path
import sys
import time
import numpy as np
from scipy.optimize import least_squares
from scipy.special import k1

try:
    from rift_numerics.rollout import rollout, sample_indices
except ModuleNotFoundError as exc:
    if exc.name!='rift_numerics':raise
    configured=os.environ.get('RIFT_PUBLIC_ROOT')
    root=Path(configured).expanduser().resolve() if configured else Path(__file__).resolve().parent.parent/'DiscoverPhysics'
    sys.path.insert(0,str(root))
    from rift_numerics.rollout import rollout, sample_indices

SCHEMA='safe-acceleration-expression-1.0.0'
EPS=.05
PARAMETER_NAMES=frozenset(f'p{i}' for i in range(5))
VARIABLES=frozenset(('x','y','vx','vy','t','cx','cy','dx','dy','r','rho','eps','pi','e',
                     'source_ratio','probe_ratio'))
_FUNCTIONS={
    'exp':(np.exp,1),'log':(np.log,1),'sqrt':(np.sqrt,1),'sin':(np.sin,1),
    'cos':(np.cos,1),'tanh':(np.tanh,1),'abs':(np.abs,1),'k1':(k1,1),
    'minimum':(np.minimum,2),'maximum':(np.maximum,2),'where':(np.where,3),
    'clip':(np.clip,3),'hypot':(np.hypot,2),'arctan':(np.arctan,1),
    'arctan2':(np.arctan2,2),'log1p':(np.log1p,1),'expm1':(np.expm1,1),
}
_BIN={ast.Add:np.add,ast.Sub:np.subtract,ast.Mult:np.multiply,
      ast.Div:np.divide,ast.Pow:np.power}
_CMP={ast.Lt:np.less,ast.LtE:np.less_equal,ast.Gt:np.greater,
      ast.GtE:np.greater_equal,ast.Eq:np.equal,ast.NotEq:np.not_equal}


def _finite(value,label):
    if isinstance(value,(bool,str,bytes)) or np.ndim(value)!=0:
        raise ValueError(label+' must be a finite real scalar')
    result=float(value)
    if not math.isfinite(result):raise ValueError(label+' must be finite')
    return result


def _qualified(node):
    if isinstance(node,ast.Name):return node.id
    if isinstance(node,ast.Attribute):return _qualified(node.value)+'.'+node.attr
    raise ValueError('Only whitelisted mathematical function names are callable')


def _function_name(node):
    name=_qualified(node)
    parts=name.split('.')
    if len(parts)==1 and name in _FUNCTIONS:return name
    if len(parts)==2 and parts[0] in ('np','numpy','math') and parts[1] in _FUNCTIONS:return parts[1]
    if name in ('special.k1','scipy.special.k1'):return 'k1'
    raise ValueError('Function is not allowed: '+name)


class SafeExpression:
    """Bounded arithmetic AST with vector NumPy evaluation and no Python exec."""
    def __init__(self,text,names):
        if not isinstance(text,str) or not text or len(text)>2048:
            raise ValueError('Expression must contain 1..2048 characters')
        try:self.tree=ast.parse(text,mode='eval').body
        except SyntaxError as exc:raise ValueError('Invalid mathematical expression') from exc
        if len(list(ast.walk(self.tree)))>384:raise ValueError('Expression AST is too large')
        self.names=frozenset(names)
        self.used=set()
        self._validate(self.tree,0)

    def _validate(self,node,depth):
        if depth>32:raise ValueError('Expression is too deeply nested')
        if isinstance(node,ast.Constant):
            _finite(node.value,'Constant');return
        if isinstance(node,ast.Name):
            if node.id not in self.names:raise ValueError('Unknown variable: '+node.id)
            self.used.add(node.id);return
        if isinstance(node,ast.BinOp) and type(node.op) in _BIN:
            self._validate(node.left,depth+1);self._validate(node.right,depth+1);return
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            self._validate(node.operand,depth+1);return
        if isinstance(node,ast.Call):
            name=_function_name(node.func)
            if node.keywords or len(node.args)!=_FUNCTIONS[name][1]:
                raise ValueError('Mathematical call has an unsupported signature')
            for arg in node.args:self._validate(arg,depth+1)
            return
        if isinstance(node,ast.Compare) and all(type(op) in _CMP for op in node.ops):
            self._validate(node.left,depth+1)
            for value in node.comparators:self._validate(value,depth+1)
            return
        if isinstance(node,ast.BoolOp) and isinstance(node.op,(ast.And,ast.Or)):
            for value in node.values:self._validate(value,depth+1)
            return
        if isinstance(node,ast.IfExp):
            for value in (node.test,node.body,node.orelse):self._validate(value,depth+1)
            return
        if isinstance(node,ast.Attribute) and _qualified(node) in ('np.pi','numpy.pi','math.pi','np.e','numpy.e','math.e'):
            return
        raise ValueError('Unsupported expression syntax: '+type(node).__name__)

    def _evaluate(self,node,env):
        if isinstance(node,ast.Constant):return float(node.value)
        if isinstance(node,ast.Name):return env[node.id]
        if isinstance(node,ast.BinOp):return _BIN[type(node.op)](self._evaluate(node.left,env),self._evaluate(node.right,env))
        if isinstance(node,ast.UnaryOp):
            value=self._evaluate(node.operand,env)
            return -value if isinstance(node.op,ast.USub) else value
        if isinstance(node,ast.Call):
            return _FUNCTIONS[_function_name(node.func)][0](*[self._evaluate(v,env) for v in node.args])
        if isinstance(node,ast.Compare):
            left=self._evaluate(node.left,env);result=True
            for op,right_node in zip(node.ops,node.comparators):
                right=self._evaluate(right_node,env)
                result=np.logical_and(result,_CMP[type(op)](left,right));left=right
            return result
        if isinstance(node,ast.BoolOp):
            fn=np.logical_and if isinstance(node.op,ast.And) else np.logical_or
            values=[self._evaluate(v,env) for v in node.values]
            result=values[0]
            for value in values[1:]:result=fn(result,value)
            return result
        if isinstance(node,ast.IfExp):
            return np.where(self._evaluate(node.test,env),self._evaluate(node.body,env),self._evaluate(node.orelse,env))
        if isinstance(node,ast.Attribute):return np.pi if node.attr=='pi' else np.e
        raise ValueError('Invalid AST')

    def __call__(self,env):
        with np.errstate(all='ignore'):
            return self._evaluate(self.tree,env)


def _parameters(values):
    if not isinstance(values,dict) or len(values)>5 or not set(values)<=PARAMETER_NAMES:
        raise ValueError('parameters must be an object of at most five p0..p4 scalars')
    return {name:_finite(value,name) for name,value in values.items()}


class ExpressionCandidate:
    """Pure mathematical prediction using a fixed proposal and known bindings."""
    def __init__(self,model):
        self.model=copy.deepcopy(model)
        if self.model.get('schema_version')!=SCHEMA:raise ValueError('Unknown expression candidate schema')
        self.parameters=_parameters(self.model.get('parameters',{}))
        names=VARIABLES|set(self.parameters)
        self.ax=SafeExpression(self.model['ax'],names)
        self.ay=SafeExpression(self.model['ay'],names)
        center_accel=self.model.get('center_accel')
        if center_accel is not None:
            if not isinstance(center_accel,list) or len(center_accel)!=2:raise ValueError('center_accel requires two expressions')
            self.center_axes=[SafeExpression(v,set(self.parameters)|{'pi','e'}) for v in center_accel]
        else:self.center_axes=None
        bindings=self.model['bindings']
        for key in ('center_position','center_velocity'):
            value=np.asarray(bindings[key],dtype=float)
            if value.shape!=(2,) or not np.isfinite(value).all():raise ValueError('Invalid known center binding')
        for key in ('source_default','probe_default'):
            if _finite(bindings[key],key)<=0:raise ValueError('Default attribute must be positive')

    def to_dict(self):return copy.deepcopy(self.model)

    @classmethod
    def from_dict(cls,model):return cls(model)

    def center_acceleration(self):
        if self.center_axes is None:return np.zeros(2)
        env={**self.parameters,'pi':np.pi,'e':np.e}
        result=np.array([_finite(expr(env),'center acceleration') for expr in self.center_axes])
        return result

    def acceleration(self,t,positions,velocities=None,*,source_properties=None,probe_properties=None,center_position=None):
        x=np.asarray(positions,dtype=float)
        if x.ndim!=2 or x.shape[1]!=2:raise ValueError('Positions must have shape(N,2)')
        v=np.zeros_like(x) if velocities is None else np.asarray(velocities,dtype=float)
        if v.shape!=x.shape:raise ValueError('Velocity shape mismatch')
        bindings=self.model['bindings']
        center=np.asarray(bindings['center_position'],dtype=float)
        if center_position is not None:center=np.asarray(center_position,dtype=float)
        elif self.center_axes is not None:
            center=center+np.asarray(bindings['center_velocity'])*t+.5*self.center_acceleration()*t*t
        dx=x[:,0]-center[0];dy=x[:,1]-center[1]
        radius=np.hypot(dx,dy)
        source=source_properties or {}
        skey=bindings.get('source_key')
        source_ratio=float(source[skey])/bindings['source_default'] if skey else 1.
        props=probe_properties if isinstance(probe_properties,list) else [probe_properties]*len(x)
        pkey=bindings.get('probe_key')
        probe_ratio=np.array([float(q[pkey])/bindings['probe_default'] for q in props]) if pkey else np.ones(len(x))
        env={**self.parameters,'x':x[:,0],'y':x[:,1],'vx':v[:,0],'vy':v[:,1],
             't':float(t),'cx':center[0],'cy':center[1],'dx':dx,'dy':dy,'r':radius,
             'rho':np.sqrt(radius*radius+EPS*EPS),'eps':EPS,'pi':np.pi,'e':np.e,
             'source_ratio':source_ratio,'probe_ratio':probe_ratio}
        ax=np.broadcast_to(np.asarray(self.ax(env),dtype=float),(len(x),))
        ay=np.broadcast_to(np.asarray(self.ay(env),dtype=float),(len(x),))
        result=np.column_stack([ax,ay])
        if not np.isfinite(result).all():raise FloatingPointError('Expression acceleration is nonfinite')
        return result

    def predict(self,case):
        probes=case['probes'];source=case.get('source_properties',{})
        props=[q['properties'] for q in probes]
        x=np.array([q['pos'] for q in probes],dtype=float)
        v=np.array([q['vel'] for q in probes],dtype=float)
        indices=sample_indices(case['readout'])
        start=float(case.get('t_launch',0.));duration=float(case['readout'][-1])
        # The published callback signature receives positions. Expressions that
        # depend on velocity cannot use that interface without an extended state
        # integrator, so reject them explicitly rather than silently using zero.
        if {'vx','vy'}&(self.ax.used|self.ay.used):
            raise ValueError('Velocity-dependent proposals are not supported by the frozen position-acceleration rollout')
        if self.center_axes is None:
            history=rollout(lambda t,state:self.acceleration(t,state,source_properties=source,probe_properties=props),
                            x,v,t_launch=start,duration=duration)
            return history['positions'][indices]
        bindings=self.model['bindings'];b=self.center_acceleration()
        center=rollout(lambda t,state:np.broadcast_to(b,state.shape),[bindings['center_position']],
                       [bindings['center_velocity']],t_launch=0.,duration=start)
        pos=np.vstack([center['positions'][-1],x]);vel=np.vstack([center['velocities'][-1],v])
        def acceleration(t,state):
            result=np.empty_like(state);result[0]=b
            result[1:]=self.acceleration(t,state[1:],source_properties=source,
                probe_properties=props,center_position=state[0])
            return result
        history=rollout(acceleration,pos,vel,t_launch=start,duration=duration)
        return history['positions'][indices,1:]


def _bindings(mission,spec):
    init=mission['background_initial_state'];ids=init['ids']
    center_id=spec.get('center_id',ids[0] if ids else None)
    if center_id is not None:
        if center_id not in ids:raise ValueError('center_id is not a known visible object')
        i=ids.index(center_id);position=init['positions'][i];velocity=init['velocities'][i]
    else:position=mission['launch_region']['center'];velocity=[0.,0.]
    source=mission['controls']['source_properties'];probe=mission['controls']['probe_properties']
    if len(source)>1 or len(probe)>1:raise ValueError('This expression adapter supports one scalar of each kind')
    skey=next(iter(source),None);pkey=next(iter(probe),None)
    return {'center_id':center_id,'center_position':copy.deepcopy(position),'center_velocity':copy.deepcopy(velocity),
            'source_key':skey,'source_default':float(source[skey]['default']) if skey else 1.,
            'probe_key':pkey,'probe_default':float(probe[pkey]['default']) if pkey else 1.}


def _samples(mission,transcript):
    records=[]
    if mission.get('first_light'):records.append((mission['first_light'],.1))
    seen=set()
    for entry in transcript:
        if entry.get('operation')!='launch':continue
        r=entry['response'];key=r.get('experiment_id')
        if key in seen:continue
        seen.add(key);records.append((r,1.))
    out=[]
    for record,quality in records:
        readout=np.asarray(record['readout'],dtype=float)
        ix=np.flatnonzero((readout>0)&(readout<=.10000001))[:4]
        if len(ix)<2:continue
        h=readout[ix];design=np.column_stack([h,h*h])
        velocities=np.asarray(record['velocities'],dtype=float)
        for i,probe in enumerate(record['probes']):
            delta=velocities[ix,i]-np.asarray(probe['vel'])
            acceleration=np.linalg.lstsq(design,delta,rcond=None)[0][0]
            out.append({'position':probe['pos'],'velocity':probe['vel'],'properties':probe['properties'],
                'source_properties':record.get('source_properties',{}),'time':float(record['t_launch']),
                'acceleration':acceleration,'weight':quality*min(1.,(.01/max(h))**2)})
    return out


def fit_expression(mission,transcript,spec):
    """Fit the proposer-supplied expression; no hypotheses are invented here."""
    started=time.perf_counter()
    allowed={'schema_version','ax','ay','parameters','center_id','center_accel'}
    if not isinstance(spec,dict) or set(spec)-allowed:raise ValueError('Unknown expression proposal fields')
    declarations=spec.get('parameters',{})
    if not isinstance(declarations,dict) or len(declarations)>5 or not set(declarations)<=PARAMETER_NAMES:
        raise ValueError('Declare at most five p0..p4 parameters')
    initial={};bounds={}
    for name,decl in declarations.items():
        if not isinstance(decl,dict) or set(decl)!={'initial','bounds'}:
            raise ValueError('Each fitted parameter requires initial and bounds')
        if not isinstance(decl['bounds'],list) or len(decl['bounds'])!=2:raise ValueError('Parameter bounds need two numbers')
        lower,upper=map(lambda v:_finite(v,'bound'),decl['bounds'])
        value=_finite(decl['initial'],name)
        if not lower<upper or not lower<=value<=upper:raise ValueError('Invalid fitted parameter interval/initial')
        if max(abs(lower),abs(upper))>1e6:raise ValueError('Parameter bounds exceed expression diagnostic limits')
        initial[name]=value;bounds[name]=[lower,upper]
    model={'schema_version':SCHEMA,'ax':spec['ax'],'ay':spec['ay'],'parameters':initial,
           'parameter_bounds':bounds,'center_accel':copy.deepcopy(spec.get('center_accel')),
           'bindings':_bindings(mission,spec)}
    candidate=ExpressionCandidate(model)
    if {'vx','vy'}&(candidate.ax.used|candidate.ay.used):
        raise ValueError('Velocity-dependent proposals require a future extended shared rollout')
    samples=_samples(mission,transcript)
    if len(samples)<max(6,2*len(initial)):
        raise ValueError('Insufficient public short trajectories: obtain at least max(6,2*parameter_count) probes with two positive readouts <=0.1')
    y=np.asarray([s['acceleration'] for s in samples],dtype=float)
    norm=np.linalg.norm(y,axis=1)
    weight=np.sqrt([s['weight'] for s in samples])/np.maximum(norm,.025*np.median(norm)+1e-8)
    indices=np.arange(len(samples));train=indices%5!=2;holdout=~train
    names=list(initial)
    def residual(values,selection=train):
        candidate.parameters={name:float(v) for name,v in zip(names,values)}
        result=[]
        for i,sample in enumerate(samples):
            if not selection[i]:continue
            try:
                pred=candidate.acceleration(sample['time'],[sample['position']],[sample['velocity']],
                    source_properties=sample['source_properties'],probe_properties=[sample['properties']])[0]
                error=(pred-y[i])*weight[i]
                if not np.isfinite(error).all():raise FloatingPointError('Invalid expression residual')
            except (ValueError,TypeError,OverflowError,FloatingPointError):
                error=np.full(2,1e6)
            result.extend(error)
        return np.asarray(result,dtype=float)
    if names:
        fitted=least_squares(residual,[initial[n] for n in names],
            bounds=([bounds[n][0] for n in names],[bounds[n][1] for n in names]),
            max_nfev=300,ftol=1e-9,xtol=1e-9,gtol=1e-9)
        values=fitted.x;success=bool(fitted.success);nfev=int(fitted.nfev)
    else:values=[];success=True;nfev=0
    training=residual(values,train);validation=residual(values,holdout)
    parameters={name:float(v) for name,v in zip(names,values)}
    candidate.model['parameters']=copy.deepcopy(parameters);candidate.parameters=parameters
    diagnostics={'method':'LLM-proposed safe expressions; numerical fit uses acquired public data only',
        'sample_count':len(samples),'training_count':int(train.sum()),'holdout_count':int(holdout.sum()),
        'training_loss':float(np.mean(training**2)),'public_holdout_loss':float(np.mean(validation**2)),
        'optimizer_success':success,'nfev':nfev,'elapsed_seconds':time.perf_counter()-started,
        'unused_parameters':sorted(set(parameters)-(candidate.ax.used|candidate.ay.used|set().union(*(v.used for v in candidate.center_axes or [])))),
        'uses_velocity_observations':True,'true_world_state_access':False,
        'limitations':['not an LLM capability claim by itself','short-time velocity differentiation can amplify observation noise',
            'velocity-dependent proposals and arbitrary hidden-source arrays are not implemented',
            'only the proposer selected this equation; no candidate-family search or true-law lookup occurs']}
    return {'candidate':candidate,'fitted_parameters':parameters,'diagnostics':diagnostics}


__all__=['ExpressionCandidate','SafeExpression','fit_expression','SCHEMA']
