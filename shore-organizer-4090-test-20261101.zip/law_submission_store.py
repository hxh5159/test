"""PRIVATE server-side paired law/claims snapshots; never executes a candidate.

The caller must own/authorize the private store directory.  This module is an
artifact store, not a session controller or an OS isolation mechanism.  End
exploration only after ``submit`` returns successfully; validation failures do
not change the last valid pair.  Draft and submission use exactly the same
static checks, without judging scientific truth or relating HIDDEN to claims.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import threading
from uuid import uuid4


PUBLIC_ROOT = Path(os.environ.get("RIFT_PUBLIC_ROOT",Path(__file__).resolve().parent.parent / "DiscoverPhysics")).resolve()
if str(PUBLIC_ROOT) not in sys.path:
    sys.path.insert(0, str(PUBLIC_ROOT))

from rift.law import ValidationError, validate_source
from scripts.validate_claims import (
    ClaimsValidationError, SCHEMA_VERSION, canonical_json, parse_claims,
)


FORMAT_VERSION = "1.0.0"
_SNAPSHOT_ID = re.compile(r"^[0-9a-f]{32}$")


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, allow_nan=False,
                       sort_keys=True, indent=2) + "\n").encode("utf-8")


class SubmissionValidationError(ValueError):
    """Invalid submitted format; the previous valid pair remains current."""
    code = "invalid_submission"

    def __init__(self, artifact, details):
        self.artifact, self.details = artifact, details
        super().__init__(f"Invalid {artifact} format")

    def as_dict(self):
        return {"code": self.code, "artifact": self.artifact,
                "details": self.details, "ends_exploration": False}


class ArtifactError(RuntimeError):
    """Private storage/I/O/integrity error; never convert to scientific P=0."""
    code = "artifact_infrastructure_error"


@dataclass(frozen=True)
class FrozenSubmission:
    """Detached immutable bytes, safe from subsequent current-pointer changes.

    ``claims`` and ``manifest`` properties return fresh dictionaries.  A worker
    should use these frozen bytes, rather than reopening mutable upload paths.
    """
    snapshot_id: str
    law_bytes: bytes
    claims_bytes: bytes
    manifest_bytes: bytes

    @property
    def claims(self):
        return json.loads(self.claims_bytes)

    @property
    def manifest(self):
        return json.loads(self.manifest_bytes)

    @property
    def operation(self):
        return self.manifest["operation"]

    @property
    def ends_exploration(self):
        return self.operation == "submit"

    @property
    def law_sha256(self):
        return _sha(self.law_bytes)

    @property
    def claims_sha256(self):
        return _sha(self.claims_bytes)

    @property
    def manifest_sha256(self):
        return _sha(self.manifest_bytes)


class LawSubmissionStore:
    """One private session store, with append-only UUID snapshot directories.

    Complete law/claims/manifest files are fsynced before the single current
    pointer is atomically replaced.  Failed publication can leave an unreferenced
    snapshot, which is never treated as current.  Authentication, request ordering
    across server processes, and exploration state belong to the caller.
    """
    def __init__(self, server_root):
        self.root = Path(server_root).resolve()
        self.snapshots = self.root / "snapshots"
        self._lock = threading.RLock()
        try:
            self.snapshots.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ArtifactError("Cannot initialize private submission store") from exc

    def save_draft(self, law_bytes: bytes, claims: str | bytes) -> FrozenSubmission:
        return self._publish("save_draft", law_bytes, claims)

    def submit(self, law_bytes: bytes, claims: str | bytes) -> FrozenSubmission:
        return self._publish("submit", law_bytes, claims)

    def _publish(self, operation, law_bytes, claims):
        # Complete both validations before creating any publishable snapshot.
        if not isinstance(law_bytes, bytes):
            raise SubmissionValidationError("law.py", {"code": "invalid_bytes"})
        try:
            source = law_bytes.decode("utf-8")  # BOM and CRLF retained for SHA.
            metadata = validate_source(source, source_name="law.py")
        except UnicodeError:
            raise SubmissionValidationError("law.py", {"code": "invalid_utf8"}) from None
        except ValidationError as exc:
            raise SubmissionValidationError("law.py", exc.as_dict()) from None
        if not isinstance(claims, (str, bytes)):
            raise SubmissionValidationError("claims.json", {"code": "invalid_text"})
        try:
            normalized = parse_claims(claims)
            claims_bytes = canonical_json(normalized).encode("utf-8")
        except ClaimsValidationError as exc:
            raise SubmissionValidationError("claims.json", exc.as_dict()) from None

        with self._lock:
            ident = uuid4().hex
            directory = self.snapshots / ident
            manifest = {
                "format_version": FORMAT_VERSION, "snapshot_id": ident,
                "operation": operation, "ends_exploration": operation == "submit",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "law_api_version": metadata.api_version,
                "claims_schema_version": SCHEMA_VERSION,
                "execution_checked": False, "scientific_correctness_checked": False,
                "files": {
                    "law.py": {"sha256": _sha(law_bytes), "size": len(law_bytes)},
                    "claims.json": {"sha256": _sha(claims_bytes), "size": len(claims_bytes)},
                },
            }
            manifest_bytes = _json_bytes(manifest)
            pointer = _json_bytes({"format_version": FORMAT_VERSION,
                                   "snapshot_id": ident,
                                   "manifest_sha256": _sha(manifest_bytes)})
            pointer_tmp = self.root / f".current.{ident}.tmp"
            try:
                directory.mkdir()
                for name, data in (("law.py", law_bytes), ("claims.json", claims_bytes),
                                   ("manifest.json", manifest_bytes)):
                    self._write_new(directory / name, data)
                # Verify the complete pair before making it visible to readers.
                frozen = self.get_snapshot(ident, manifest_sha256=_sha(manifest_bytes))
                self._write_new(pointer_tmp, pointer)
                os.replace(pointer_tmp, self.root / "current.json")
            except ArtifactError:
                raise
            except OSError as exc:
                raise ArtifactError("Cannot atomically publish submission pair") from exc
            return frozen

    @staticmethod
    def _write_new(path, raw):
        with path.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())

    def get_current(self) -> FrozenSubmission | None:
        # Read the pointer once: another request cannot mix one snapshot's law
        # with another snapshot's claims even when it replaces current.json.
        try:
            raw = (self.root / "current.json").read_bytes()
        except FileNotFoundError:
            return None
        except OSError as exc:
            raise ArtifactError("Cannot read current submission pointer") from exc
        try:
            pointer = json.loads(raw)
            if (pointer["format_version"] != FORMAT_VERSION
                    or set(pointer) != {"format_version", "snapshot_id", "manifest_sha256"}
                    or not re.fullmatch(r"[0-9a-f]{64}", pointer["manifest_sha256"])):
                raise ValueError("Invalid pointer envelope")
            return self.get_snapshot(pointer["snapshot_id"],
                                     manifest_sha256=pointer["manifest_sha256"])
        except ArtifactError:
            raise
        except (ValueError, TypeError, KeyError) as exc:
            raise ArtifactError("Current submission pointer is corrupt") from exc

    def get_snapshot(self, snapshot_id: str, *, manifest_sha256: str | None = None) -> FrozenSubmission:
        """Read and hash-check one whole pair; no candidate code is executed.

        ``get_current`` anchors the manifest hash in its atomic pointer.  Older
        snapshot IDs are safe only in the private trusted store; a retained
        FrozenSubmission.manifest_sha256 may also be supplied as an anchor.
        """
        if not isinstance(snapshot_id, str) or not _SNAPSHOT_ID.fullmatch(snapshot_id):
            raise ArtifactError("Invalid snapshot identifier")
        directory = self.snapshots / snapshot_id
        try:
            manifest_bytes = (directory / "manifest.json").read_bytes()
            if manifest_sha256 is not None and _sha(manifest_bytes) != manifest_sha256:
                raise ArtifactError("Snapshot manifest hash mismatch")
            manifest = json.loads(manifest_bytes)
            if (manifest["format_version"] != FORMAT_VERSION
                    or manifest["snapshot_id"] != snapshot_id
                    or manifest["operation"] not in ("save_draft", "submit")
                    or type(manifest["ends_exploration"]) is not bool
                    or manifest["ends_exploration"] != (manifest["operation"] == "submit")
                    or set(manifest["files"]) != {"law.py", "claims.json"}):
                raise ArtifactError("Snapshot manifest envelope mismatch")
            values = {}
            for name in ("law.py", "claims.json"):
                raw = (directory / name).read_bytes()
                expected = manifest["files"][name]
                if len(raw) != expected["size"] or _sha(raw) != expected["sha256"]:
                    raise ArtifactError(f"Snapshot {name} hash/length mismatch")
                values[name] = raw
            return FrozenSubmission(snapshot_id, values["law.py"],
                                    values["claims.json"], manifest_bytes)
        except ArtifactError:
            raise
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise ArtifactError("Snapshot is missing or corrupt") from exc
