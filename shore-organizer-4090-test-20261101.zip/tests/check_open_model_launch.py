"""Synthetic local metadata tests; never start vLLM or use a GPU/API."""
from __future__ import annotations

import contextlib
import io
import json
import os
from pathlib import Path
import shlex
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from serve_open_models import LaunchError, compatible_version, prepare_launch, main


def make_model(path, dtype="BF16", quant=None):
    path.mkdir(parents=True)
    config = {"torch_dtype": "bfloat16", "architectures": ["SyntheticQwen"], "hidden_size": 16}
    if quant is not None: config["quantization_config"] = {"quant_method": quant}
    (path / "config.json").write_text(json.dumps(config), encoding="utf8")
    (path / "tokenizer_config.json").write_text("{}")
    (path / "tokenizer.json").write_text("{}")
    size = 8 if dtype.startswith("F8") or dtype == "I8" else 16
    raw = json.dumps({"weight": {"dtype": dtype, "shape": [2, 4], "data_offsets": [0, size]}}).encode()
    (path / "model.safetensors").write_bytes(struct.pack("<Q", len(raw)) + raw + bytes(size))
    return path


class LaunchTests(unittest.TestCase):
    def setUp(self):
        (ROOT / "checks").mkdir(parents=True, exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(prefix="open-model-launch-test-", dir=ROOT / "checks")
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.assertTrue(self.root.resolve().is_relative_to((ROOT / "checks").resolve()))
        self.tmp.cleanup()

    def test_27b_auto_common_flags_and_shell_safe_path(self):
        path = make_model(self.root / "weights with spaces 'literal'")
        command, env, record = prepare_launch("27b", model_path=path, dry_run=True)
        self.assertEqual(shlex.split(shlex.join(command)), command)
        self.assertEqual(command[command.index("serve") + 1], str(path.resolve()))
        for key, value in {"--tensor-parallel-size": "4", "--max-num-seqs": "1", "--dtype": "auto",
                           "--max-model-len": "32768", "--gpu-memory-utilization": "0.90",
                           "--reasoning-parser": "qwen3", "--generation-config": "vllm"}.items():
            self.assertEqual(command[command.index(key) + 1], value)
        self.assertIn("--language-model-only", command)
        self.assertIn("--enforce-eager", command)
        self.assertNotIn("--quantization", command)
        self.assertNotIn("CUDA_VISIBLE_DEVICES", env)
        self.assertEqual(env["HF_HUB_OFFLINE"], "1")
        self.assertFalse(record["successful_loading_or_inference_verified"])

    def test_122b_bf16_requests_per_block_without_claiming_success(self):
        path = make_model(self.root / "122-bf16")
        command, _, record = prepare_launch("122b", model_path=path, version="0.32.0+cu129")
        self.assertEqual(command[command.index("--quantization") + 1], "fp8_per_block")
        self.assertEqual(record["precision"]["mode"], "online_fp8_per_block_requested")
        self.assertFalse(record["precision"]["checkpoint_is_prequantized_fp8"])
        self.assertFalse(record["precision"]["actual_load_or_quantization_verified"])

    def test_fp8_checkpoint_auto_recognized_for_122_and_397(self):
        path = make_model(self.root / "fp8", "F8_E4M3", "fp8")
        for selector in ("122b", "397b"):
            command, _, record = prepare_launch(selector, model_path=path, version="0.32.0")
            self.assertNotIn("--quantization", command)
            self.assertTrue(record["precision"]["checkpoint_is_prequantized_fp8"])
            self.assertEqual(record["precision"]["largest_payload_dtype"], "F8_E4M3")
            self.assertFalse(record["model_identity_verified"])

    def test_raw_397_and_other_quantization_blocked_even_dry(self):
        raw = make_model(self.root / "397-FP8-in-name-only")
        other = make_model(self.root / "other", "I8", "gptq")
        for selector, path in (("397b", raw), ("122b", other)):
            with self.assertRaises(LaunchError): prepare_launch(selector, model_path=path, dry_run=True)

    def test_fp8_config_without_fp8_header_is_not_auto_conversion(self):
        path = make_model(self.root / "bad-declaration", "BF16", "fp8")
        with self.assertRaises(LaunchError): prepare_launch("122b", model_path=path, dry_run=True)

    def test_version_gate_and_unknown_dry_run(self):
        path = make_model(self.root / "base")
        for version in (None, "0.31.0", "0.32.1", "0.320.0"):
            with self.assertRaises(LaunchError): prepare_launch("27b", model_path=path, version=version)
        _, _, record = prepare_launch("27b", model_path=path, dry_run=True, version=None)
        self.assertIsNone(record["installed_vllm_version"])
        self.assertFalse(record["installed_version_accepted"])
        self.assertTrue(compatible_version("0.32.0"))
        self.assertTrue(compatible_version("0.32.0+cu129"))

    def test_cli_print_only_does_not_exec_and_records_plan(self):
        path = make_model(self.root / "base with spaces")
        output = self.root / "launch.json"
        stdout = io.StringIO()
        with patch("serve_open_models.installed_vllm_version", return_value=None), patch("serve_open_models.os.execvpe") as execute:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                code = main(["--model", "27b", "--model-path", str(path), "--port", "8123",
                             "--max-model-len", "8192", "--print-command", "--record", str(output)])
        self.assertEqual(code, 0)
        execute.assert_not_called()
        parsed = shlex.split(stdout.getvalue().strip())
        self.assertIn(str(path.resolve()), parsed)
        self.assertIn("8123", parsed)
        record = json.loads(output.read_text(encoding="utf8"))
        self.assertEqual(record["max_model_len"], 8192)
        self.assertTrue(record["print_command_only"])

    def test_foreground_exec_inherits_allocated_devices(self):
        path = make_model(self.root / "base")
        with patch.dict(os.environ, {"CUDA_VISIBLE_DEVICES": "GPU-one,GPU-two,GPU-three,GPU-four"}):
            with patch("serve_open_models.installed_vllm_version", return_value="0.32.0"), patch("serve_open_models.os.execvpe", side_effect=OSError("mock blocked")) as execute:
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(main(["--model", "27b", "--model-path", str(path), "--no-enforce-eager"]), 2)
        command = execute.call_args.args[1]
        environment = execute.call_args.args[2]
        self.assertNotIn("--enforce-eager", command)
        self.assertEqual(environment["CUDA_VISIBLE_DEVICES"], "GPU-one,GPU-two,GPU-three,GPU-four")
        self.assertEqual(command[0], sys.executable)


if __name__ == "__main__":
    unittest.main()
