"""Synthetic metadata/header tests only: no GPU, model load or network."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from preflight_open_models import (PreflightError, inspect_safetensors, inspect_weights,
    inspect_model, inspect_tokenizer, inspect_gpus, memory_assessment, main)


def checkpoint(path, tensors):
    header, offset = {}, 0
    for name, dtype, shape, nbytes in tensors:
        header[name] = {"dtype": dtype, "shape": shape, "data_offsets": [offset, offset + nbytes]}
        offset += nbytes
    raw = json.dumps(header).encode("utf8")
    path.write_bytes(struct.pack("<Q", len(raw)) + raw + bytes(offset))
    return raw


def setUpModule():
    (ROOT / "checks").mkdir(parents=True, exist_ok=True)


class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="open-model-preflight-test-", dir=ROOT / "checks")
        self.root = Path(self.temp.name)

    def tearDown(self):
        if not self.root.resolve().is_relative_to((ROOT / "checks").resolve()):
            raise AssertionError("Synthetic cleanup must remain in the private test workspace")
        self.temp.cleanup()

    def files(self, root=None, config=None):
        root = self.root if root is None else root
        root.mkdir(parents=True, exist_ok=True)
        (root / "config.json").write_text(json.dumps(config or {
            "architectures": ["SyntheticMoe"], "torch_dtype": "bfloat16",
            "text_config": {"hidden_size": 16, "num_attention_heads": 4,
                            "num_experts": 8, "num_experts_per_tok": 2}}))
        (root / "tokenizer_config.json").write_text("{}")
        (root / "tokenizer.json").write_text("{}")

    def test_sharded_bf16_uses_real_offsets_and_all_experts(self):
        self.files()
        checkpoint(self.root / "a.safetensors", [("experts.weight", "BF16", [8, 2, 3], 96)])
        checkpoint(self.root / "b.safetensors", [("norm.weight", "F32", [4], 16)])
        (self.root / "model.safetensors.index.json").write_text(json.dumps({
            "metadata": {"total_size": 112},
            "weight_map": {"experts.weight": "a.safetensors", "norm.weight": "b.safetensors"}}))
        result = inspect_model(self.root, "122B-A10B", "Expected-FP8", {"selected": []})
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["weights"]["tensor_payload_size"]["bytes"], 112)
        self.assertEqual(result["parameter_estimate"]["stored_tensor_elements"], 52)
        self.assertEqual(result["weights"]["shard_count"], 2)
        self.assertEqual(result["whitelist_alignment"], "requires_confirmation_or_approved_quantization")
        self.assertFalse(result["identity_verified"])

    def test_header_fp8_overrides_bf16_config_description(self):
        self.files(config={"torch_dtype": "bfloat16", "quantization_config": {"quant_method": "fp8"}})
        raw = checkpoint(self.root / "model.safetensors", [
            ("weight", "F8_E4M3", [8, 8], 64), ("weight_scale", "F32", [1], 4)])
        result = inspect_model(self.root, "397B-A17B", "Expected-FP8", {"selected": []})
        self.assertTrue(result["precision_evidence"]["FP8_tensor_storage_present"])
        self.assertEqual(result["precision_evidence"]["largest_payload_dtype"], "F8_E4M3")
        self.assertEqual(result["weights"]["tensor_payload_size"]["bytes"], 68)
        self.assertEqual(result["weights"]["shards"][0]["header_sha256"],
                         hashlib.sha256(struct.pack("<Q", len(raw)) + raw).hexdigest())

    def test_header_reader_never_reads_tensor_payload(self):
        import unittest.mock as mock
        raw = checkpoint(self.root / "model.safetensors", [("w", "BF16", [3], 6)])
        original = Path.open
        calls = []

        class Guard:
            def __init__(self, stream): self.stream = stream
            def __enter__(self): return self
            def __exit__(self, *args): self.stream.close()
            def read(self, n=-1):
                calls.append(n)
                if self.stream.tell() + n > 8 + len(raw) or n < 0:
                    raise AssertionError("Attempted tensor payload read")
                return self.stream.read(n)

        with mock.patch.object(Path, "open", lambda p, *a, **k: Guard(original(p, *a, **k))):
            self.assertEqual(inspect_safetensors(self.root / "model.safetensors")["tensors"]["w"]["bytes"], 6)
        self.assertEqual(calls, [8, len(raw)])

    def test_invalid_offsets_and_missing_tokenizer_are_rejected(self):
        self.files()
        (self.root / "tokenizer.json").unlink()
        self.assertTrue(inspect_tokenizer(self.root)["errors"])
        header = json.dumps({"w": {"dtype": "BF16", "shape": [3], "data_offsets": [0, 6]}}).encode()
        p = self.root / "broken.safetensors"
        p.write_bytes(struct.pack("<Q", len(header)) + header + b"00")
        with self.assertRaises(PreflightError): inspect_safetensors(p)

    def test_index_cannot_traverse_or_claim_missing_tensor(self):
        self.files()
        checkpoint(self.root / "a.safetensors", [("w", "BF16", [1], 2)])
        idx = self.root / "model.safetensors.index.json"
        idx.write_text(json.dumps({"weight_map": {"w": "../a.safetensors"}}))
        with self.assertRaises(PreflightError): inspect_weights(self.root)
        idx.write_text(json.dumps({"weight_map": {"missing": "a.safetensors"}}))
        with self.assertRaises(PreflightError): inspect_weights(self.root)

    def test_bin_checkpoint_is_not_deserialized(self):
        (self.root / "pytorch_model.bin").write_bytes(b"not a real model")
        with self.assertRaisesRegex(PreflightError, "pickle/.bin"):
            inspect_weights(self.root)

    def test_gpu_selection_capacity_and_command_are_read_only(self):
        rows = "\n".join(f"{i}, GPU-{i}, NVIDIA H200, 143771, 140000, 575.57.08, 9.0" for i in range(4))
        calls = []
        def run(args, **kw):
            calls.append((args, kw))
            return SimpleNamespace(returncode=0, stdout=rows)
        gpu = inspect_gpus(runner=run, environ={"CUDA_VISIBLE_DEVICES": "GPU-3,GPU-2,GPU-1,GPU-0"})
        self.assertEqual([r["index"] for r in gpu["selected"]], ["3", "2", "1", "0"])
        self.assertIn("--query-gpu=", calls[0][0][1])
        self.assertEqual(calls[0][1]["timeout"], 15)
        self.assertTrue(gpu["driver_check"]["meets_conservative_marker"])
        self.assertEqual(gpu["selected"][0]["compute_capability"], "9.0")
        assessment = memory_assessment(794_000_000_000, gpu)
        self.assertFalse(assessment["fits_4x141GiB_weights_only"])
        self.assertFalse(assessment["fits_reported_free_memory_weights_only"])
        self.assertTrue(memory_assessment(244_000_000_000, gpu)["fits_reported_free_memory_weights_only"])

    def test_gpu_failure_is_reported_without_model_load(self):
        def run(*a, **kw): raise FileNotFoundError("not installed")
        self.assertEqual(inspect_gpus(runner=run, environ={})["status"], "unavailable")

    def test_expanded_4090_profile_and_actual_memory_budget(self):
        rows = "\n".join(f"{i}, GPU-{i}, NVIDIA GeForce RTX 4090, 49152, 48000, 575.57.08, 8.9" for i in range(4))
        def run(*args, **kw):
            return SimpleNamespace(returncode=0, stdout=rows)
        gpu = inspect_gpus(runner=run, environ={}, hardware_profile="4090")
        self.assertEqual(gpu["hardware_profile"], "4090")
        self.assertEqual(gpu["expected_compute_capability"], "8.9")
        self.assertFalse(any("H200" in warning or "9.0" in warning for warning in gpu["warnings"]))
        self.assertTrue(memory_assessment(128_000_000_000, gpu)["fits_reported_free_memory_weights_only"])
        self.assertFalse(memory_assessment(400_000_000_000, gpu)["fits_reported_free_memory_weights_only"])

    def test_standard_24gb_4090_is_flagged_for_expanded_memory_profile(self):
        rows = "\n".join(f"{i}, GPU-{i}, NVIDIA GeForce RTX 4090, 24576, 24000, 575.57.08, 8.9" for i in range(4))
        def run(*args, **kw):
            return SimpleNamespace(returncode=0, stdout=rows)
        gpu = inspect_gpus(runner=run, environ={}, hardware_profile="4090")
        self.assertTrue(any("less than 40GiB" in warning for warning in gpu["warnings"]))

    def test_old_smi_fallback_reports_low_driver_without_upgrading(self):
        rows = "\n".join(f"{i}, GPU-{i}, NVIDIA H200, 143771, 140000, 550.90.07" for i in range(4))
        replies = iter((SimpleNamespace(returncode=1, stdout=""), SimpleNamespace(returncode=0, stdout=rows)))
        commands = []
        def run(args, **kwargs):
            commands.append(args)
            return next(replies)
        result = inspect_gpus(runner=run, environ={})
        self.assertFalse(result["driver_check"]["meets_conservative_marker"])
        self.assertIsNone(result["selected"][0]["compute_capability"])
        self.assertEqual(len(commands), 2)
        self.assertTrue(all(command[0] == "nvidia-smi" and len(command) == 3 for command in commands))

    def test_json_report_keeps_bad_paths_separate_and_does_not_overwrite(self):
        import contextlib
        import io
        for name in ("one", "two", "three"):
            self.files(self.root / name)
            checkpoint(self.root / name / "model.safetensors", [("w", "BF16", [2], 4)])
        output = self.root / "report.json"
        argv = ["--model-path", str(self.root / "one"), "--model-path", str(self.root / "two"),
                "--model-path", str(self.root / "three"), "--skip-gpu", "--json-output", str(output)]
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(argv), 0)
        data = json.loads(output.read_text(encoding="utf8"))
        self.assertEqual(len(data["models"]), 3)
        self.assertEqual(data["network_or_model_calls"], 0)
        self.assertFalse(data["private_test_workflow_distribution_allowed"])
        with contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(FileExistsError): main(argv)

    def test_two_model_selection_does_not_inspect_missing_397b(self):
        import contextlib
        import io
        for name in ("small", "large-fp8"):
            self.files(self.root / name)
            checkpoint(self.root / name / "model.safetensors", [("w", "BF16", [2], 4)])
        output = self.root / "two-models.json"
        argv = ["--models", "27b", "122b", "--model-27b", str(self.root / "small"),
                "--model-122b", str(self.root / "large-fp8"), "--model-397b", str(self.root / "missing"),
                "--skip-gpu", "--json-output", str(output)]
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(argv), 0)
        report = json.loads(output.read_text(encoding="utf8"))
        self.assertEqual(report["model_slots_requested"], ["27b", "122b"])
        self.assertEqual([row["role"] for row in report["models"]], ["27B", "122B-A10B"])

    def test_duplicate_model_slots_are_rejected(self):
        import contextlib
        import io
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
            main(["--models", "27b", "27b", "--skip-gpu"])
        self.assertEqual(error.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
