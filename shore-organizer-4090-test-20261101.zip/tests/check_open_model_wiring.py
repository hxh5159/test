"""Synthetic wiring only: fake model/console, real expression rollout and scorer.

World IDs select existing scoring labels only. References are hand-calculated
linear toy trajectories, never true contest-world simulations or capability
results. No model service, GPU, calibrate_world or real console is used.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import expression_candidate
import open_model_calibration as calibration
from trial_evaluation import evaluate_model, public_feedback
from check_open_model_calibration import CLAIMS, MODEL, SPEC, FakeClient, FakeConsole, configuration


PRIVATE_TOY_MARKER = "TOY_PRIVATE_VALIDATION_NOT_MODEL_CAPABILITY"


def toy_reference(world):
    """Compute x0 + readout*v0 directly, independently of the integrator."""
    cases = []
    truths = []
    for index, (launch, readout) in enumerate(((.01, [0., .005, .01, .025]),
                                               (.2, [0., .01, .03]))):
        probes = [{"pos": [1., -1.], "vel": [.25, -.5], "properties": {}},
                  {"pos": [-2., 1.], "vel": [.5, .125], "properties": {}}]
        cases.append({"name": f"{PRIVATE_TOY_MARKER}_{index}", "group": f"toy_{index}",
                      "t_launch": launch, "readout": readout,
                      "source_properties": {}, "probes": probes})
        position = np.asarray([probe["pos"] for probe in probes])
        velocity = np.asarray([probe["vel"] for probe in probes])
        values = position[None]+np.asarray(readout)[:, None, None]*velocity[None]
        truths.append({"positions": values.tolist()})
    flat = np.concatenate([np.asarray(record["positions"]).reshape(-1, 2) for record in truths])
    variance = float(np.mean(np.sum((flat-flat.mean(axis=0))**2, axis=1)))
    return {"world": world, "cases": cases, "truths": truths, "global_V": variance}


def toy_expression_fit(mission, transcript, spec):
    """Inject a real, zero-acceleration expression; perform no physical fitting."""
    if spec != SPEC:
        raise ValueError("This synthetic wiring check accepts only the zero-acceleration toy expression")
    candidate = expression_candidate.ExpressionCandidate({
        "schema_version": expression_candidate.SCHEMA, "ax": "0", "ay": "0", "parameters": {},
        "bindings": {"center_id": None, "center_position": [0., 0.], "center_velocity": [0., 0.],
                     "source_key": None, "source_default": 1., "probe_key": None, "probe_default": 1.}})
    return {"candidate": candidate, "fitted_parameters": {},
            "diagnostics": {"synthetic_toy_only": True, "real_physical_fitting_performed": False}}


class OpenModelToyWiringTests(unittest.TestCase):
    def test_nine_world_toy_fake_model_real_rollout_scoring_wiring_not_capability(self):
        clients = []
        references_requested = []

        def client_factory(*args, **kwargs):
            client = FakeClient([{"action": "finish", "spec": SPEC, "claims": CLAIMS,
                                  "report": "Synthetic toy wiring; fake model, no capability result"}])
            clients.append(client)
            return client

        def reference_factory(world):
            # Scoring must begin only after this world's fake model submitted.
            self.assertFalse(clients[-1].actions)
            references_requested.append(world)
            return toy_reference(world)

        (ROOT/"checks").mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_toy_wiring_") as folder:
            directory = Path(folder)
            weights = directory/"fake-metadata-not-real-weights"
            weights.mkdir()
            (weights/"config.json").write_text('{"model_type":"synthetic-toy"}', encoding="utf-8")
            out = directory/"new-toy-output"
            args = calibration.parse_args(["--base-url", "http://127.0.0.1:9/v1", "--model", MODEL,
                "--model-path", str(weights), "--out-dir", str(out), "--max-turns", "1", "--seeds", "0"])
            with patch.dict(sys.modules, {"trial_catalog": None, "trial_console": None, "contest_simulator": None}), \
                    patch("urllib.request.OpenerDirector.open", side_effect=AssertionError("No HTTP in toy wiring")), \
                    patch.object(expression_candidate, "rollout", wraps=expression_candidate.rollout) as rollout:
                result = calibration.run_calibration(args, client_factory=client_factory,
                    config_factory=configuration, console_factory=FakeConsole,
                    reference_factory=reference_factory, evaluate_fn=evaluate_model,
                    feedback_fn=public_feedback, expression_fit_fn=toy_expression_fit)
            self.assertEqual(rollout.call_count, 2*len(calibration.WORLDS))
            self.assertEqual(references_requested, list(calibration.WORLDS))
            self.assertEqual(result["status"], "completed")
            manifest = json.loads((out/"manifest.json").read_text(encoding="utf-8"))
            summary = json.loads((out/"organizer_summary.json").read_text(encoding="utf-8"))
            seed = summary["seeds"]["0"]
            self.assertEqual(manifest["status"], "completed")
            self.assertEqual(len(manifest["results"]), 9)
            self.assertTrue(seed["complete_nine_world_scores"])
            self.assertFalse(summary["private_scores_returned_to_discovery"])
            self.assertEqual(set(seed["worlds"]), set(calibration.WORLDS))
            labels = json.loads((ROOT/"claims_truth.json").read_text(encoding="utf-8"))["truth_by_world"]
            expected_totals = []
            for world in calibration.WORLDS:
                row = seed["worlds"][world]
                scores = row["scores"]
                expected_law = sum(5 for key, value in labels[world].items() if CLAIMS[key] == value)
                expected_total = 80.+expected_law+5.
                expected_totals.append(expected_total)
                self.assertEqual(row["discovery_status"], "submitted")
                self.assertEqual(row["evaluation_status"], "completed_after_discovery")
                self.assertEqual(row["model_turns"], 1)
                self.assertIsNone(row["failure_classification"])
                self.assertEqual(scores["invalid_cases"], [])
                self.assertAlmostEqual(scores["prediction"], 80., places=12)
                self.assertLess(scores["raw_MSE"], 1e-25)
                self.assertEqual(scores["law"], expected_law)
                self.assertEqual(scores["saving"], 5.)
                self.assertAlmostEqual(scores["total"], expected_total, places=12)
                self.assertAlmostEqual(seed["public_feedback"]["world_scores"][world], expected_total, places=12)
                world_dir = out/world/"seed_0"
                for name in ("run.json", "candidate.json", "claims.json", "transport.json",
                             "model_events.json", "public_records.json", "organizer_scores.json"):
                    self.assertTrue((world_dir/name).is_file(), (world, name))
            expected_weighted = (.3*np.mean(expected_totals[:3])+.4*np.mean(expected_totals[3:6])
                                 +.3*np.mean(expected_totals[6:]))
            self.assertAlmostEqual(seed["public_feedback"]["total_score"], expected_weighted, places=12)
            self.assertEqual(result["seeds"]["0"]["public_feedback"], seed["public_feedback"])
            self.assertFalse(json.loads((out/"credential_audit.json").read_text(encoding="utf-8"))[
                "credential_present_in_output_files"])
            for client in clients:
                self.assertEqual(len(client.requests), 1)
                sent = json.dumps(client.requests, ensure_ascii=False)
                for private_field in (PRIVATE_TOY_MARKER, "raw_MSE", "global_V", "case_diagnostics",
                                      "total_score", "truth_by_world"):
                    self.assertNotIn(private_field, sent)
                for world in calibration.WORLDS:
                    self.assertNotIn(world, sent)


if __name__ == "__main__":
    unittest.main(verbosity=2)
