"""Offline transport tests. No model, GPU, physics, or real HTTP server."""
import io
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_open_model_service import check_service


class FakeOpener:
    def __init__(self, advertised="Qwen3.8-27B"):
        self.advertised = advertised
        self.calls = []

    def open(self, request, timeout):
        body = None if request.data is None else json.loads(request.data)
        self.calls.append((request.full_url, body))
        if request.full_url.endswith("/v1/models"):
            result = {"data": [{"id": self.advertised}]}
        elif request.full_url.endswith("/tokenize"):
            result = {"count": 17, "max_model_len": 32768}
        elif request.full_url.endswith("/v1/chat/completions"):
            result = {"model": self.advertised,
                "choices": [{"message": {"content": '{"ok":true}'}}]}
        else:
            raise AssertionError(request.full_url)
        return io.BytesIO(json.dumps(result).encode())


class ServiceTests(unittest.TestCase):
    def test_routes_and_final_content(self):
        transport = FakeOpener()
        report = check_service("http://127.0.0.1:8000/v1", "Qwen3.8-27B", opener=transport)
        self.assertEqual(report["scientific_trials_started"], 0)
        self.assertEqual(transport.calls[1][0], "http://127.0.0.1:8000/tokenize")
        self.assertEqual(transport.calls[2][1]["chat_template_kwargs"], {"enable_thinking": False})
        self.assertEqual(json.loads(report["content"]), {"ok": True})

    def test_wrong_model_never_starts_generation(self):
        transport = FakeOpener("another-model")
        with self.assertRaisesRegex(ValueError, "not advertised"):
            check_service("http://127.0.0.1:8000/v1", "Qwen3.8-27B", opener=transport)
        self.assertEqual(len(transport.calls), 1)

    def test_api_base_requires_v1(self):
        with self.assertRaises(ValueError):
            check_service("http://127.0.0.1:8000", "Qwen3.8-27B", opener=FakeOpener())


if __name__ == "__main__":
    unittest.main()
