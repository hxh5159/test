"""Administrator ACL setup for explicitly submitted strategy/model paths."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess

from evaluate_strategy import PRIVATE, run_identity
from rift.strategy import load_model_registry, load_strategy_submission


def access_plan(agent_dir, models_file, environment_roots=()):
    load_strategy_submission(agent_dir, models_file, check_files=True)
    registry = load_model_registry(models_file, check_files=True)
    roots = {Path(agent_dir).resolve()}
    for model in registry['models']:
        roots.add(Path(model['path']).resolve())
        if model.get('adapter_path'):
            roots.add(Path(model['adapter_path']).resolve())
    roots.update(Path(path).expanduser().resolve() for path in environment_roots)
    for root in roots:
        if not root.is_dir():
            raise ValueError('Approved strategy, model and environment roots must be directories.')
        if root.is_relative_to(PRIVATE) or PRIVATE.is_relative_to(root):
            raise ValueError('Access grants must never include the private organizer runtime or an ancestor of it.')
    ancestors = {parent for root in roots for parent in root.parents if parent != parent.parent}
    return sorted(ancestors, key=lambda path: (len(path.parts), str(path))), sorted(roots)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--agent-dir', required=True, type=Path)
    parser.add_argument('--models-file', required=True, type=Path)
    parser.add_argument('--run-as', required=True)
    parser.add_argument('--environment-root', action='append', type=Path, default=[])
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args(argv)
    run_identity(args.run_as)
    parents, roots = access_plan(args.agent_dir, args.models_file, args.environment_root)
    commands = ([['setfacl', '-m', 'u:'+args.run_as+':--x', '--', str(path)] for path in parents] +
                [['setfacl', '-R', '-m', 'u:'+args.run_as+':r-X', '--', str(path)] for path in roots])
    if args.apply:
        if shutil.which('setfacl') is None:
            parser.error('setfacl is required. Install the Linux acl utility or grant equivalent platform ACLs.')
        for command in commands:
            subprocess.run(command, check=True, stdin=subprocess.DEVNULL)
    print(json.dumps({'applied':args.apply, 'run_as':args.run_as,
        'read_only_artifact_roots':[str(path) for path in roots],
        'ancestor_permissions':'traverse only', 'private_environment_granted':False}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
