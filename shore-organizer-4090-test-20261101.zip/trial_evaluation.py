"""Organizer-only trial scoring. Never import this into a contestant process.

The current 80/15/5 formula is implemented literally. Counterfactual grouped
scores are diagnostics only; they are not silently substituted for the rule.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
WORLD_ORDER=('Adam','Lilith','Tabris','Sachiel','Ramiel','Matriel','Leliel','Arael','Lilin')


def noise_sigma(config, calibration, rule='launch01'):
    """Numerical sigma is private calibration, not a console response field."""
    region=config['launch_region']
    length=math.sqrt((region['radius_min']**2+region['radius_max']**2)/2)
    rules={'legacy05':.05*math.sqrt(calibration['global_V']),
           'legacy02':.02*math.sqrt(calibration['global_V']),
           'launch01':.01*length,'launch02':.02*length}
    if rule not in rules: raise ValueError(f'Unknown diagnostic noise rule: {rule}')
    return float(rules[rule])


def prediction_score(mse, variance):
    if not math.isfinite(float(mse)) or mse<0:return 0.
    return float(80/(1+10*float(mse)/max(float(variance),1e-12)))


def score_components(prediction, claims, truth, energy_used):
    if not isinstance(claims,dict) or set(claims)!=set(truth):raise ValueError('Claims must contain exactly three schema fields.')
    order=claims['dynamics_order']
    if type(order) not in (int,float) or not math.isfinite(order) or order not in (1,2):raise ValueError('Invalid dynamics_order.')
    if any(type(claims[k]) is not bool for k in ('hidden_matter','time_dependence')):raise ValueError('Claims must use strict booleans.')
    energy=float(energy_used)
    if not math.isfinite(energy) or not 0<=energy<=100:raise ValueError('Energy must be in[0,100].')
    law=sum(5 for k,value in truth.items() if claims[k]==value)
    saving=5*(1-energy/100) if prediction>=40 else 0.
    return {'prediction':float(prediction),'law':law,'saving':saving,'total':float(prediction+law+saving)}


def _variance(truth):
    flat=truth.reshape(-1,2)
    return float(np.mean(np.sum((flat-flat.mean(axis=0))**2,axis=-1)))


def evaluate_model(candidate, calibration, claims, energy_used):
    """candidate.predict(case) is evaluated on independent hidden initial states.

    No test truth or per-component score may be returned to the discovery
    model. Invalid predictions invalidate the whole world's prediction part.
    """
    world=calibration['world']
    truth_labels=json.loads((ROOT/'claims_truth.json').read_text(encoding='utf8'))['truth_by_world'][world]
    rows=[]
    all_truth=[]
    all_errors=[]
    invalid=[]
    by_group={}
    for case,record in zip(calibration['cases'],calibration['truths']):
        truth=np.asarray(record['positions'],dtype=np.float64)
        all_truth.append(truth.reshape(-1,2))
        try:
            predicted=np.asarray(candidate.predict(case),dtype=np.float64)
            if predicted.shape!=truth.shape or not np.isfinite(predicted).all():raise ValueError('Invalid predicted array.')
            err=np.sum((predicted-truth)**2,axis=-1)
            if not np.isfinite(err).all():raise ValueError('Nonfinite error.')
            all_errors.append(err.ravel())
            mse=float(err.mean())
            variance=_variance(truth)
            e=mse/max(variance,1e-12)
            rows.append({'name':case['name'],'group':case['group'],'MSE':mse,'V':variance,'e':e,
                         'P_diagnostic_only':prediction_score(mse,variance),'sample_records':int(err.size)})
            by_group.setdefault(case['group'],{'truth':[],'errors':[]})
            by_group[case['group']]['truth'].append(truth.reshape(-1,2))
            by_group[case['group']]['errors'].append(err.ravel())
        except Exception as exc:
            invalid.append({'name':case['name'],'error':f'{type(exc).__name__}: {exc}'})
    if len(rows)+len(invalid)!=len(calibration['cases']):raise RuntimeError('Missing validation cases.')
    computed_v=_variance(np.concatenate(all_truth,axis=0))
    if not np.isclose(computed_v,calibration['global_V'],rtol=1e-12,atol=1e-12):raise ValueError('Calibration variance mismatch.')
    mse=None if invalid else float(np.concatenate(all_errors).mean())
    p=0. if invalid else prediction_score(mse,computed_v)
    components=score_components(p,claims,truth_labels,energy_used)
    grouped=[]
    for name,group in by_group.items():
        v=_variance(np.concatenate(group['truth'],axis=0))
        gmse=float(np.concatenate(group['errors']).mean())
        grouped.append({'group':name,'MSE':gmse,'V':v,'e':gmse/max(v,1e-12)})
    return {'world':world,**components,'energy_used':energy_used,'claims':claims,
            'raw_MSE':mse,'global_V':computed_v,'e':None if invalid else mse/max(computed_v,1e-12),
            'invalid_cases':invalid,'case_diagnostics':rows,'group_diagnostics':grouped,
            'counterfactual_not_adopted':{
                'mean_case_e_P':0. if invalid else 80/(1+10*np.mean([r['e'] for r in rows])),
                'mean_group_e_P':0. if invalid else 80/(1+10*np.mean([r['e'] for r in grouped]))},
            'visibility':'organizer_only; public feedback strips all component and truth diagnostics'}


def weighted_total(world_results):
    if set(world_results)!=set(WORLD_ORDER):raise ValueError('A complete nine-world submission is required.')
    values=[world_results[w]['total'] for w in WORLD_ORDER]
    return float(.3*np.mean(values[:3])+.4*np.mean(values[3:6])+.3*np.mean(values[6:]))


def public_feedback(world_results):
    return {'total_score':weighted_total(world_results),
            'world_scores':{w:float(world_results[w]['total']) for w in WORLD_ORDER}}
