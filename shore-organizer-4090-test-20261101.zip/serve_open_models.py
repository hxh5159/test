"""PRIVATE organizer-only foreground vLLM 0.32.0 launcher, never distributed.

Inspect local metadata first; do not download, rename or modify checkpoints.
--print-command inspects headers and prints a shell-safe command without
requiring vLLM installed. Real execution replaces this process in foreground.
CUDA_VISIBLE_DEVICES is inherited unchanged from the allocated job.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
import os
from pathlib import Path
import re
import shlex
import sys

from preflight_open_models import DEFAULT_ROOT, MODEL_SPECS, inspect_model


MODEL_CHOICES = dict(zip(("27b", "122b", "397b"), MODEL_SPECS))
FP8_METHODS = frozenset(("fp8", "fp8_per_block"))


class LaunchError(ValueError):
    pass


def installed_vllm_version():
    try:
        return importlib.metadata.version("vllm")
    except importlib.metadata.PackageNotFoundError:
        return None


def compatible_version(value):
    """Accept 0.32.0 and local/build suffixes; do not accept 0.32.1/0.320."""
    return isinstance(value, str) and re.fullmatch(r"0\.32\.0(?:[+._-][A-Za-z0-9][A-Za-z0-9._+-]*)?", value) is not None


def precision_plan(selector, inspection):
    if inspection.get("errors"):
        raise LaunchError("Local checkpoint preflight failed: " + "; ".join(inspection["errors"]))
    weights = inspection["weights"]
    dtypes = weights["dtype_distribution"]
    total = weights["tensor_payload_size"]["bytes"]
    fp8_fraction = sum(v["bytes"] for k, v in dtypes.items() if k.startswith("F8")) / total
    integer_fraction = sum(v["bytes"] for k, v in dtypes.items() if k.startswith(("I", "U"))) / total
    dominant = max(dtypes, key=lambda k: dtypes[k]["bytes"])
    config = inspection.get("quantization_config", {})
    method = config.get("quant_method")
    method = method.lower().replace("-", "_") if isinstance(method, str) else None
    has_quant_config = inspection.get("quantization_config_present", False)
    prequantized = fp8_fraction >= .5
    if prequantized:
        if method not in FP8_METHODS:
            raise LaunchError("FP8 tensor storage requires a coherent recognized FP8 quantization_config; other/missing quantization methods are not auto-converted by this helper")
        mode, extra = "prequantized_fp8_auto_from_config", []
    elif selector == "397b":
        raise LaunchError("397b requires an existing verified FP8-stored checkpoint at a separate path; raw BF16/F16 is not launched on the default four H200 cards and is not renamed into FP8")
    elif has_quant_config or fp8_fraction > 0:
        raise LaunchError("Checkpoint precision/config is mixed or declares a different quantization method; provide a coherent FP8 checkpoint or an unquantized supported base, rather than overriding its quantization declaration")
    elif selector == "122b":
        if dominant != "BF16" or integer_fraction > .01:
            raise LaunchError("122b online conversion is supported here only for an unquantized BF16 checkpoint with vLLM 0.32.0 fp8_per_block; other quantization/dtypes need a separately validated path")
        mode, extra = "online_fp8_per_block_requested", ["--quantization", "fp8_per_block"]
    else:
        if dominant not in ("BF16", "F16", "F32") or integer_fraction > .01:
            raise LaunchError("27b default dtype=auto expects ordinary floating weights or a coherent FP8 checkpoint; other quantization requires explicit validation")
        mode, extra = "unquantized_dtype_auto", []
    return {"mode": mode, "checkpoint_dtypes": sorted(dtypes),
            "largest_payload_dtype": dominant, "checkpoint_fp8_payload_fraction": fp8_fraction,
            "checkpoint_quant_method": method, "checkpoint_is_prequantized_fp8": prequantized,
            "loadtime_quantization_requested": "fp8_per_block" if extra else None,
            "actual_load_or_quantization_verified": False,
            "served_name_is_model_provenance_proof": False}, extra


def prepare_launch(selector, *, model_path=None, model_root=DEFAULT_ROOT,
                   host="127.0.0.1", port=8000, max_model_len=32768,
                   enforce_eager=True, dry_run=False, version=None):
    if selector not in MODEL_CHOICES:
        raise LaunchError("Choose 27b, 122b or 397b")
    if type(port) is not int or not 1 <= port <= 65535:
        raise LaunchError("Port must be an integer in [1,65535]")
    if type(max_model_len) is not int or max_model_len < 1:
        raise LaunchError("max-model-len must be a positive integer")
    if not isinstance(host, str) or not host or any(ord(c) < 33 for c in host):
        raise LaunchError("Host must be a nonempty literal interface/hostname without whitespace")
    role, directory, served_name = MODEL_CHOICES[selector]
    path = Path(model_path if model_path is not None else Path(model_root) / directory).expanduser().resolve()
    inspection = inspect_model(path, role, served_name, {})
    plan, quant_args = precision_plan(selector, inspection)
    if not dry_run and not compatible_version(version):
        raise LaunchError("Actual launch requires installed vLLM 0.32.0 (local/build suffix accepted); installed version is %s. No model is loaded or package changed" % (version or "unknown/not installed"))
    command = [sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", str(path),
        "--served-model-name", served_name, "--host", host, "--port", str(port),
        "--tensor-parallel-size", "4", "--dtype", "auto",
        "--max-model-len", str(max_model_len), "--max-num-seqs", "1",
        "--gpu-memory-utilization", "0.90", "--language-model-only",
        "--reasoning-parser", "qwen3", "--generation-config", "vllm", *quant_args]
    if enforce_eager:
        command.append("--enforce-eager")
    environment = {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1"}
    record = {"schema_version": "1.0.0", "scope": "organizer_only_local_vllm_launch",
        "created_utc": datetime.now(timezone.utc).isoformat(), "selector": selector,
        "model_path": str(path), "served_model_name": served_name,
        "installed_vllm_version": version, "required_vllm_version": "0.32.0 with optional local/build suffix",
        "installed_version_accepted": compatible_version(version), "print_command_only": dry_run,
        "precision": plan, "checkpoint_tensor_payload_size": inspection["weights"]["tensor_payload_size"],
        "preflight_warnings": inspection["warnings"], "tensor_parallel_size": 4,
        "max_model_len": max_model_len, "enforce_eager": enforce_eager,
        "performance_note": "Eager mode avoids CUDA graph capture peaks and may reduce throughput; graph/eager timings are not interchangeable",
        "cuda_visible_devices": "inherited unchanged; no allocation or device override by this helper",
        "model_identity_verified": False, "successful_loading_or_inference_verified": False,
        "workflow_distribution_allowed": False, "command": command,
        "environment_overrides": environment}
    return command, environment, record


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, choices=tuple(MODEL_CHOICES))
    parser.add_argument("--model-root", default=DEFAULT_ROOT)
    parser.add_argument("--model-path", type=Path)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--max-model-len", type=int, default=32768)
    parser.add_argument("--no-enforce-eager", action="store_true", help="Allow CUDA graphs; may increase peak memory and change throughput")
    parser.add_argument("--print-command", action="store_true", help="Inspect and print only; vLLM need not be installed")
    parser.add_argument("--record", type=Path, help="Optional new private launch-plan JSON; existing files are never overwritten")
    args = parser.parse_args(argv)
    try:
        version = installed_vllm_version()
        command, additions, record = prepare_launch(args.model, model_path=args.model_path,
            model_root=args.model_root, host=args.host, port=args.port,
            max_model_len=args.max_model_len, enforce_eager=not args.no_enforce_eager,
            dry_run=args.print_command, version=version)
        if args.record:
            args.record.parent.mkdir(parents=True, exist_ok=True)
            with args.record.open("x", encoding="utf8") as stream:
                stream.write(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        print(json.dumps(record, ensure_ascii=False, allow_nan=False), file=sys.stderr, flush=True)
        printable = shlex.join(["env", *(k + "=" + v for k, v in additions.items()), *command])
        print(printable, flush=True)
        if args.print_command:
            return 0
        environment = os.environ.copy()
        environment.update(additions)
        os.execvpe(command[0], command, environment)
    except (LaunchError, OSError) as exc:
        print("Launch blocked: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
