"""Organizer-only transport adapter for the formal acceleration law API.

No true law, hidden state, validation group or scoring reference is sent to
the worker. OS account/mount isolation still belongs to the deployed service;
this local subprocess adapter alone is not a production privacy boundary.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np

PRIVATE=Path(__file__).resolve().parent
PUBLIC=Path(os.environ.get('RIFT_PUBLIC_ROOT',PRIVATE.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0,str(PUBLIC))


class OrganizerConfigurationError(RuntimeError):pass
class CandidateExecutionError(RuntimeError):pass
class InfrastructureError(RuntimeError):pass


def validate_calibration(calibration, canonical_cases):
    """Check reference shape/time/scale before any candidate is evaluated."""
    from rift_numerics import DT,sample_indices
    cases=calibration.get('cases',[]);truths=calibration.get('truths',[])
    if not cases or len(cases)!=len(truths) or len(cases)!=len(canonical_cases):
        raise OrganizerConfigurationError('Reference/case counts do not agree')
    total=0;counts=set();flat=[]
    for i,(raw,case,truth) in enumerate(zip(cases,canonical_cases,truths)):
        t_count=len(case['readout']);n_count=len(case['probes']);total+=n_count;counts.add(t_count)
        positions=np.asarray(truth.get('positions'),dtype=float)
        expected=(t_count,n_count,2)
        if positions.shape!=expected or not np.isfinite(positions).all():
            raise OrganizerConfigurationError(f'Reference positions have invalid shape/values at case{i}')
        if raw.get('name') is not None and truth.get('name') is not None and raw['name']!=truth['name']:
            raise OrganizerConfigurationError(f'Reference/case identity mismatch at case{i}')
        offsets=sample_indices(case['readout']);launch=int(sample_indices([case['t_launch']])[0])
        try:truth_ticks=sample_indices(truth['times'])
        except (KeyError,TypeError,ValueError) as exc:
            raise OrganizerConfigurationError(f'Reference actual time labels invalid at case{i}') from exc
        if not np.array_equal(truth_ticks,launch+offsets):
            raise OrganizerConfigurationError(f'Reference time labels mismatch at case{i}')
        # The local rollout accepts arbitrary legal readouts; this check is
        # for the separately chosen common official validation schedule only.
        if int(offsets[-1])%t_count or not np.array_equal(offsets,np.arange(1,t_count+1)*(int(offsets[-1])//t_count)):
            raise OrganizerConfigurationError(f'Official validation sampling schedule is inconsistent at case{i}')
        if 'velocities' in truth:
            velocity=np.asarray(truth['velocities'],dtype=float)
            if velocity.shape!=expected or not np.isfinite(velocity).all():
                raise OrganizerConfigurationError(f'Reference velocities invalid at case{i}')
        flat.append(positions.reshape(-1,2))
    if total<20 or len(counts)!=1:
        raise OrganizerConfigurationError('Official validation needs at least20 probes and one common sample count')
    if calibration.get('N_probes',total)!=total or calibration.get('T_samples',next(iter(counts)))!=next(iter(counts)):
        raise OrganizerConfigurationError('Reference sample metadata disagree with cases')
    values=np.concatenate(flat,axis=0)
    variance=float(np.mean(np.sum((values-values.mean(axis=0))**2,axis=-1)))
    declared=calibration.get('global_V')
    if isinstance(declared,bool) or not isinstance(declared,(int,float)) or not math.isfinite(declared) or declared<0:
        raise OrganizerConfigurationError('Reference variance is invalid')
    if not np.isclose(declared,variance,rtol=1e-12,atol=1e-12):
        raise OrganizerConfigurationError('Reference variance does not match the frozen clean positions')
    return True


def canonical_case(public_mission, validation_case, *, source_target_id=None):
    """Construct a whitelisted input. In particular name/group are discarded."""
    from rift.observations import case_from_observation
    from rift.law import ValidationError
    try:
        record={key:copy.deepcopy(validation_case[key]) for key in ('probes','t_launch','readout','source_properties')}
        return case_from_observation(public_mission,record,source_target_id=source_target_id)
    except (ValidationError,KeyError,TypeError,ValueError) as exc:
        raise OrganizerConfigurationError(f'Invalid organizer prediction input: {exc}') from exc


def run_law_file(law_path, case, *, timeout_seconds=120.):
    """Fixed worker execution, with organizer-input failures kept distinct."""
    from rift.prediction import validate_case
    from rift.law import validate_source,ValidationError
    try:clean=validate_case(case)
    except ValidationError as exc:raise OrganizerConfigurationError(str(exc)) from exc
    path=Path(law_path).resolve()
    source=path.read_bytes()
    validate_source(source.decode('utf-8'),source_name=str(path))  # Static only.
    expected_sha=hashlib.sha256(source).hexdigest()
    if isinstance(timeout_seconds,bool) or not math.isfinite(float(timeout_seconds)) or timeout_seconds<=0:
        raise OrganizerConfigurationError('timeout_seconds must be finite and positive')
    temporary_root=PRIVATE/'checks/.worker-temp'
    temporary_root.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='law_',dir=temporary_root) as directory:
        candidate=Path(directory)/'law.py';candidate.write_bytes(source)
        command=[sys.executable,'-I','-X','utf8',str(PUBLIC/'rift/worker.py'),'--law',str(candidate)]
        try:
            completed=subprocess.run(command,input=json.dumps(clean,ensure_ascii=False,allow_nan=False),
                text=True,encoding='utf-8',capture_output=True,cwd=directory,
                timeout=float(timeout_seconds),check=False)
        except subprocess.TimeoutExpired as exc:
            raise CandidateExecutionError('Candidate worker exceeded the configured diagnostic runtime limit') from exc
        except OSError as exc:
            raise InfrastructureError('Unable to start the official candidate worker') from exc
        if len(completed.stdout)>16*1024*1024:
            raise CandidateExecutionError('Candidate output exceeded the technical transport limit')
        try:payload=json.loads(completed.stdout)
        except (ValueError,TypeError) as exc:
            raise InfrastructureError('Official worker returned no valid protocol response') from exc
        status=payload.get('status')
        if status=='invalid_case':raise OrganizerConfigurationError(str(payload.get('error')))
        if status in ('invalid_law','candidate_error'):
            raise CandidateExecutionError(json.dumps(payload,ensure_ascii=False))
        if status!='ok' or completed.returncode!=0:
            raise InfrastructureError('Unexpected official worker status')
        if payload.get('law_sha256')!=expected_sha:
            raise InfrastructureError('Candidate source identity changed during execution')
        return payload


class LawFileCandidate:
    """Bridge to the existing score calculator after organizer preflight."""
    def __init__(self, law_path, mission, cases, *, source_target_id=None,timeout_seconds=120.,executor=None):
        self.law_path=Path(law_path).resolve();self.timeout_seconds=timeout_seconds
        self.executor=executor or run_law_file
        self._cases={id(case):canonical_case(mission,case,source_target_id=source_target_id) for case in cases}
        self.last_execution=[]
    def predict(self,case):
        if id(case) not in self._cases:
            raise OrganizerConfigurationError('Case was not included in organizer preflight')
        output=self.executor(self.law_path,self._cases[id(case)],timeout_seconds=self.timeout_seconds)
        self.last_execution.append({'law_sha256':output['law_sha256'],'status':'ok'})
        return output['result']['positions']


def evaluate_law_file(law_path,mission,calibration,claims,energy_used,*,source_target_id=None,timeout_seconds=120.,executor=None):
    """No result is emitted when organizer input/infrastructure is invalid."""
    from trial_evaluation import evaluate_model
    from rift.law import validate_law
    validate_law(law_path)
    candidate=LawFileCandidate(law_path,mission,calibration['cases'],source_target_id=source_target_id,
                               timeout_seconds=timeout_seconds,executor=executor)
    validate_calibration(calibration,[candidate._cases[id(case)] for case in calibration['cases']])
    # Existing scorer catches candidate failures. System/config failures are
    # trapped separately, remembered and re-raised rather than assigned P=0.
    system_failures=[]
    original=candidate.predict
    def guarded(case):
        if system_failures:raise system_failures[0]
        try:return original(case)
        except (OrganizerConfigurationError,InfrastructureError) as exc:
            system_failures.append(exc);raise
    candidate.predict=guarded
    result=evaluate_model(candidate,calibration,claims,energy_used)
    if system_failures:raise system_failures[0]
    return result


def evaluate_frozen_submission(submission,mission,calibration,energy_used,*,source_target_id=None,timeout_seconds=120.,executor=None):
    """Use one paired frozen artifact; never mix a law with another claims file."""
    source=submission.law_bytes
    if hashlib.sha256(source).hexdigest()!=submission.manifest['files']['law.py']['sha256']:
        raise InfrastructureError('Frozen law does not match the paired manifest')
    if hashlib.sha256(submission.claims_bytes).hexdigest()!=submission.manifest['files']['claims.json']['sha256']:
        raise InfrastructureError('Frozen claims do not match the paired manifest')
    root=PRIVATE/'checks/.worker-temp';root.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='snapshot_',dir=root) as directory:
        path=Path(directory)/'law.py';path.write_bytes(source)
        result=evaluate_law_file(path,mission,calibration,submission.claims,energy_used,
                                 source_target_id=source_target_id,timeout_seconds=timeout_seconds,executor=executor)
    result['artifact_identity']={'snapshot_id':submission.snapshot_id,
        'law_sha256':submission.law_sha256,'claims_sha256':submission.claims_sha256,
        'manifest_sha256':submission.manifest_sha256}
    return result
