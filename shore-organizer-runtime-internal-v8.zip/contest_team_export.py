"""Export one team's own records and code, never organizer diagnostics.

Only the trusted per-attempt team-export area is copied by default. Optional
agent-output is a distinct directory written solely by the stopped team agent;
it can contain that team's trained adapters/weights. Private score/session/
reference/store/log files are never traversed by this exporter.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

from contest_scoreboard import Scoreboard,WORLDS,QueueError

ALLOWED_FILES=('mission.json','archive.json','law.py','claims.json','report.md')


def _file_sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def export_own(board,job_id,team_id,run_root,output,*,include_agent_output=False):
    status=board.status(job_id,team_id=team_id)
    if status['state'] not in ('completed','infrastructure_failed'):
        raise QueueError('Export only after the selected attempt has stopped')
    root=Path(run_root).resolve();job=root/job_id
    if job.is_symlink() or not job.resolve().is_relative_to(root):raise QueueError('Invalid private job directory')
    attempts=sorted((p for p in job.glob('attempt-*') if p.is_dir() and not p.is_symlink()),key=lambda p:p.stat().st_mtime_ns)
    if not attempts:raise QueueError('This job has no recorded attempt')
    attempt=attempts[-1]
    identity=json.loads((attempt/'job.json').read_text(encoding='utf8'))
    if identity.get('job_id')!=job_id or identity.get('team_id')!=team_id:
        raise QueueError('Export attempt identity does not match the accepted team')
    output=Path(output).resolve()
    if output.suffix.lower()!='.zip' or output.exists():raise QueueError('Choose a new explicit ZIP output filename')
    files=[]
    for world in WORLDS:
        source=attempt/'team-export'/world
        if source.is_symlink():raise QueueError('Symlinks are not allowed in the export area')
        for name in ALLOWED_FILES:
            path=source/name
            if path.is_symlink():raise QueueError('Symlinks are not allowed in the export area')
            if path.is_file():files.append((path,f'{world}/{name}'))
        if include_agent_output:
            owned=attempt/world/'output'
            if owned.is_symlink():raise QueueError('Invalid agent-owned output directory')
            for path in sorted(owned.rglob('*')) if owned.exists() else []:
                if path.is_symlink():raise QueueError('Agent output export does not follow symlinks')
                if path.is_dir():continue
                if not path.is_file() or not path.resolve().is_relative_to(owned.resolve()):
                    raise QueueError('Agent output must contain ordinary confined files')
                files.append((path,f'agent-output/{world}/'+path.relative_to(owned).as_posix()))
    output.parent.mkdir(parents=True,exist_ok=True)
    # Opening with x preserves any pre-existing destination even under a race.
    with ZipFile(output,'x',compression=ZIP_DEFLATED) as archive:
        for path,name in files:archive.write(path,name)
        archive.writestr('EXPORT_NOTICE.txt','本包仅包含本攻坚组合法取得的观测与自身代码/产物。\n'
            '不包含官方验证轨迹、真值、评分分项或内部诊断。agent-output若存在，是队伍自身写出的文件。\n')
    return {'job_id':job_id,'team_id':team_id,'file_count':len(files)+1,
            'includes_agent_output':bool(include_agent_output),
            'archive_sha256':_file_sha(output)}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('db','job-id','team-id','run-root','output'):p.add_argument('--'+name,required=True)
    p.add_argument('--include-agent-output',action='store_true')
    a=p.parse_args(argv)
    result=export_own(Scoreboard(a.db),a.job_id,a.team_id,a.run_root,a.output,include_agent_output=a.include_agent_output)
    print(json.dumps(result,ensure_ascii=False));return 0


if __name__=='__main__':raise SystemExit(main())
