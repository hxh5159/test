"""Create an explicitly private organizer runtime ZIP from fixed allowlists.

Nothing is written unless --output selects a new ZIP filename. Default bundles
contain no profile, validation cache, model API client, run log, credential,
research memory or known-truth candidate fixture. They DO contain the real
simulator and must never enter public Git or contestant distribution.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


PRIVATE_ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(os.environ.get('RIFT_PUBLIC_ROOT', PRIVATE_ROOT.parent/'DiscoverPhysics')).resolve()
PRIVATE_FILES = (
    'contest_simulator.py', 'contest_world_definitions.json', 'claims_truth.json',
    'trial_console.py', 'trial_catalog.py', 'trial_evaluation.py',
    'law_program_evaluation.py', 'law_submission_store.py', 'contest_console_service.py',
    'contest_job_runner.py', 'contest_scoreboard.py', 'contest_execution.py',
    'contest_platform.py', 'contest_intake.py', 'contest_team_export.py', 'contest_worker.py',
    'package_contest_runtime.py', 'README_正式赛题部署.txt', 'Dockerfile.candidate',
)
PUBLIC_FILES = (
    'LICENSE',
    'rift/__init__.py', 'rift/console.py', 'rift/submission.py', 'rift/law.py',
    'rift/observations.py', 'rift/prediction.py', 'rift/worker.py',
    'rift_numerics/__init__.py', 'rift_numerics/rollout.py',
    'scripts/validate_claims.py', 'scripts/validate_law.py', 'scripts/validate_submission.py',
    'docs/contracts/claims.schema.json', 'docs/contracts/law_api.json',
    'docs/contracts/law_case.schema.json', 'docs/contracts/submission.schema.json',
)
WORLDS = ('Adam', 'Lilith', 'Tabris', 'Sachiel', 'Ramiel', 'Matriel', 'Leliel', 'Arael', 'Lilin')
_PROFILE_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z')
_PROFILE_FIELDS = frozenset((
    'profile_version', 'profile_id', 'status', 'release_approved', 'runtime_limits_approved',
    'domains_and_validation_approved', 'created_at', 'public_runtime_sha256',
    'private_source_sha256', 'startup_seconds', 'candidate_timeout_seconds',
    'shutdown_seconds', 'resource_values_status', 'policies', 'agent_limits',
    'candidate_limits', 'gpu_devices', 'candidate_image', 'model_mounts', 'worlds',
))
NOTICE = '''指挥部私有运行包

本包含正式九宇宙真实模拟器、命题配置和定律判定真值。
禁止上传公开Git仓库、发送攻坚组或放入参赛镜像、公开下载目录。
public/子目录为运行所需公开SDK；整个ZIP仍是指挥部私有资料。

解压到独立私有目录后，在远端Linux设置：
  export RIFT_PUBLIC_ROOT="$(pwd)/public"
  python contest_platform.py --help

Python环境须已具备正式镜像要求的NumPy/SciPy；本包不下载模型、不连接API、
不安装依赖、不启动服务，也不包含权重、任务数据库或运行日志。
默认无profile和验证参考；只有显式--profile才加入指定配置及其声明的参考。
打包不批准配置发布，internal_validation状态不会自动变成released。
正式操作见README_正式赛题部署.txt，文件清单和摘要见bundle-manifest.json。
'''


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, indent=2)+'\n').encode('utf-8')


def _regular_in_root(root, relative):
    lexical = root/relative
    if lexical.is_symlink() or not lexical.is_file() or not lexical.resolve().is_relative_to(root):
        raise ValueError('Required allowlisted source is missing or not an in-root regular file: '+relative)
    current = root
    for part in Path(relative).parts:
        current /= part
        if current.is_symlink():
            raise ValueError('Allowlisted source path must not contain a symlink: '+relative)
    return lexical


def _profiles_payloads(profiles):
    payloads, identities = {}, []
    for supplied in profiles:
        lexical = Path(supplied).expanduser().absolute()
        if lexical.is_symlink() or not lexical.is_file() or lexical.suffix.lower() != '.json':
            raise ValueError('Explicit profile must be a regular JSON file')
        path = lexical.resolve()
        value = json.loads(path.read_text(encoding='utf-8-sig'))
        if not isinstance(value, dict) or set(value)-_PROFILE_FIELDS:
            raise ValueError('Profile has unknown root fields; do not bundle secrets or unrelated metadata')
        profile_id = value.get('profile_id')
        if (value.get('profile_version') != '1.0.0' or not isinstance(profile_id, str)
                or not _PROFILE_ID.fullmatch(profile_id)
                or value.get('status') not in ('internal_validation', 'released')
                or set(value.get('worlds', {})) != set(WORLDS)):
            raise ValueError('Explicit profile must identify version, status and all nine worlds')
        if profile_id in identities:
            raise ValueError('Duplicate profile identities are not accepted')
        identities.append(profile_id)
        prefix = 'profiles/'+profile_id+'/'
        for world in WORLDS:
            entry = value['worlds'][world]
            if not isinstance(entry, dict) or set(entry) != {'config', 'calibration_file', 'calibration_sha256'}:
                raise ValueError('Profile world entries must contain only config and reference identity')
            declared = entry['calibration_file']
            if not isinstance(declared, str):
                raise ValueError('Profile reference path must be text')
            relative = Path(declared)
            reference = relative if relative.is_absolute() else path.parent/relative
            resolved = reference.resolve()
            if not resolved.is_relative_to(path.parent) or resolved.suffix.lower() != '.json':
                raise ValueError('Profile references must remain within the profile directory')
            checked = _regular_in_root(path.parent, reference.absolute().relative_to(path.parent).as_posix())
            raw = checked.read_bytes()
            if _sha(raw) != entry['calibration_sha256']:
                raise ValueError('Explicit profile reference hash mismatch')
            name = 'references/'+world+'.json'
            payloads[prefix+name] = raw
            entry['calibration_file'] = name
        payloads[prefix+'profile.json'] = _json_bytes(value)
    return payloads, identities


def build_runtime_package(output, *, profiles=(), private_root=PRIVATE_ROOT, public_root=PUBLIC_ROOT):
    """Write one NEW private ZIP; fixed files plus explicitly named profiles."""
    private_root, public_root = Path(private_root).resolve(), Path(public_root).resolve()
    lexical_output = Path(output).expanduser().absolute()
    output = lexical_output.resolve()
    if output.suffix.lower() != '.zip' or output.exists() or lexical_output.is_symlink():
        raise ValueError('Select a new explicit .zip output; existing files are never overwritten')
    if output.is_relative_to(public_root) or lexical_output.is_relative_to(public_root):
        raise ValueError('A private organizer bundle must not be written inside the public repository')
    payloads = {name: _regular_in_root(private_root, name).read_bytes() for name in PRIVATE_FILES}
    payloads.update({'public/'+name: _regular_in_root(public_root, name).read_bytes() for name in PUBLIC_FILES})
    optional, profile_ids = _profiles_payloads(profiles)
    payloads.update(optional)
    payloads['PRIVATE_RUNTIME_NOTICE.txt'] = NOTICE.encode('utf-8')
    manifest = {'bundle_version': '1.0.0', 'audience': 'organizer_only',
                'contains_true_simulator': True, 'public_distribution_allowed': False,
                'observation_noise_version': '1.1.0',
                'velocity_noise_fraction': 1e-4,
                'exploration_wall_clock_seconds': 600,
                'scientific_dataset_scope': 'Legacy packaged nine-world definitions and validation; new six-plus-nine designs and selected coverage are not migrated by this instrument update',
                'profile_ids': profile_ids, 'default_validation_cache_included': False,
                'files': [{'path': name, 'sha256': _sha(raw), 'size': len(raw)}
                          for name, raw in sorted(payloads.items())]}
    payloads['bundle-manifest.json'] = _json_bytes(manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with output.open('xb') as stream:
            created = True
            with ZipFile(stream, 'w', compression=ZIP_DEFLATED, compresslevel=6) as archive:
                for name, raw in sorted(payloads.items()):
                    info = ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
                    info.compress_type = ZIP_DEFLATED
                    info.external_attr = 0o600 << 16
                    archive.writestr(info, raw)
    except Exception:
        if created:
            output.unlink(missing_ok=True)  # Only the new partial file created above.
        raise
    return {'output': str(output), 'audience': 'organizer_only', 'files': len(payloads),
            'profile_ids': profile_ids, 'sha256': _sha(output.read_bytes())}


def main(argv=None):
    parser = argparse.ArgumentParser(description='显式生成指挥部私有运行ZIP，严禁公开分发')
    parser.add_argument('--output', required=True, help='新的私有.zip路径，不得放在公开仓库内')
    parser.add_argument('--profile', action='append', default=[], help='显式加入一份profile及其声明的参考，可重复')
    args = parser.parse_args(argv)
    print(json.dumps(build_runtime_package(args.output, profiles=args.profile), ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
