"""Organizer-only persistent queue, complete-submission ranking and feedback.

Only already computed nine-world totals enter ranking.  No observations,
candidate predictions or model calls are made for the exact tie statistic.
This database is private; public methods explicitly select allowed fields.
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import contextmanager
import itertools
import json
import math
import os
from pathlib import Path
import sqlite3
import sys
from uuid import uuid4

import numpy as np

PUBLIC=Path(os.environ.get('RIFT_PUBLIC_ROOT',Path(__file__).resolve().parent.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0,str(PUBLIC))
from rift.submission import validate_manifest,manifest_digest,SubmissionError

WORLDS = ('Adam', 'Lilith', 'Tabris', 'Sachiel', 'Ramiel', 'Matriel',
          'Leliel', 'Arael', 'Lilin')
WEIGHTS = (.3, .4, .3)


class QueueError(ValueError):
    pass


def utc_timestamp(value=None):
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError as exc:
            raise QueueError('Timestamp must be an ISO8601 value with timezone') from exc
    else:
        raise QueueError('Timestamp must be a timezone-aware datetime or string')
    if parsed.tzinfo is None:
        raise QueueError('Timestamp requires a timezone')
    return parsed.astimezone(timezone.utc).isoformat()


def clean_world_scores(values):
    if not isinstance(values, dict) or set(values) != set(WORLDS):
        raise QueueError('Exactly one score for every world in one submission is required')
    result = {}
    for world in WORLDS:
        value = values[world]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise QueueError('World scores must be finite real numbers')
        number = float(value)
        if not math.isfinite(number) or not 0 <= number <= 100:
            raise QueueError('World scores must be in [0,100]')
        result[world] = number
    return result


def total_score(values):
    scores = clean_world_scores(values)
    ordered = [scores[w] for w in WORLDS]
    return float(sum(weight * float(np.mean(ordered[i*3:i*3+3]))
                     for i, weight in enumerate(WEIGHTS)))


def exact_interval_width(values):
    ordered = [clean_world_scores(values)[w] for w in WORLDS]
    samples = []
    for tier in range(3):
        triplet = ordered[3*tier:3*tier+3]
        samples.append(np.array([np.mean([triplet[i] for i in indices])
                                 for indices in itertools.product(range(3), repeat=3)], dtype=float))
    combined = (.3*samples[0][:, None, None] + .4*samples[1][None, :, None]
                + .3*samples[2][None, None, :]).reshape(-1)
    assert combined.size == 19683
    lower, upper = np.quantile(combined, [.025, .975], method='linear')
    return float(upper-lower)


class Scoreboard:
    """Trusted intake/worker API. No candidate can connect to this database.

    If a deadline is configured, the operator must explicitly select the
    accepted_at policy. No still-pending contest policy is silently assumed.
    """
    def __init__(self, path, *, deadline=None, deadline_policy=None,scope=None):
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.deadline = utc_timestamp(deadline) if deadline is not None else None
        if self.deadline is not None and deadline_policy != 'accepted_at':
            raise QueueError('Configure the confirmed deadline policy explicitly')
        self.deadline_policy = deadline_policy
        if scope not in (None,'internal_validation','official'):
            raise QueueError('Unknown scoreboard execution scope')
        with self._connect() as connection:
            connection.executescript('''
              CREATE TABLE IF NOT EXISTS settings(name TEXT PRIMARY KEY,value TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS jobs(
                job_id TEXT PRIMARY KEY, team_id TEXT NOT NULL,
                accepted_at TEXT NOT NULL, state TEXT NOT NULL,
                manifest_json TEXT NOT NULL, manifest_sha256 TEXT NOT NULL,
                image_digest TEXT NOT NULL, private_spec_json TEXT NOT NULL,
                worker_id TEXT, completed_at TEXT, world_scores_json TEXT,
                total_score REAL, interval_width REAL, private_error TEXT);
              CREATE INDEX IF NOT EXISTS jobs_state_time ON jobs(state,accepted_at);
              CREATE INDEX IF NOT EXISTS jobs_team ON jobs(team_id,state);
            ''')
            stored={row['name']:row['value'] for row in connection.execute('SELECT name,value FROM settings')}
            recorded_scope=stored.get('scope')
            if recorded_scope is not None and scope is not None and recorded_scope!=scope:
                raise QueueError('Internal validation and official competition require separate databases')
            self.scope=recorded_scope or scope or 'internal_validation'
            if recorded_scope is None:
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('scope',self.scope))
            recorded_deadline=stored.get('deadline')
            if recorded_deadline is not None:
                if self.deadline is not None and self.deadline!=recorded_deadline:
                    raise QueueError('The competition deadline is frozen in this database')
                if deadline_policy is not None and deadline_policy!=stored['deadline_policy']:
                    raise QueueError('The competition deadline policy is frozen in this database')
                self.deadline,self.deadline_policy=recorded_deadline,stored['deadline_policy']
            elif self.deadline is not None:
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('deadline',self.deadline))
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('deadline_policy',self.deadline_policy))

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        try:
            connection.execute('PRAGMA foreign_keys=ON')
            with connection:
                yield connection
        finally:
            connection.close()

    def enqueue(self, manifest, *, manifest_sha256, image_digest, private_spec=None,
                accepted_at=None, authenticated_team_id=None):
        try:manifest=validate_manifest(manifest)
        except SubmissionError as exc:raise QueueError(str(exc)) from exc
        team_id = manifest['team_id']
        if authenticated_team_id is not None and team_id != authenticated_team_id:
            raise QueueError('Manifest team_id does not match authenticated intake')
        if (not isinstance(manifest_sha256, str) or len(manifest_sha256) != 64
                or any(c not in '0123456789abcdef' for c in manifest_sha256)):
            raise QueueError('Frozen manifest SHA256 required')
        if manifest_digest(manifest)!=manifest_sha256:
            raise QueueError('Frozen manifest SHA256 does not match its contents')
        # The operator resolves mutable tags before intake. No candidate gets
        # to select host mounts, sockets or Docker privileges via this field.
        if (not isinstance(image_digest,str) or not image_digest.startswith('sha256:') or len(image_digest)!=71
                or any(c not in '0123456789abcdef' for c in image_digest[7:])):
            raise QueueError('Resolved immutable container image digest required')
        timestamp = utc_timestamp(accepted_at)
        if self.deadline is not None and timestamp > self.deadline:
            raise QueueError('Submission was not accepted before the configured deadline')
        job_id = uuid4().hex
        with self._connect() as connection:
            connection.execute('''INSERT INTO jobs(job_id,team_id,accepted_at,state,manifest_json,
                manifest_sha256,image_digest,private_spec_json) VALUES(?,?,?,'queued',?,?,?,?)''',
                (job_id, team_id, timestamp,
                 json.dumps(manifest, ensure_ascii=False, allow_nan=False, sort_keys=True),
                 manifest_sha256, image_digest,
                 json.dumps(private_spec or {}, ensure_ascii=False, allow_nan=False, sort_keys=True)))
        return self.status(job_id, team_id=team_id)

    def claim_next(self, worker_id):
        if not isinstance(worker_id, str) or not worker_id:
            raise QueueError('Worker identity required')
        with self._connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            row = connection.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY accepted_at,job_id LIMIT 1").fetchone()
            if row is None:
                return None
            connection.execute("UPDATE jobs SET state='running',worker_id=? WHERE job_id=? AND state='queued'",
                               (worker_id, row['job_id']))
            value = dict(row)
            value['execution_scope']=self.scope
            value['state'], value['worker_id'] = 'running', worker_id
            value['manifest'] = json.loads(value.pop('manifest_json'))
            value['private_spec'] = json.loads(value.pop('private_spec_json'))
            return value

    def complete(self, job_id, scores, *, worker_id, completed_at=None):
        cleaned = clean_world_scores(scores)
        total, width = total_score(cleaned), exact_interval_width(cleaned)
        with self._connect() as connection:
            changed = connection.execute('''UPDATE jobs SET state='completed',completed_at=?,
                world_scores_json=?,total_score=?,interval_width=?,private_error=NULL
                WHERE job_id=? AND state='running' AND worker_id=?''',
                (utc_timestamp(completed_at), json.dumps(cleaned, ensure_ascii=False),
                 total, width, job_id, worker_id)).rowcount
            if changed != 1:
                raise QueueError('Only the assigned running worker can complete a job')
        return self.status(job_id)

    def fail_infrastructure(self, job_id, *, worker_id, private_error):
        with self._connect() as connection:
            changed = connection.execute("UPDATE jobs SET state='infrastructure_failed',private_error=? WHERE job_id=? AND state='running' AND worker_id=?",
                (str(private_error), job_id, worker_id)).rowcount
            if changed != 1:
                raise QueueError('Job is not assigned to this worker')

    def requeue_infrastructure(self, job_id):
        # Explicit organizer recovery reuses the accepted immutable version;
        # it is not a candidate retry or a new acceptance after the deadline.
        with self._connect() as connection:
            changed = connection.execute("UPDATE jobs SET state='queued',worker_id=NULL WHERE job_id=? AND state='infrastructure_failed'",
                                         (job_id,)).rowcount
            if changed != 1:
                raise QueueError('Only an infrastructure-failed job can be requeued')

    def status(self, job_id, *, team_id=None):
        with self._connect() as connection:
            row = connection.execute('SELECT * FROM jobs WHERE job_id=?', (job_id,)).fetchone()
        if row is None or (team_id is not None and row['team_id'] != team_id):
            raise QueueError('Unknown submission')
        result = {'job_id': row['job_id'], 'team_id': row['team_id'],
                  'accepted_at': row['accepted_at'], 'state': row['state']}
        if row['state'] == 'completed':
            result['total_score'] = row['total_score']
            result['world_scores'] = json.loads(row['world_scores_json'])
        return result

    def leaderboard(self):
        with self._connect() as connection:
            rows = connection.execute("SELECT * FROM jobs WHERE state='completed' ORDER BY total_score DESC, interval_width ASC, accepted_at,job_id").fetchall()
        best, ordered = set(), []
        last_key, rank = None, 0
        for row in rows:
            if row['team_id'] in best:
                continue
            best.add(row['team_id'])
            key = (row['total_score'], row['interval_width'])
            if key != last_key:
                rank = len(ordered)+1
                last_key = key
            entry = {'rank': rank, 'team_id': row['team_id'], 'job_id': row['job_id'],
                     'total_score': row['total_score'],
                     'world_scores': json.loads(row['world_scores_json'])}
            ordered.append(entry)
        return ordered


__all__ = ['Scoreboard', 'QueueError', 'WORLDS', 'clean_world_scores',
           'total_score', 'exact_interval_width', 'utc_timestamp']
