"""Trusted organizer CLI: prepare, accept, run, rank and view submissions.

Never distribute this module, private profiles, simulator or database to teams.
No command downloads models, contacts a model API or publishes a web service
unless the operator explicitly invokes the corresponding operation.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import subprocess
import sys

PRIVATE=Path(__file__).resolve().parent
PUBLIC=Path(os.environ.get('RIFT_PUBLIC_ROOT',PRIVATE.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0,str(PUBLIC))

from rift.submission import load_manifest,manifest_digest
from contest_scoreboard import Scoreboard,WORLDS
from contest_execution import (ContainerLimits,DockerBackend,LocalDiagnosticBackend,immutable_image,public_runtime_digest)
from law_program_evaluation import OrganizerConfigurationError,InfrastructureError


def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


PROFILE_SOURCES=('contest_simulator.py','contest_world_definitions.json','claims_truth.json',
    'trial_console.py','trial_evaluation.py','law_program_evaluation.py',
    'law_submission_store.py','contest_console_service.py','contest_execution.py',
    'contest_scoreboard.py','contest_job_runner.py','contest_platform.py',
    'contest_intake.py','contest_team_export.py','contest_worker.py')


def read_profile(path,*,require_released=False):
    path=Path(path).resolve()
    value=json.loads(path.read_text(encoding='utf-8-sig'))
    if value.get('profile_version')!='1.0.0' or set(value.get('worlds',{}))!=set(WORLDS):
        raise OrganizerConfigurationError('Profile must explicitly configure all nine worlds')
    if value.get('status') not in ('internal_validation','released'):
        raise OrganizerConfigurationError('Unknown profile release status')
    for name in ('startup_seconds','candidate_timeout_seconds','shutdown_seconds'):
        n=value.get(name)
        if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) or n<=0:
            raise OrganizerConfigurationError(f'Explicit positive {name} required')
    if require_released:
        if value['status']!='released' or value.get('release_approved') is not True:
            raise OrganizerConfigurationError('Profile is not approved for official competition')
        policies=value.get('policies',{})
        if policies.get('cross_submission_memory') not in ('allow_own_legal_artifacts','restricted_explicit_policy'):
            raise OrganizerConfigurationError('Confirm the observation/training/persistence policy before release')
        if policies.get('deadline')!='accepted_at':
            raise OrganizerConfigurationError('Confirm the intake deadline policy before release')
        if not value.get('runtime_limits_approved') or not value.get('domains_and_validation_approved'):
            raise OrganizerConfigurationError('Explicit approval of formal ranges and runtime resource profile required')
        if value.get('public_runtime_sha256')!=public_runtime_digest():
            raise OrganizerConfigurationError('Released SDK identity differs from the frozen profile')
        if value.get('private_source_sha256')!={name:_sha(PRIVATE/name) for name in PROFILE_SOURCES}:
            raise OrganizerConfigurationError('Released organizer runtime/source identity differs from the frozen profile')
    for world,entry in value['worlds'].items():
        relative=Path(entry['calibration_file'])
        entry['calibration_file']=str((path.parent/relative).resolve() if not relative.is_absolute() else relative.resolve())
        if not Path(entry['calibration_file']).is_file() or _sha(entry['calibration_file'])!=entry.get('calibration_sha256'):
            raise OrganizerConfigurationError('Private reference file is missing or differs from the frozen profile')
        if entry.get('config',{}).get('world_id')!=world:
            raise OrganizerConfigurationError('World configuration identity mismatch')
        if entry['config'].get('energy_budget')!=100 or entry['config'].get('observe_calls')!=20 or entry['config'].get('wall_clock_seconds')!=3600:
            raise OrganizerConfigurationError('Profile must retain the confirmed 100/20/3600 exploration rules')
    return value


def prepare_profile(output):
    """Explicit offline reference preparation; no change to any true force.

    Uses the existing calibration routine and its convergence checks/caches.
    It prepares an INTERNAL profile, not approval of the provisional domains.
    """
    from trial_catalog import trial_config,calibrate_world
    output=Path(output).resolve()
    if output.exists():raise OrganizerConfigurationError('Choose a new profile filename; existing versions are immutable')
    directory=output.parent/(output.stem+'-references');directory.mkdir(parents=True,exist_ok=True)
    entries={}
    for world in WORLDS:
        reference=calibrate_world(world)
        if not reference.get('all_cases_converged'):
            raise OrganizerConfigurationError('Reference convergence checks failed; do not release this profile')
        path=directory/(world+'.json')
        path.write_text(json.dumps(reference,ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf8')
        entries[world]={'config':trial_config(world),'calibration_file':str(path.relative_to(output.parent)),
                        'calibration_sha256':_sha(path)}
    value={'profile_version':'1.0.0','profile_id':output.stem,'status':'internal_validation',
           'release_approved':False,'runtime_limits_approved':False,'domains_and_validation_approved':False,
           'created_at':datetime.now(timezone.utc).isoformat(),
           'public_runtime_sha256':public_runtime_digest(),
           'private_source_sha256':{name:_sha(PRIVATE/name) for name in PROFILE_SOURCES},
           'startup_seconds':900,'candidate_timeout_seconds':120,'shutdown_seconds':30,
           'resource_values_status':'diagnostic examples, not frozen contest resource limits',
           'policies':{'cross_submission_memory':'allow_own_legal_artifacts','deadline':'accepted_at'},
           'agent_limits':{'cpus':32,'memory':'256g','pids':4096,'tmp_mb':8192},
           'candidate_limits':{'cpus':2,'memory':'8g','pids':128,'tmp_mb':256},
           'gpu_devices':['0','1','2','3'],'candidate_image':None,
           'model_mounts':[],'worlds':entries}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return {'profile_id':value['profile_id'],'status':value['status'],'world_count':len(entries)}


def make_world_factory(profile):
    from contest_simulator import ContestSimulator
    from trial_console import TrialConsole
    def factory(world):
        entry=profile['worlds'][world]
        reference=json.loads(Path(entry['calibration_file']).read_text(encoding='utf8'))
        simulator=ContestSimulator(world)
        if reference.get('simulator_cache_token')!=simulator.cache_token:
            raise OrganizerConfigurationError('Private physics/reference version differs; prepare a new profile')
        cfg=entry['config'];region=cfg['launch_region']
        length=math.sqrt((region['radius_min']**2+region['radius_max']**2)/2)
        # New independent observation noise for this independent run.  Seeds
        # may be recorded privately for audit, never selected by contestants.
        seed=int.from_bytes(os.urandom(16),'big')
        console=TrialConsole(world,sigma=.01*length,seed=seed,config=cfg)
        return console,reference
    return factory


def inspect_image(image,*,docker='docker'):
    try:
        result=subprocess.run([docker,'image','inspect','--format','{{.Id}}',image],
                              capture_output=True,text=True,encoding='utf8',timeout=30,check=False)
    except (OSError,subprocess.TimeoutExpired) as exc:raise InfrastructureError('Cannot inspect the operator-provided image') from exc
    if result.returncode!=0:raise InfrastructureError('Image is unavailable locally; build/import it before intake')
    return immutable_image(result.stdout.strip())


_BOARD_HTML='''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>彼岸挑战赛成绩</title>
<style>body{font:16px system-ui,sans-serif;margin:3rem auto;padding:0 1rem;max-width:1200px;color:#17212b}
table{border-collapse:collapse;width:100%;overflow:auto}th,td{padding:.7rem;border-bottom:1px solid #ddd;text-align:right}
th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}small{color:#586779}</style>
<h1>彼岸物理规律发现挑战赛</h1><p>各攻坚组最高一次完整提交成绩</p><small id="state">正在读取成绩</small>
<div style="overflow:auto"><table><thead><tr id="head"></tr></thead><tbody id="rows"></tbody></table></div>
<script>const worlds=['Adam','Lilith','Tabris','Sachiel','Ramiel','Matriel','Leliel','Arael','Lilin'];
for(const t of ['排名','攻坚组','总分',...worlds]){let e=document.createElement('th');e.textContent=t;document.querySelector('#head').append(e)}
async function refresh(){try{let r=await fetch('/api/leaderboard',{cache:'no-store'});if(!r.ok)throw Error();let d=await r.json();
const body=document.querySelector('#rows');body.replaceChildren();for(const row of d.leaderboard){let tr=document.createElement('tr');
for(const v of [row.rank,row.team_id,row.total_score,...worlds.map(w=>row.world_scores[w])]){let td=document.createElement('td');td.textContent=typeof v==='number'&&!Number.isInteger(v)?v.toFixed(4):String(v);tr.append(td)}body.append(tr)}
document.querySelector('#state').textContent='已更新 '+new Date().toLocaleTimeString()}catch(e){document.querySelector('#state').textContent='暂时无法读取成绩，请稍后重试'}}refresh();setInterval(refresh,5000);</script></html>'''


def make_leaderboard_server(board,host='127.0.0.1',port=8080):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):
            if self.path=='/':data=_BOARD_HTML.encode('utf8');kind='text/html; charset=utf-8'
            elif self.path=='/api/leaderboard':
                data=json.dumps({'leaderboard':board.leaderboard()},ensure_ascii=False,allow_nan=False).encode('utf8');kind='application/json; charset=utf-8'
            else:self.send_error(404);return
            self.send_response(200);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers();self.wfile.write(data)
    return ThreadingHTTPServer((host,port),Handler)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('prepare-profile');p.add_argument('--output',required=True)
    p=sub.add_parser('intake');p.add_argument('--db',required=True);p.add_argument('--manifest',required=True)
    p.add_argument('--image',required=True);p.add_argument('--submission-root',required=True);p.add_argument('--team-id',required=True)
    p.add_argument('--deadline');p.add_argument('--deadline-policy',choices=['accepted_at'],default='accepted_at')
    p.add_argument('--internal-validation',action='store_true')
    p=sub.add_parser('work-once');p.add_argument('--db',required=True);p.add_argument('--profile',required=True)
    p.add_argument('--run-root',required=True);p.add_argument('--worker-id',required=True)
    p.add_argument('--local-diagnostic',action='store_true');p.add_argument('--internal-validation',action='store_true')
    p=sub.add_parser('leaderboard');p.add_argument('--db',required=True)
    p=sub.add_parser('serve-board');p.add_argument('--db',required=True);p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8080)
    p.add_argument('--internal-validation',action='store_true')
    p=sub.add_parser('requeue-infrastructure');p.add_argument('--db',required=True);p.add_argument('--job-id',required=True)
    args=parser.parse_args(argv)
    if args.command=='prepare-profile':result=prepare_profile(args.output)
    elif args.command=='intake':
        from contest_intake import verify_image_manifest
        manifest=load_manifest(args.manifest);image=inspect_image(args.image)
        image_manifest=verify_image_manifest(image,manifest)
        board=Scoreboard(args.db,deadline=args.deadline,deadline_policy=args.deadline_policy,
                         scope='internal_validation' if args.internal_validation else 'official')
        if board.scope=='official' and board.deadline is None:
            raise OrganizerConfigurationError('Set the official intake deadline before accepting competition submissions')
        result=board.enqueue(manifest,manifest_sha256=manifest_digest(manifest),image_digest=image,
            authenticated_team_id=args.team_id,private_spec={'submission_root':str(Path(args.submission_root).resolve()),
                'image_manifest_verified':image_manifest['verified'],
                'image_manifest_sha256':image_manifest['image_manifest_sha256']})
    elif args.command=='work-once':
        from contest_job_runner import JobRunner
        profile=read_profile(args.profile,require_released=not args.internal_validation)
        board=Scoreboard(args.db,scope='internal_validation' if args.internal_validation else 'official')
        job=board.claim_next(args.worker_id)
        if job is None:result={'state':'no_queued_job'}
        else:
            try:
                if args.local_diagnostic:
                    if not args.internal_validation:raise OrganizerConfigurationError('Local diagnostics cannot produce official competition results')
                    backend=LocalDiagnosticBackend(explicitly_allow_local=True)
                else:
                    backend=DockerBackend(agent_image=job['image_digest'],candidate_image=profile['candidate_image'],
                        agent_limits=ContainerLimits(**profile['agent_limits']),candidate_limits=ContainerLimits(**profile['candidate_limits']),
                        gpu_devices=profile['gpu_devices'],uid=os.getuid(),gid=os.getgid())
                runner=JobRunner(board,backend,make_world_factory(profile),run_root=args.run_root,profile=profile,
                    model_mounts=[tuple(x) for x in profile['model_mounts']],require_released=not args.internal_validation)
                try:result=runner.run_job(job,worker_id=args.worker_id)
                finally:runner.close()
            except Exception as exc:
                if board.status(job['job_id'])['state']=='running':
                    board.fail_infrastructure(job['job_id'],worker_id=args.worker_id,private_error=str(exc))
                raise
    elif args.command=='leaderboard':result={'leaderboard':Scoreboard(args.db).leaderboard()}
    elif args.command=='requeue-infrastructure':
        board=Scoreboard(args.db);board.requeue_infrastructure(args.job_id);result=board.status(args.job_id)
    else:
        board=Scoreboard(args.db,scope='internal_validation' if args.internal_validation else 'official')
        server=make_leaderboard_server(board,args.host,args.port)
        try:server.serve_forever()
        except KeyboardInterrupt:pass
        finally:server.server_close()
        return 0
    print(json.dumps(result,ensure_ascii=False,allow_nan=False))
    return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,RuntimeError) as exc:
        # This CLI is trusted organizer-only; private failure details stay here.
        print(json.dumps({'ok':False,'error':str(exc)},ensure_ascii=False),file=sys.stderr)
        raise SystemExit(2)
