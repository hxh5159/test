"""Organizer-owned evaluation using an agent directory and model registry.

The administrator retains this runtime and launches submitted strategies as a
dedicated unprivileged account. Only an allowlisted public SDK is staged for
that account. Scientific sessions, prediction and scoring reuse JobRunner.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
from uuid import uuid4

from direct_project_eval import (
    PRIVATE, PUBLIC, DirectProjectBackend, _OwnedProcessTree,
    _enable_child_subreaper,
)
from contest_execution import AgentHandle, stage_public_runtime
from contest_job_runner import JobRunner, _write_private
from contest_platform import make_world_factory, read_profile
from contest_scoreboard import Scoreboard, WORLDS
from law_program_evaluation import OrganizerConfigurationError
from rift.strategy import load_model_registry, load_strategy_submission
from rift.submission import SubmissionError, manifest_digest


def default_profile():
    for relative in ('profiles/strategy-v3/profile.json', 'profiles/strategy-v3.json',
                     'profiles/strategy-v2/profile.json', 'profiles/strategy-v2.json',
                     'profiles/strategy-v1/profile.json', 'profiles/strategy-v1.json'):
        path = PRIVATE/relative
        if path.is_file():
            return path
    raise OrganizerConfigurationError('The organizer strategy-path runtime profile is required')


def run_identity(name):
    """Resolve the administrator-selected account, without changing users."""
    if sys.platform != 'linux' or not hasattr(os, 'geteuid'):
        raise OrganizerConfigurationError('Formal strategy-path evaluation requires Linux administrator execution')
    if os.geteuid() != 0:
        raise OrganizerConfigurationError('Run the organizer evaluator as administrator so it can select the dedicated evaluation account')
    if not isinstance(name, str) or not name:
        raise OrganizerConfigurationError('Specify --run-as with a dedicated unprivileged evaluation account')
    import pwd
    try:
        account = pwd.getpwnam(name)
    except KeyError as exc:
        raise OrganizerConfigurationError('The --run-as account must already exist on this instance') from exc
    if account.pw_uid == 0:
        raise OrganizerConfigurationError('The strategy account must be an unprivileged UID distinct from the administrator')
    return {'user': account.pw_uid, 'group': account.pw_gid,
            'extra_groups': os.getgrouplist(account.pw_name, account.pw_gid), 'umask': 0o077}


def check_lock_directory(directory):
    """Keep the shared UID lock trustworthy, independently of package location."""
    info = Path(directory).stat()
    if info.st_uid != 0 or stat.S_IMODE(info.st_mode) & 0o077:
        raise OrganizerConfigurationError('The evaluation lock directory must be administrator-owned and inaccessible to other accounts')


_ENV_NAMES = frozenset((
    'PATH', 'SYSTEMROOT', 'WINDIR', 'LANG', 'LC_ALL', 'LD_LIBRARY_PATH',
    'CUDA_HOME', 'CUDA_PATH', 'CC', 'CXX', 'CUDAHOSTCXX', 'NVCC_CCBIN',
    'CUDACXX', 'TRITON_PTXAS_PATH', 'CUDA_VISIBLE_DEVICES',
    'NVIDIA_VISIBLE_DEVICES', 'NVIDIA_DRIVER_CAPABILITIES', 'CONDA_PREFIX',
    'VIRTUAL_ENV', 'SHORE_MODEL_PYTHON',
))
_ENV_PREFIXES = ('NCCL_', 'OMP_', 'MKL_', 'VLLM_', 'FLASHINFER_', 'TVM_FFI_')


def strategy_environment(source, workspace, sdk, registry_path, agent_dir):
    """Carry runtime/GPU settings, never inherited organizer import paths."""
    env = {key: value for key, value in source.items()
           if key in _ENV_NAMES or key.startswith(_ENV_PREFIXES)}
    env.update(HOME=str(workspace), TMPDIR=str(workspace), TMP=str(workspace), TEMP=str(workspace),
        SHORE_MODEL_REGISTRY=str(registry_path), SHORE_STRATEGY_DIR=str(agent_dir),
        SHORE_SDK_ROOT=str(sdk), PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        FLASHINFER_NO_DOWNLOAD='1', HF_HUB_DISABLE_TELEMETRY='1', VLLM_NO_USAGE_STATS='1')
    return env


def _readable_sdk(destination):
    root = stage_public_runtime(destination)
    for path in root.rglob('*'):
        path.chmod(0o755 if path.is_dir() else 0o644)
    root.chmod(0o755)
    return root


_ACCESS_PROBE = '''import json,os,sys
from pathlib import Path
paths=json.loads(sys.argv[1])
bad=[]
for raw in paths:
    p=Path(raw)
    mode=os.R_OK|os.X_OK if p.is_dir() else os.R_OK
    if not p.exists() or not os.access(p,mode):
        bad.append(raw)
    elif p.is_dir():
        def onerror(error):
            bad.append(str(error.filename))
        for base,dirs,files in os.walk(p,onerror=onerror):
            if not os.access(base,os.R_OK|os.X_OK):bad.append(base)
            for name in files:
                file=os.path.join(base,name)
                if not os.access(file,os.R_OK):bad.append(file)
print(json.dumps({'ok':not bad,'unreadable':bad[:20]}))
sys.exit(0 if not bad else 2)
'''


class StrategyBackend(DirectProjectBackend):
    """Run the self-contained strategy as the configured non-admin UID."""
    def __init__(self, registry, *, run_as, agent_python=None, environment=None):
        super().__init__(agent_python=agent_python or sys.executable, environment=environment)
        self.identity = run_identity(run_as)
        self.registry = registry
        self.run_as = run_as

    def check_access(self, agent_dir):
        paths = [str(agent_dir)]
        for model in self.registry['models']:
            paths.append(model['path'])
            if model.get('adapter_path'):
                paths.append(model['adapter_path'])
        try:
            result = subprocess.run([self.agent_python, '-I', '-c', _ACCESS_PROBE, json.dumps(paths)],
                stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=60,
                env={key:value for key,value in self.environment.items() if key in _ENV_NAMES},
                **self.identity)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise OrganizerConfigurationError('The evaluation account cannot execute the configured Python or inspect strategy/model paths; grant it read/execute access to those approved paths') from exc
        if result.returncode:
            raise OrganizerConfigurationError('The evaluation account cannot read the complete strategy, weights or adapters; grant read/execute access to every declared artifact before evaluation')

    @contextmanager
    def evaluation_lock(self):
        """Serialize this UID, so parallel teams need separate run accounts."""
        import fcntl
        directory = Path('/run/shore-evaluation')
        directory.mkdir(mode=0o700, exist_ok=True)
        check_lock_directory(directory)
        flags = os.O_CREAT | os.O_RDWR | os.O_CLOEXEC | os.O_NOFOLLOW
        descriptor = os.open(directory/f'uid-{self.identity["user"]}.lock', flags, 0o600)
        try:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise OrganizerConfigurationError('This evaluation account is already running another submission; wait or select a different dedicated account') from exc
            yield
        finally:
            os.close(descriptor)

    def start_agent(self, manifest, *, submission_root, output_dir, log_dir, endpoint, token,
                    socket_directory=None, model_mounts=(), sdk_root=None):
        if model_mounts:
            raise OrganizerConfigurationError('Strategy-path evaluation uses declared model paths')
        root = Path(submission_root).resolve()
        output, logs = Path(output_dir).resolve(), Path(log_dir).resolve()
        logs.mkdir(parents=True, exist_ok=True)
        workspace_root = Path(tempfile.mkdtemp(prefix='shore-strategy-run-'))
        workspace_root.chmod(0o711)
        workspace = workspace_root/'workspace'
        workspace.mkdir(mode=0o700)
        sdk = Path(tempfile.mkdtemp(prefix='shore-strategy-sdk-'))
        handles, process, owner = [], None, None
        try:
            _readable_sdk(sdk)
            os.chown(workspace, self.identity['user'], self.identity['group'])
            registry_path = workspace/'models.json'
            _write_private(registry_path, self.registry)
            registry_path.chmod(0o644)
            artifacts = workspace/'output'
            artifacts.mkdir(mode=0o700)
            os.chown(artifacts, self.identity['user'], self.identity['group'])
            env = strategy_environment(self.environment, workspace, sdk, registry_path, root)
            ownership_token = uuid4().hex
            env.update(RIFT_CONSOLE_URL=endpoint, RIFT_SESSION_TOKEN=token,
                       RIFT_OUTPUT_DIR=str(artifacts))
            env[_OwnedProcessTree.KEY] = ownership_token
            command = [self.agent_python, '-I', str(sdk/'scripts/run_strategy.py'),
                       '--agent-dir', str(root), '--models-file', str(registry_path)]
            handles = [open(logs/'agent.stdout.log', 'wb'), open(logs/'agent.stderr.log', 'wb')]
            _enable_child_subreaper()
            process = subprocess.Popen(command, cwd=workspace, env=env, stdin=subprocess.DEVNULL,
                stdout=handles[0], stderr=handles[1], start_new_session=True, **self.identity)
            owner = _OwnedProcessTree(process, ownership_token)
        except BaseException:
            if owner is not None:
                owner.stop()
            elif process is not None and process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
            for stream in handles:
                stream.close()
            shutil.rmtree(workspace_root)
            shutil.rmtree(sdk)
            raise

        stopped = False
        def stop():
            nonlocal stopped
            if stopped:
                return
            stopped = True
            archived = False
            try:
                owner.stop()
                # Preserve hidden artifacts only after every owned process has
                # stopped. Symlinks are copied as links rather than followed.
                if artifacts.is_symlink() or not artifacts.is_dir():
                    raise OrganizerConfigurationError('The strategy replaced its assigned output directory')
                shutil.copytree(artifacts, output, symlinks=True)
                archived = True
            except BaseException:
                # An archival or process-cleanup failure must not discard the
                # only copy of hidden observations. Root retains this parent.
                workspace_root.chmod(0o700)
                _write_private(output.parent/'retained-workspace.private.json',
                               {'workspace_root':str(workspace_root),
                                'reason':'process_cleanup_or_artifact_archival_failed'})
                raise
            finally:
                try:
                    if archived:
                        shutil.rmtree(workspace_root)
                    shutil.rmtree(sdk)
                finally:
                    for stream in handles:
                        stream.close()
        return AgentHandle(process, handles, stop=stop)


def evaluate(agent_dir, models_file, output, *, profile_path=None, agent_python=None,
             run_as=None, check_only=False, backend=None):
    """Evaluate two submitted paths. Backend injection is for engineering tests."""
    strategy = Path(agent_dir).expanduser().absolute()
    models = Path(models_file).expanduser().resolve()
    manifest = load_strategy_submission(strategy, models, check_files=True)
    registry = load_model_registry(models, check_files=True)
    if manifest['models'] != registry['models']:
        raise OrganizerConfigurationError('The model registry changed while this submission was being accepted')
    strategy = strategy.resolve()
    registry_digest = hashlib.sha256(json.dumps(
        registry, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
    profile = read_profile(profile_path or default_profile(), require_released=True)
    if profile.get('execution_mode') != 'direct_project':
        raise OrganizerConfigurationError('Use the organizer-approved strategy-path profile')
    if profile.get('policies', {}).get('hidden_run_artifacts') != 'organizer_retained_no_contest_export':
        raise OrganizerConfigurationError('Hidden artifacts must remain organizer-only')
    runner_backend = backend or StrategyBackend(registry, run_as=run_as, agent_python=agent_python)
    runner_backend.check_access(strategy)
    factory = make_world_factory(profile)
    for world in WORLDS:
        factory(world)
    if check_only:
        return {'status': 'strategy_paths_checked', 'team_id': manifest['team_id'],
                'submission_id': manifest['submission_id'], 'model_count': len(registry['models']),
                'world_count': len(profile.get('evaluation_worlds', WORLDS)), 'model_loaded': False}
    root = Path(output).expanduser().resolve()
    if root.exists():
        raise OrganizerConfigurationError('Choose a new output directory; existing runs are never overwritten')
    root.mkdir(parents=True, mode=0o700)
    root.chmod(0o700)
    private = root/'private'
    private.mkdir(mode=0o700)
    private.chmod(0o700)
    accepted = datetime.now(timezone.utc).isoformat()
    board = Scoreboard(private/'scores.sqlite', scope='official',
                       evaluation_worlds=profile.get('evaluation_worlds', WORLDS))
    receipt = board.enqueue_direct(manifest, project_root=strategy, accepted_at=accepted,
        private_spec={'execution_mode':'organizer_strategy_paths', 'models_file':str(models),
                      'agent_python':runner_backend.agent_python, 'run_as':run_as,
                      'model_registry_sha256':registry_digest})
    _write_private(private/'models.normalized.json', registry)
    _write_private(private/'acceptance.json', {'job_id':receipt['job_id'], 'accepted_at':accepted,
        'strategy_directory':str(strategy), 'models_file':str(models),
        'manifest_sha256':manifest_digest(manifest), 'execution_mode':'organizer_strategy_paths',
        'model_registry_sha256':registry_digest,
        'run_as':run_as, 'model_ids':[model['id'] for model in registry['models']],
        'model_provenance_verified':False})
    with runner_backend.evaluation_lock(), JobRunner(
            board, runner_backend, factory, run_root=private/'runs', profile=profile) as runner:
        result = runner.run_next('strategy-path-worker')
    summary = {key:result[key] for key in ('job_id','team_id','accepted_at','state','total_score','world_scores')
               if key in result}
    summary.update(schema_version='shore-strategy-feedback-1.0',
                   execution_mode='organizer_strategy_paths', submission_id=manifest['submission_id'])
    if summary['state'] != 'completed':
        summary['error'] = 'Organizer execution failed; diagnostics are retained privately for repair and re-evaluation.'
    _write_private(root/'summary.json', summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--agent-dir', type=Path, required=True)
    parser.add_argument('--models-file', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--profile', type=Path)
    parser.add_argument('--agent-python')
    parser.add_argument('--run-as', required=True)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args(argv)
    try:
        result = evaluate(args.agent_dir, args.models_file, args.output, profile_path=args.profile,
            agent_python=args.agent_python, run_as=args.run_as, check_only=args.check_only)
    except (OSError, ValueError, RuntimeError) as exc:
        result = {'status':'startup_or_format_error', 'error':
            exc.message if isinstance(exc, SubmissionError) else str(exc)
            if isinstance(exc, OrganizerConfigurationError) else
            'Check the strategy, model registry, access permissions and matching organizer profile.'}
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result.get('state','completed') == 'completed' else 2


if __name__ == '__main__':
    raise SystemExit(main())
