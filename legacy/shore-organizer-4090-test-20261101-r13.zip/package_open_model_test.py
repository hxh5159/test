"""Build an explicit allowlist-only PRIVATE organizer calibration archive."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = (
    "contest_simulator.py", "contest_world_definitions.json", "claims_truth.json",
    "trial_catalog.py", "trial_console.py", "trial_evaluation.py",
    "expression_candidate.py", "closed_expression_trial.py", "llm_trial_runner.py",
    "open_model_calibration.py", "preflight_open_models.py", "serve_open_models.py",
    "check_open_model_service.py", "env_open_models.sh", "requirements-trials.txt",
    "README_三模型远端测试.txt", "package_open_model_test.py",
    "tests/check_open_model_calibration.py", "tests/check_open_model_preflight.py",
    "tests/check_open_model_launch.py", "tests/check_open_model_service_transport.py",
    "tests/check_open_model_wiring.py",
)
NUMERICS = ("__init__.py", "rollout.py")


def package(destination, *, profile="three-model", runtime_profile=None):
    if profile not in ("three-model", "4090"):
        raise ValueError("Unknown private packaging profile")
    destination = Path(destination).resolve()
    public_repo = Path(os.environ.get('RIFT_PUBLIC_ROOT',ROOT.parent/'DiscoverPhysics')).resolve()
    if destination == public_repo or public_repo in destination.parents:
        raise ValueError("Never write the private archive inside the public repository.")
    if destination.exists():
        raise FileExistsError("Use a new private archive path; existing evidence is not overwritten.")
    files = FILES + (("README_4卡4090双模型测试.txt",) if profile == "4090" else ())
    sources = {name: ROOT/name for name in files}
    from package_contest_runtime import collect_runtime_payloads, _regular_in_root
    for name in files:_regular_in_root(ROOT,name)
    math_root = ROOT/"rift_numerics"
    if not math_root.is_dir():
        math_root = public_repo/"rift_numerics"
    sources.update({"rift_numerics/"+name: math_root/name for name in NUMERICS})
    for name in NUMERICS:_regular_in_root(math_root.resolve(),name)
    for name,path in sources.items():
        if path.is_symlink() or not path.is_file():raise ValueError('Missing ordinary allowlisted source: '+name)
    blobs = {name: path.read_bytes() for name, path in sources.items()}
    if runtime_profile is None:
        runtime_profile=ROOT/'profiles/direct-v1-r3.json'
        if not runtime_profile.is_file():runtime_profile=ROOT/'profiles/direct-v1-r3/profile.json'
    profiles=[runtime_profile]
    # Existing organizer test folders contain direct-v1/internal-v9 paths.
    # Retain those original bytes so an explicit --refresh can update source
    # without deleting old files, environments, observations or results.
    for prior_name in ('direct-v1-r2','direct-v1','internal-v9'):
        prior_profile=ROOT/('profiles/'+prior_name+'.json')
        if prior_profile.is_file() and all(Path(p).resolve()!=prior_profile.resolve() for p in profiles):
            profiles.append(prior_profile)
    runtime_payloads,profile_ids=collect_runtime_payloads(profiles=profiles,
        private_root=ROOT,public_root=public_repo,public_prefix='')
    for name,raw in runtime_payloads.items():
        if name in blobs and blobs[name]!=raw:raise ValueError('Public/private source disagreement: '+name)
        blobs[name]=raw
    for name, data in blobs.items():
        if re.search(rb"sk-[A-Za-z0-9]{20,}", data):
            raise ValueError("Possible literal API credential in allowlisted file: " + name)
    listed=sorted(set(blobs)|{'FILE_LIST.txt','PRIVATE_PACKAGE_MANIFEST.json'})
    blobs['FILE_LIST.txt']=('指挥部完整模型测试资料清单\n文件总数：'+str(len(listed))+'\n\n'
                           +'\n'.join(listed)+'\n').encode('utf-8')
    manifest = {"schema_version": "1.0.0", "scope": "organizer_only_open_model_calibration",
        "delivery_revision": 13,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "deployment_guide_profile": profile,
        "contains_true_physics_and_hidden_validation": True,
        "participant_distribution_allowed": False,
        "model_or_api_calls_during_packaging": 0,
        "observation_noise_version": "1.1.0",
        "velocity_noise_fraction": 1e-4,
        "exploration_wall_clock_seconds": 600,
        "default_agent_max_turns": 3,
        "evaluation_worlds": ["Adam", "Ramiel", "Leliel"],
        "scientific_dataset_scope": "Latest fixed six-public/nine-hidden design; selected Adam and validation coverage installed",
        "primary_entrypoint": "python -m development_worlds.runner (public); scripts/evaluate_submission.py --organizer-root . (hidden organizer)",
        "formal_execution_mode": "direct_project",
        "requires_container_runtime": False,
        "model_service_entrypoint": "scripts/serve_model.py (vLLM0.24/CUDA12.8)",
        "legacy_expression_calibration": "open_model_calibration.py retained for diagnostics, not the primary law.py workflow",
        "contains_public_development_kit": True,
        "profile_ids": profile_ids,
        "hidden_artifacts_returned_during_contest": False,
        "full_law_py_agent_generation_validated": False,
        "excluded": ["API keys", "closed gateway transports", "historical trial outputs",
            "predefined physical candidate libraries", "model weights", "private memory documents"],
        "files": {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
            for name, data in blobs.items()}}
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in blobs.items():
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100600 << 16
            archive.writestr(info, data)
        archive.writestr("PRIVATE_PACKAGE_MANIFEST.json",
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    return {"archive": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
        "file_count": len(blobs)+1, "private_only": True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=("three-model", "4090"), default="three-model")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--runtime-profile",type=Path)
    args = parser.parse_args(argv)
    name = "shore-organizer-4090-test-20261101.zip" if args.profile == "4090" else "shore-organizer-open-model-test-20261101.zip"
    destination = args.output or ROOT/"exports"/name
    print(json.dumps(package(destination, profile=args.profile,runtime_profile=args.runtime_profile), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
