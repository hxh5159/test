彼岸正式赛题运行系统 内部构建版 1.0.0

本文及同目录程序仅供指挥部。真实模拟器、定义、三声明真值、验证参考、队列数据库与运行日志不得进入公开仓库、攻坚组镜像或公开下载目录。
构建前公开保存点：cbb8313aeaf2a6704e92941a99c682749982d41c（已推送）。该点之后为正式比赛系统实现；不修改九宇宙真实力场或80/15/5计分。

一、两套包与运行位置

攻坚组起步包：公开SDK、固定候选积分器、提交模板、预检与接口文档。只按白名单打包，不直接把研究仓库交给攻坚组。
指挥部私有包：包根目录为真实服务、评分、调度、队列和运维程序；public/下仅是运行所需公开数学SDK及校验器。不含API客户端、凭证或过去模型实验日志。

所有正式命令在用户远端Linux执行。原研究目录为：
  /inspire/hdd/project/urbanlowaltitude/fengkairui-25026/houwenzhe/test/DiscoverPhysics
模型通常位于：
  /inspire/hdd/project/urbanlowaltitude/fengkairui-25026/houwenzhe/models
已有公共量化模型：
  /inspire/hdd/global_public/models/Qwen3.6-35B-A3B-W8A8
私有包另解压至指挥部权限目录，不能放攻坚组可读工作区。不要将指挥部私有包提交公开Git。

从独立私有包运行时：
  cd /指挥部权限目录/shore-runtime
  export RIFT_PUBLIC_ROOT="$PWD/public"
  python contest_platform.py --help

在现有研究检出旁运行时，RIFT_PUBLIC_ROOT指向远端DiscoverPhysics检出绝对路径。NumPy、SciPy需在可信Python和官方候选镜像中可用；其他GPU推理依赖由基础镜像准备。运行时不下载权重或联网安装。

二、职责和边界

contest_console_service.py：认证会话、任务包、正常实验计费、缓存、草稿/提交、外部计时快照与封存。真实模拟只在此侧。
contest_job_runner.py：消费同一次冻结提交，依次运行九宇宙、停止智能体、获取有效配对、调用固定预测、完整汇总。每局的输出目录和配额独立。
contest_execution.py：正式Docker执行与明确的本地诊断后端。正式agent断网，只挂官方Unix socket、公开SDK、自身输出和指挥部批准的只读模型。最终候选没有socket、令牌、GPU或私有目录。
law_program_evaluation.py：白名单测试输入、固定worker桥、官方参考预检及科学/基础设施故障区分。
contest_scoreboard.py：SQLite受理队列、运行域、截止配置、完整成绩和最佳完整提交；精确分层bootstrap只用已有九界总分。
contest_platform.py：可信CLI受理、运行、查询和只读榜单页；不是向攻坚组开放的任意上传或Docker控制API。
contest_team_export.py：归还本队合法记录和自身产物，不遍历私有评分目录。

用户已确认：可以跨提交复用本队合法观测、候选规律和白名单模型成果。每次正式运行仍独立会话/配额/评分；不拼接历史逐宇宙高分。
用户已确认：截止前成功受理的提交可在截止后评完；指挥部基础设施故障保留原版本，修复后重评。截止在数据库持久化，后续命令漏传参数不会解除检查。

三、准备正式profile

先创建内部版本，不覆盖既有文件：
  python contest_platform.py prepare-profile --output /指挥部权限目录/profiles/internal-v1.json

该命令离线运行原有参考生成/收敛检查并使用匹配缓存，不改力场或调优规则。输出9份无噪参考及其SHA256，固定公开SDK/私有源码身份。
输出为internal_validation，真实投放域、第一束光和验证范围沿已有试做配置，不能自动称为已发布正式范围。startup_seconds=900、candidate_timeout_seconds=120等只是内部诊断示例，不是冻结赛题时限。
发布前需明确并审阅：正式域/验证清单、范围公开粒度、统一CPU/内存/执行护栏、镜像与模型资产、目标环境权限与性能。确认后创建新版本并设release_approved、runtime_limits_approved、domains_and_validation_approved；不得把过时源码/参考摘要仅改标签后强行通过。
若未来修改公开SDK或指挥部运行代码，prepare-profile生成新版本，不能悄悄改变旧profile的参考或代码。

四、镜像和模型准备

攻坚组镜像内将代码与submission.json放在/submission。平台覆盖镜像ENTRYPOINT，按清单数组在该目录直接执行。不要依赖容器启动后在线pip、外部API或宿主机任意目录。
镜像可使用examples/Dockerfile.agent的最小结构；BASE_IMAGE必须是指挥部预先准备且离线可用的基础镜像。镜像受理时解析实际sha256 ID并核对镜像内submission.json，而非只相信tag或外部字符串。
候选镜像必须是指挥部持有的固定科学计算镜像，包含Python、NumPy、SciPy；不包含真实模拟器或测试真值。SDK以只读、内容摘要目录挂入，不能被队伍版本替换。

profile中的candidate_image填写实际sha256 ID；model_mounts仅由指挥部配置为[宿主机只读模型路径,容器/models/名称]列表，清单中的path不授予host挂载权。
例如公共Qwen路径可映射至/models/Qwen3.6-35B-A3B-W8A8。正式模型资产须固定revision/摘要并置于指挥部控制的不可变版本目录；队伍仍在训练的可写目录不能直接充当已受理版本。自训权重也可以打入不可变镜像。
正式运行指定4个H200设备ID，指挥部worker独占这4卡。CPU、内存、输出配额和4TB存储边界需要在实际主机配置，不把诊断示例值当作已部署的硬限制。

五、受理和运行

以下占位路径、镜像和实际截止时间由指挥部替换。受理操作由可信人员或已认证平台执行，team-id来自登录身份，不相信攻击者自行声明。

  python contest_platform.py intake --db /指挥部权限目录/official.sqlite \
    --manifest /受理暂存目录/submission.json --submission-root /受理暂存目录 \
    --image 攻坚组已导入镜像 --team-id team01 --deadline 带时区的正式截止时间

  python contest_platform.py work-once --db /指挥部权限目录/official.sqlite \
    --profile /指挥部权限目录/profiles/released-v1.json \
    --run-root /指挥部权限目录/runs --worker-id h200-worker-1

每次work-once消费一个完整提交。不同worker可共享同一队列认领任务，但GPU设备分配必须由指挥部外部调度保证不重叠；不能启动多个worker抢同4卡。
模型当前每宇宙独立启动进程；尚未实现并验收一次加载复用服务。正式发布前必须测量加载和九宇宙实际耗时，不宣称48小时内已经支持足够提交轮次。
本机诊断必须使用不同的内部数据库，并显式同时传--internal-validation与--local-diagnostic；内部队列不能混写正式结果。LocalDiagnostic没有文件权限隔离，禁止用于不可信攻坚组。

六、查询、排行榜和故障

  python contest_platform.py leaderboard --db /指挥部权限目录/official.sqlite
  python contest_platform.py serve-board --db /指挥部权限目录/official.sqlite --host 127.0.0.1 --port 8080

只读页及/api/leaderboard仅显示排名、队伍标识、总分和九宇宙总分。图表、下载、日志不能绕过此过滤。内部同分统计、分项和参考留在指挥部侧。
网页默认仅监听本机；若接入现场内网门户，需要由指挥部受控反向代理发布。这个程序没有公共写入或上传端点。

基础设施故障状态为infrastructure_failed，不发布部分总分或伪0。修复后：
  python contest_platform.py requeue-infrastructure --db /指挥部权限目录/official.sqlite --job-id 对应提交编号
重新使用原受理版本和时间，不因为截止已过就丢弃合法排队提交。候选自身超时/非法输出按既有规则，不走这一人工基础设施重排通道。
复杂计费退款和自动重试政策仍按此前决定暂缓，本版本不暗设免费试探/额外LLM轮数。

七、归还本队记录和模型成果

  python contest_team_export.py --db /指挥部权限目录/official.sqlite \
    --run-root /指挥部权限目录/runs --job-id 对应编号 --team-id team01 \
    --output /受控队伍下载目录/team01-records.zip

默认只导出本队任务、允许观测、选定law/claims与可选报告。需要归还评测时本队写出的模型或adapter，可额外传--include-agent-output；这些来自独立agent output目录。必须先结束该次运行；不跟随符号链接、不打包评分/会话/日志/参考目录。
此CLI的team-id校验必须接在可信身份之后；不能将其原样变成任意用户可指定别人team-id的下载接口。

八、正式上线前仍须验收

1. Linux Unix socket及UID/GID权限；断网容器只能连接指定socket，最终候选不能读取真值文件。
2. 基础镜像、固定依赖、各白名单模型与自训产物的实际加载和摘要核验，4H200运行和显存余量。
3. 正常策略的完整用时、模型启动成本、CPU积分、并发队列及48小时多次提交能力。九宇宙理论探索上限可接近9小时，不能仅凭有独立评测卡就承诺分钟级反馈。
4. 公开起步包独立解压检查、完整九宇宙提交、草稿收卷、无草稿、坏提交、官方故障重评、最佳完整成绩和反馈过滤。
5. 正式域/验证profile和资源值经过审阅后发布；内部测试与已知规律fixture不等于白名单模型发现能力或现场难度验收。

当前本机工程测试仅证明已覆盖链路，未远端部署，未调用任何模型/API，闭源模型模拟仍暂停。
