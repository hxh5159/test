"""Private, provisional case catalogue for budget/noise discovery trials.

This file contains organizer-only validation inputs and sampled clean truth.
It is not a contestant SDK, a final published domain, or a new true law.
Validation initial velocities are fixed ordinary numbers with perturbations;
none are computed from true acceleration or an exact circular-orbit recipe.
Only the organizer's calibration routine queries the true simulator.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import time

import numpy as np

from contest_simulator import ContestSimulator, SINGLE_CENTER
from rift_numerics import sample_indices,DT


ROOT = Path(__file__).resolve().parent
CATALOG_VERSION = "private-trial-catalog-2.0.0"
WORLDS = ("Adam", "Lilith", "Tabris", "Sachiel", "Ramiel", "Matriel", "Leliel", "Arael", "Lilin")
FIRST_LIGHT_READOUT = [0., .05, .1, .2, .35, .5, .7, 1.]
_LIMITS = {
    "Adam": (1., 8., 40., 30., 5.),
    "Lilith": (1., 8., 40., 30., 5.),
    "Tabris": (1., 8., 40., 30., 5.),
    "Sachiel": (2., 12., 30., 20., 5.),
    "Ramiel": (2., 12., 30., 20., 5.),
    "Matriel": (2., 8., 32., 16., 3.),
    "Leliel": (.4, 8., 40., 30., 5.),
    "Arael": (2., 8., 32., 16., 3.),
    "Lilin": (2., 8., 48., 24., 3.),
}


def _check_world(world):
    if world not in WORLDS:
        raise ValueError(f"Unknown trial world {world!r}.")


def _probe(pos, vel, world, attr=1.):
    return {"pos": list(map(float, pos)), "vel": list(map(float, vel)),
            "properties": {"p2" if world in SINGLE_CENTER else "mass": float(attr)}}


def first_light_request(world):
    """Two probes and eight readouts; this entire request is public metadata."""
    _check_world(world)
    if world in ("Matriel", "Arael", "Lilin"):
        definition = json.loads((ROOT / "contest_world_definitions.json").read_text(encoding="utf-8"))
        item = next(w for w in definition["worlds"] if w["name"] == world)
        request = item["first_light"]
        return copy.deepcopy({k: request[k] for k in ("t_launch", "readout", "source_properties", "probes")})
    if world in ("Adam", "Tabris"):
        positions, velocities = [[2., 0.], [0., 4.]], [[0., .3], [-.3, 0.]]
    elif world == "Lilith":
        positions, velocities = [[2., 0.], [0., 4.]], [[0., .6], [-.45, 0.]]
    elif world == "Leliel":
        positions, velocities = [[1., 0.], [0., 3.]], [[0., .5], [-.4, 0.]]
    else:
        positions, velocities = [[5., 0.], [0., 6.]], [[0., 2.5], [-2.4, 0.]]
    return {"t_launch": 0., "readout": FIRST_LIGHT_READOUT.copy(),
            "source_properties": {"p1": 1.} if world in SINGLE_CENTER else {},
            "probes": [_probe(p, v, world) for p, v in zip(positions, velocities)]}


def trial_config(world):
    """Only legal operations/limits, not validation cases or unknown physics.

    Numeric limits are provisional for reproducible development trials. The
    six transferred worlds previously had no frozen contest input domains;
    the three custom worlds retain their previous development annuli/windows.
    """
    _check_world(world)
    rmin, rmax, tmax, duration, vmax = _LIMITS[world]
    return {
        "status": "calibration_not_final", "catalog_version": CATALOG_VERSION,
        "world_id": world,
        "launch_region": {"kind": "annulus", "center": [0., 0.],
                          "radius_min": rmin, "radius_max": rmax},
        "initial_speed_max": vmax,
        "maximum_physical_time": tmax,
        "maximum_single_trajectory_duration": duration,
        "source_properties": {"p1": {"min": .5, "max": 2., "default": 1.}} if world in SINGLE_CENTER else {},
        "probe_properties": {("p2" if world in SINGLE_CENTER else "mass"):
            {"min": .5, "max": 2. if world in SINGLE_CENTER else 4., "default": 1.}},
        "energy_budget": 10,
        "max_probes_per_launch": 8,
        "max_readouts_per_probe": 50,
        "observe_calls": 20,
        "max_times_per_observe": 50,
        "wall_clock_seconds": 300.,
        "first_light": first_light_request(world),
    }


def _cohort(world, radii, speeds, rotation, attrs=None):
    radii = np.asarray(radii, dtype=np.float64)
    speeds = np.broadcast_to(np.asarray(speeds, dtype=np.float64), radii.shape)
    angles = rotation + np.arange(len(radii)) * (2 * np.pi / len(radii))
    radial = np.column_stack((np.cos(angles), np.sin(angles)))
    tangent = np.column_stack((-np.sin(angles), np.cos(angles)))
    velocities = speeds[:, None] * tangent + .025 * np.sin(3 * angles)[:, None] * radial
    if attrs is None:
        attrs = [.5, 1., 2., 4.] if world not in SINGLE_CENTER else [.7, 1., 1.3, 1.6]
    return [_probe(p, v, world, a) for p, v, a in zip(radii[:, None] * radial, velocities, attrs)]


def _case(world, name, group, probes, *, duration, launch=0., p1=None):
    return {"name": name, "group": group, "t_launch": float(launch),
            "readout": (np.arange(1, 21, dtype=float) * (duration / 20)).tolist(),
            "source_properties": {"p1": float(p1)} if p1 is not None else {},
            "probes": probes}


def legacy_diagnostic_validation_cases(world):
    """Independent validation inputs, never to be passed to an exploring agent.

    Every case has four independent probes and twenty relative readouts.
    Across a world all cases keep the same readout count/duration. They are
    pooled with equal per-probe/time weight by the CURRENT score contract.
    `group` is internal audit metadata, not an adopted grouped scoring rule.
    """
    _check_world(world)
    cases = []
    if world in SINGLE_CENTER:
        layout = {
            "Adam": [([1.15, 1.4, 1.65, 1.9], [.4, .45, .5, .55]),
                     ([2.6, 3.1, 3.6, 4.1], [.3, .4, .5, .45]),
                     ([5.2, 5.9, 6.6, 7.3], [.3, .4, .5, .45])],
            "Lilith": [([1.15, 1.4, 1.65, 1.9], [1.2, 1.05, 1.1, 1.15]),
                       ([2.1, 2.45, 2.8, 3.15], [.65, .7, .75, .8]),
                       ([3.6, 4.1, 4.6, 5.1], [.4, .45, .5, .55])],
            "Tabris": [([1.1, 1.35, 1.6, 1.85], [.3, .35, .4, .45]),
                       ([2.5, 3., 3.5, 4.], [.25, .3, .35, .4]),
                       ([4.5, 5., 5.5, 6.], [.2, .25, .3, .35])],
            "Leliel": [([.55, .68, .81, .94], [.75, .8, .85, .9]),
                       ([1.2, 1.55, 1.9, 2.25], [.45, .5, .55, .6]),
                       ([3.5, 4.2, 4.9, 5.6], [.35, .4, .45, .5])],
        }[world]
        strengths = [.65, 1.4] if world == "Lilith" else [.7, 1.7]
        for band, (radii, speeds) in enumerate(layout):
            for k, p1 in enumerate(strengths):
                probes = _cohort(world, radii, speeds, .23 + .37 * k + .19 * band)
                cases.append(_case(world, f"b{band}-s{k}", f"distance_{band}", probes,
                                   duration=30., p1=p1))
    elif world in ("Sachiel", "Ramiel"):
        for band, radii in enumerate(([3.5, 4., 4.5, 5.], [6., 6.6, 7.2, 7.8], [9., 9.6, 10.2, 10.8])):
            for k, launch in enumerate((0., 4.)):
                probes = _cohort(world, radii, [2.25, 2.5, 2.75, 3.], .27 + .43*k + .11*band)
                cases.append(_case(world, f"b{band}-l{k}", f"distance_{band}", probes, duration=20., launch=launch))
    elif world == "Arael":
        for band, radii in enumerate(([5.4, 5.65, 5.9, 6.15], [6.3, 6.55, 6.8, 7.05], [7.2, 7.4, 7.6, 7.8])):
            for k, rotation in enumerate((.18, .82)):
                probes = _cohort(world, radii, [2.4, 2.65, 2.8, 2.9], rotation+.13*band)
                cases.append(_case(world, f"b{band}-a{k}", f"distance_{band}", probes, duration=16.))
    else:
        phases, duration = ([0., 2., 4., 6.], 16.) if world == "Matriel" else ([0., 3., 6., 9.], 24.)
        speeds = ([1.95, 2.1, 2.25, 2.4], [1.7, 1.95, 2.1, 2.3]) if world == "Matriel" else ([1.75, 1.9, 2.05, 2.2], [1.2, 1.35, 1.5, 1.65])
        for band, radii in enumerate(([2.5, 2.8, 3.1, 3.4], [7., 7.25, 7.5, 7.75])):
            for k, launch in enumerate(phases):
                probes = _cohort(world, radii, speeds[band], .17 + .13*k + .09*band)
                cases.append(_case(world, f"b{band}-l{k}", f"distance_{band}-launch_{k}", probes,
                                   duration=duration, launch=launch))
    _validate_requests(world, cases)
    return cases


def diagnostic_validation_cases(world):
    """Frozen selected coverage, independent of team actions or submissions."""
    _check_world(world)
    source = json.loads((ROOT/'validation_cases.json').read_text(encoding='utf-8'))
    if source.get('version') != 'selected-validation-20261102-v1':
        raise ValueError('Unknown selected validation catalogue')
    cases = copy.deepcopy(source['worlds'][world])
    _validate_requests(world, cases)
    return cases


def _validate_requests(world, cases):
    config = trial_config(world)
    region = config["launch_region"]
    for case in [first_light_request(world)] + cases:
        launch, readout = case["t_launch"], np.asarray(case["readout"])
        if launch < 0 or launch + max(readout) > config["maximum_physical_time"] or max(readout) > config["maximum_single_trajectory_duration"]:
            raise ValueError(f"Trial catalogue time outside declared domain: {world}")
        if not 1 <= len(case["probes"]) <= 8 or not 1 <= len(readout) <= 50:
            raise ValueError("Trial catalogue exceeds protocol batch limits.")
        for probe in case["probes"]:
            radius, speed = np.linalg.norm(probe["pos"]), np.linalg.norm(probe["vel"])
            if not region["radius_min"] <= radius + 1e-12 or radius > region["radius_max"] + 1e-12 or speed > config["initial_speed_max"]:
                raise ValueError(f"Trial initial state outside domain: {world}, {probe}")


def _variance(positions):
    mean = np.mean(positions, axis=(0, 1))
    per_trajectory_mean = np.mean(positions, axis=0)
    total = float(np.mean(np.sum((positions-mean)**2, axis=-1)))
    within = float(np.mean(np.sum((positions-per_trajectory_mean[None])**2, axis=-1)))
    return total, within


def _score(pred, truth, variance):
    mse = float(np.mean(np.sum((pred-truth)**2, axis=-1)))
    e = mse / max(variance, 1e-12)
    return {"MSE": mse, "e": e, "P": 80/(1+10*e)}


def calibrate_world(world, *, force=False):
    """Generate sampled clean truth/cache and convergence diagnostics privately.

    The exploring policy must only receive trial_config/console outputs, never
    this organizer-only return value. All provisional cases are retained;
    failed convergence is reported and the catalogue requires a documented
    revision before it can support final score conclusions.
    """
    _check_world(world)
    sim = ContestSimulator(world)
    cases = diagnostic_validation_cases(world)
    fingerprint = hashlib.sha256(json.dumps({
        "catalog": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "simulator": sim.cache_token, "cases": cases,
    }, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
    directory = ROOT / "checks" / "trial_calibration"
    directory.mkdir(parents=True,exist_ok=True)
    path = directory / f"{world}-{fingerprint[:16]}.json"
    if path.exists() and not force:
        return json.loads(path.read_text(encoding="utf-8"))
    started = time.perf_counter()
    truths, convergence, ballistic = [], [], []
    for case in cases:
        # Internal case configuration is checked before truth or candidate
        # execution; a malformed organizer grid must never punish a team.
        launch_tick=int(sample_indices([case['t_launch']])[0])
        indices=sample_indices(case['readout'])
        probes = case["probes"]
        kwargs = {"t_launch": case["t_launch"], "duration": case["readout"][-1],
                  "source_properties": case["source_properties"], "probe_properties": [p["properties"] for p in probes]}
        pos, vel = [p["pos"] for p in probes], [p["vel"] for p in probes]
        coarse = sim.integrate(pos, vel, **kwargs)
        fine = sim.integrate(pos, vel, dt=.0025, **kwargs)
        truth, fine_truth = coarse["positions"][indices], fine["positions"][2*indices]
        dx = float(np.max(np.linalg.norm(coarse["positions"]-fine["positions"][::2], axis=-1)))
        dv = float(np.max(np.linalg.norm(coarse["velocities"]-fine["velocities"][::2], axis=-1)))
        sample_dx = float(np.max(np.linalg.norm(truth-fine_truth, axis=-1)))
        convergence.append({"name": case["name"], "max_position_difference": dx, "max_velocity_difference": dv,
                            "sample_max_position_difference": sample_dx, "passed": dx < .001 and dv < .01})
        truths.append({"name": case["name"], "positions": truth.tolist(),
                       "velocities": coarse["velocities"][indices].tolist(),
                       "times": ((launch_tick+indices)*DT).tolist()})
        ballistic.append(np.asarray(pos)[None]+np.asarray(case["readout"])[:, None, None]*np.asarray(vel)[None])
    all_truth = np.concatenate([np.asarray(t["positions"]) for t in truths], axis=1)
    variance, within = _variance(all_truth)
    baseline = _score(np.concatenate(ballistic, axis=1), all_truth, variance)
    result = {
        "status": "calibration_not_final", "catalog_version": CATALOG_VERSION,
        "world": world, "fingerprint": fingerprint, "simulator_cache_token": sim.cache_token,
        "config": trial_config(world), "cases": cases, "truths": truths,
        "N_probes": sum(len(c["probes"]) for c in cases), "T_samples": 20,
        "global_V": variance, "within_V": within, "between_V": variance-within,
        "noise_contract": "observation-noise-1.1.0",
        "velocity_observation_noise": {
            "distribution": "independent Gaussian per coordinate/probe/returned time/new experiment",
            "fraction": 1e-4,
            "reference": "public initial_speed_max",
            "sigma": 1e-4 * trial_config(world)["initial_speed_max"],
            "first_light_same_rule": True,
            "cached_data_not_renoised": True,
            "known_command_initial_state_clean": True,
            "clean_scoring_truth_unchanged": True,
        },
        "sigma_current": .01*np.sqrt((_LIMITS[world][0]**2+_LIMITS[world][1]**2)/2),
        "sigma_legacy05": .05*np.sqrt(variance),
        "sigma_by_legacy_validation_fraction": {str(f): float(f*np.sqrt(variance)) for f in (.01, .02, .05)},
        "noise_ab_comparison": "Use one seed/standard-normal stream across factors; this cache contains clean truth only.",
        "ballistic_baseline": baseline, "convergence": convergence,
        "all_cases_converged": all(c["passed"] for c in convergence),
        "omitted_failed_cases": False,
        "initial_velocity_policy": "Fixed ordinary values and small perturbations, not derived from true forces/circular speeds.",
        "changed_original_world_definitions": False,
        "source_sha256": {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                          for name in ("contest_simulator.py", "contest_world_definitions.json", "trial_catalog.py")},
        "elapsed_seconds": time.perf_counter()-started,
    }
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    summary = {}
    for world in WORLDS:
        data = calibrate_world(world)
        summary[world] = {k: data[k] for k in ("N_probes", "global_V", "within_V", "sigma_current", "sigma_legacy05", "all_cases_converged", "ballistic_baseline")}
        summary[world]["worst_position_dt_halving"] = max(r["max_position_difference"] for r in data["convergence"])
        summary[world]["failed_cases"] = [r for r in data["convergence"] if not r["passed"]]
        print(world, json.dumps(summary[world], ensure_ascii=False), flush=True)
    (ROOT/"checks/trial_catalog_calibration_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
