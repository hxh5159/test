"""PRIVATE session controller and HTTP transport for the contest console.

Only this module's response allowlists cross the contestant boundary.  The
real console and paired store remain in the organizer process; no candidate
code is executed here.  Deploy under a separate account/container and mount
only the Unix socket into the agent environment.  A TCP server is provided for
local diagnostics, not as permission isolation.  Complex retry/refund policies
remain outside this implementation.
"""
from __future__ import annotations

import base64
import binascii
import errno
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import secrets
import socketserver
import threading
import time
from uuid import uuid4

from law_submission_store import (
    ArtifactError, LawSubmissionStore, SubmissionValidationError,
)


CONSOLE_PROTOCOL_VERSION = "1.0.0"
EXPLORATION_PROTOCOL_VERSION = "3.10.0"
MAX_REQUEST_BYTES = 5 * 1024 * 1024  # Transport guard; not an experiment quota.
MAX_ARTIFACT_BYTES = 1024 * 1024
MAX_RESPONSE_BYTES = 64 * 1024 * 1024 - 4096  # Leave room for the JSON envelope.
_METHODS = frozenset(("mission", "observe", "launch", "archive", "save_draft", "submit"))
_BUDGET_KEYS = ("energy_remaining", "energy_used", "observe_remaining", "observe_used",
                "wall_clock_remaining_seconds")
_MISSION_KEYS = ("world_id", "numerics_version", "claims_schema_version", "law_api_version",
                 "task", "controls", "source_property_target_id", "launch_region",
                 "initial_speed_max", "maximum_physical_time",
                 "maximum_single_trajectory_duration", "background_initial_state", "limits", "noise")
_FIRST_KEYS = ("probes", "t_launch", "readout", "source_properties", "times", "positions",
               "velocities", "visible_background_positions", "background_ids")
_OBSERVE_KEYS = ("observation_id", "times", "positions", "ids")
_LAUNCH_KEYS = ("experiment_id", "probes", "t_launch", "readout", "source_properties",
                "times", "positions", "velocities")


def _copy(value):
    encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if len(encoded.encode("utf-8")) > MAX_RESPONSE_BYTES:
        raise ConsoleInfrastructureError("Private service produced an oversized public response")
    return json.loads(encoded)


def _select(value, keys, *, required=()):
    if not isinstance(value, dict):
        raise ConsoleInfrastructureError("Console returned a malformed public response")
    if any(key not in value for key in required):
        raise ConsoleInfrastructureError("Console omitted required public response fields")
    return _copy({key: value[key] for key in keys if key in value})


class ConsoleRequestError(ValueError):
    def __init__(self, code, path, message):
        self.code, self.path, self.message = code, path, message
        super().__init__(message)

    def as_dict(self):
        return {"code": self.code, "path": self.path, "message": self.message}


class ConsoleInfrastructureError(RuntimeError):
    """Organizer-side fault: the parent must repair/re-evaluate, never award P=0."""


def _bad(path, message, code="invalid_request"):
    raise ConsoleRequestError(code, path, message)


def _params(params, required=(), optional=()):
    if not isinstance(params, dict):
        _bad("$.params", "Expected a JSON object")
    missing = set(required) - set(params)
    extra = set(params) - set(required) - set(optional)
    if missing:
        _bad("$.params", "Missing required parameter: " + sorted(missing)[0])
    if extra:
        _bad("$.params", "Unknown parameter")


def _decode_artifact(value, name):
    path = "$.params." + name
    if not isinstance(value, str) or len(value) > 4 * ((MAX_ARTIFACT_BYTES + 2) // 3):
        _bad(path, "Expected a base64-encoded artifact within the published size guard")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        _bad(path, "Invalid base64 artifact")
    if len(raw) > MAX_ARTIFACT_BYTES:
        _bad(path, "Artifact exceeds the published size guard")
    return raw


class ConsoleSession:
    """One trusted job/world session; caller supplies its real private console.

    Both this controller and TrialConsole must use the same monotonic clock and
    wall limit.  All operations serialize under one session lock.  A slow call
    completing after expiry cannot replace the last timely valid draft.
    ``frozen_submission`` and ``finalized_record`` are trusted-parent APIs only.
    """
    def __init__(self, console, store_root, *, session_id=None, job_id=None,
                 clock=time.monotonic, wall_seconds=300):
        if not callable(clock) or not math.isfinite(float(wall_seconds)) or wall_seconds <= 0:
            raise ValueError("A monotonic clock and positive finite wall limit are required")
        if hasattr(console, "_wall_seconds") and float(console._wall_seconds) != float(wall_seconds):
            raise ValueError("Console/controller wall-clock limits must agree")
        self._console = console
        self._store = LawSubmissionStore(store_root)
        self.session_id = str(session_id or uuid4().hex)
        self.job_id = None if job_id is None else str(job_id)
        self._clock, self._wall_seconds = clock, float(wall_seconds)
        self._started_at = None
        self._state = "READY"
        self._reason = None
        self._mission = None
        self._observations = []
        self._latest = None
        self._selected = None
        self._report = None
        self._failure = None
        self._final = None
        self._operation = None
        self._operation_started_at = None
        self._lock = threading.RLock()
        self._publish_watchdog()

    def _publish_watchdog(self):
        # Atomic assignment of an immutable tuple under the request lock. The
        # watchdog reads this tuple without waiting behind slow physics/I/O.
        self._watchdog = (self._state, self._started_at, self._failure is not None,
                          self._operation, self._operation_started_at)

    def watchdog_snapshot(self):
        """Trusted-parent nonblocking snapshot, including a pending mission.

        A permanently stuck private simulator remains an infrastructure fault;
        a parent must not turn inability to finalize into scientific zero.
        """
        state, started, failed, operation, operation_started = self._watchdog
        pending = state == "READY" and operation == "mission" and started is None
        effective = operation_started if pending else started
        remaining = None if effective is None else max(0.0, self._wall_seconds - (self._clock() - effective))
        return {"state": state, "started_at": effective, "deadline_remaining": remaining,
                "failed": failed, "request_in_flight": operation,
                "operation_started_at": operation_started, "pending_mission": pending}

    @property
    def state(self):
        with self._lock:
            return self._state

    @property
    def started_at(self):
        with self._lock:
            return self._started_at

    @property
    def deadline_remaining(self):
        with self._lock:
            if self._started_at is None:
                return None
            return max(0.0, self._wall_seconds - (self._clock() - self._started_at))

    def _budget(self):
        budget = _select(self._console.budget, _BUDGET_KEYS)
        if self._started_at is not None:
            budget["wall_clock_remaining_seconds"] = self.deadline_remaining
        return budget

    def _status(self):
        return {"session_id": self.session_id, "session_state": self._state, "budget": self._budget()}

    def _mark_failure(self, exc):
        self._failure = exc
        self._state, self._reason = "FAILED", "infrastructure_error"
        self._selected = self._latest
        self._publish_watchdog()
        self._final = self._make_record()

    def raise_if_failed(self):
        with self._lock:
            if self._failure is not None:
                raise ConsoleInfrastructureError("Private console session failed; repair and re-evaluate") from self._failure

    def _make_record(self):
        frozen = self._selected
        budget = self._budget()
        return {"session_id": self.session_id, "job_id": self.job_id,
                "world_id": None if self._mission is None else self._mission.get("world_id"),
                "state": self._state, "reason": self._reason,
                "started_at_monotonic": self._started_at, "budget": budget,
                "energy_used": budget["energy_used"], "observe_used": budget["observe_used"],
                "snapshot_id": None if frozen is None else frozen.snapshot_id,
                "law_sha256": None if frozen is None else frozen.law_sha256,
                "claims_sha256": None if frozen is None else frozen.claims_sha256,
                "manifest_sha256": None if frozen is None else frozen.manifest_sha256,
                "has_valid_submission": frozen is not None,
                "infrastructure_failed": self._failure is not None}

    def _seal(self, reason):
        if self._state in ("CLOSED", "FAILED"):
            return
        self._state, self._reason = "CLOSED", str(reason)
        self._selected = self._latest
        self._publish_watchdog()
        self._final = self._make_record()
        # The private final record anchors a selected snapshot, including when a
        # late in-flight save left a newer unselected store pointer.
        path = self._store.root / "finalized.json"
        temporary = path.with_name(".finalized." + uuid4().hex + ".tmp")
        try:
            with temporary.open("xb") as stream:
                stream.write((json.dumps(self._final, ensure_ascii=False, allow_nan=False,
                                         sort_keys=True, indent=2) + "\n").encode("utf-8"))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        except OSError as exc:
            self._mark_failure(exc)
            raise ConsoleInfrastructureError("Cannot persist private session finalization") from exc

    def expire_if_needed(self):
        with self._lock:
            if self._state == "ACTIVE" and self.deadline_remaining <= 0:
                self._seal("timeout")
                return True
            return False

    def close(self, reason="agent_exited"):
        """Trusted parent closes a terminated/exited agent, selecting its draft."""
        with self._lock:
            self.expire_if_needed()
            self._seal(reason)
            return self.finalized_record()

    def frozen_submission(self):
        with self._lock:
            self.raise_if_failed()
            if self._state != "CLOSED":
                raise RuntimeError("Only a closed session may be graded")
            return self._selected

    def report_bytes(self):
        with self._lock:
            self.raise_if_failed()
            return self._report

    def public_mission(self):
        """Trusted parent reads the cache without starting/resetting exploration."""
        with self._lock:
            return None if self._mission is None else _copy(self._mission)

    def finalized_record(self):
        with self._lock:
            return None if self._final is None else _copy(self._final)

    def _require_active(self):
        self.raise_if_failed()
        self.expire_if_needed()
        if self._state == "READY":
            _bad("$.method", "Call mission before using this operation", "mission_required")
        if self._state != "ACTIVE":
            _bad("$.method", "This exploration session has ended", "session_closed")

    def _validate_experiment(self, method, params):
        """Separate ordinary invalid inputs from true-simulator failures."""
        try:
            validator = getattr(self._console, "validate_request", None)
            if callable(validator):  # Diagnostic adapters may implement this.
                validator(method, params)
            elif method == "launch":
                self._console._validate_launch(params["probes"], params["t_launch"], params["readout"],
                                               params.get("source_properties"))
            else:
                from contest_simulator import DT, _sample_ticks
                ticks = _sample_ticks(params["times"], "times", limit=self._console._max_observe_times)
                if ticks[-1] * DT > self._console._time_max + 1e-12:
                    raise ValueError("Observation exceeds maximum_physical_time")
        except (ValueError, TypeError, KeyError, OverflowError):
            _bad("$.params", "Experiment input violates the published shape, grid, property or range rules")
        budget = self._budget()
        if method == "observe" and budget["observe_remaining"] <= 0:
            _bad("$.method", "The observe-call allowance is exhausted", "quota_exhausted")
        if method == "launch" and len(params["probes"]) > budget["energy_remaining"]:
            _bad("$.params.probes", "Insufficient energy for these new probes", "quota_exhausted")

    def _archive(self):
        if self._mission is None:
            _bad("$.method", "Call mission before reading the archive", "mission_required")
        return {"world_id": self._mission["world_id"], "first_light": _copy(self._mission["first_light"]),
                "observations": _copy(self._observations), **self._status()}

    def _submission(self, method, params):
        _params(params, ("law_b64", "claims_b64"), ("report_b64",))
        raw = _decode_artifact(params["law_b64"], "law_b64")
        claims = _decode_artifact(params["claims_b64"], "claims_b64")
        report = _decode_artifact(params["report_b64"], "report_b64") if "report_b64" in params else None
        try:
            frozen = getattr(self._store, method)(raw, claims)
        except SubmissionValidationError as exc:
            detail = exc.details
            if isinstance(detail, dict):
                path = detail.get("path", "$." + exc.artifact)
                message = detail.get("message", "Artifact violates the published format")
                if isinstance(detail.get("errors"), list) and detail["errors"]:
                    issue = detail["errors"][0]
                    path = issue.get("pointer", path)
                    message = issue.get("message", message)
            else:
                path, message = "$." + exc.artifact, "Artifact violates the published format"
            _bad(path, message, "invalid_submission")
        if self.expire_if_needed():
            _bad("$.method", "The session expired before this pair was accepted", "session_closed")
        self._latest, self._report = frozen, report
        if method == "submit":
            self._seal("submitted")
        return {**self._status(), "snapshot_id": frozen.snapshot_id, "operation": method,
                "ends_exploration": self._state == "CLOSED", "format_checked": True,
                "scientific_correctness_checked": False}

    def dispatch(self, method, params):
        with self._lock:
            self._operation, self._operation_started_at = method, float(self._clock())
            self._publish_watchdog()
            try:
                self.raise_if_failed()
                self.expire_if_needed()
                if method not in _METHODS:
                    _bad("$.method", "Unknown console operation")
                if method == "mission":
                    _params(params)
                    if self._state == "CLOSED":
                        if self._mission is None:
                            _bad("$.method", "This exploration session has ended", "session_closed")
                        return {**_copy(self._mission), **self._status()}
                    if self._mission is None:
                        admitted = float(self._clock())
                        value = self._console.mission()
                        self._started_at = float(getattr(self._console, "_started_at", admitted) or admitted)
                        self._state = "ACTIVE"
                        self._publish_watchdog()
                        mission = _select(value, _MISSION_KEYS, required=_MISSION_KEYS)
                        mission["background_initial_state"] = _select(
                            value["background_initial_state"], ("ids", "positions", "velocities", "properties"))
                        mission["controls"] = _select(value["controls"], ("source_properties", "probe_properties"))
                        mission["limits"] = _select(value["limits"], (
                            "energy_budget", "energy_per_new_probe", "max_probes_per_launch",
                            "max_readouts_per_probe", "observe_calls", "max_times_per_observe", "wall_clock_seconds"))
                        mission["first_light"] = _select(value["first_light"], _FIRST_KEYS, required=_FIRST_KEYS)
                        mission.update(protocol_version=EXPLORATION_PROTOCOL_VERSION,
                                       console_protocol_version=CONSOLE_PROTOCOL_VERSION,
                                       session_id=self.session_id)
                        self._mission = mission
                        self.expire_if_needed()
                        self._require_active()
                    return {**_copy(self._mission), **self._status()}
                if method == "archive":
                    _params(params)
                    return self._archive()
                self._require_active()
                if method in ("save_draft", "submit"):
                    return self._submission(method, params)
                if method == "observe":
                    _params(params, ("times",))
                else:
                    _params(params, ("probes", "t_launch", "readout"), ("source_properties",))
                self._validate_experiment(method, params)
                value = getattr(self._console, method)(**params)
                if self.expire_if_needed():
                    _bad("$.method", "The session expired while the experiment was running", "session_closed")
                keys = _OBSERVE_KEYS if method == "observe" else _LAUNCH_KEYS
                result = {**_select(value, keys, required=keys), **self._status()}
                self._observations.append(_copy(result))
                return result
            except ConsoleRequestError:
                raise
            except TimeoutError as exc:
                if self._started_at is None or self.deadline_remaining > 0:
                    self._mark_failure(exc)
                    raise ConsoleInfrastructureError("A private operation timed out before the exploration deadline") from exc
                self._seal("timeout")
                _bad("$.method", "This exploration session has ended", "session_closed")
            except ConsoleInfrastructureError as exc:
                # Response validation can itself raise this exception. Mark
                # those failures too, so a client receiving HTTP 503 cannot
                # later be mistaken for an agent exiting without a draft.
                if self._failure is None:
                    self._mark_failure(exc)
                raise
            except Exception as exc:
                self._mark_failure(exc)
                raise ConsoleInfrastructureError("Private console operation failed") from exc
            finally:
                self._operation = self._operation_started_at = None
                self._publish_watchdog()


class ConsoleService:
    """In-memory authenticated registry; tokens never appear in responses/logs."""
    def __init__(self):
        self._sessions = {}
        self._lock = threading.RLock()

    @staticmethod
    def _key(token):
        if not isinstance(token, str) or not token:
            return None
        return hashlib.sha256(token.encode("utf-8")).digest()

    def register(self, session, token=None):
        if not isinstance(session, ConsoleSession):
            raise TypeError("Expected a trusted ConsoleSession")
        token = token or secrets.token_urlsafe(32)
        key = self._key(token)
        if key is None:
            raise ValueError("A nonempty token is required")
        with self._lock:
            if key in self._sessions or any(item.session_id == session.session_id for item in self._sessions.values()):
                raise ValueError("Token or session is already registered")
            self._sessions[key] = session
        return token

    def revoke(self, token):
        with self._lock:
            self._sessions.pop(self._key(token), None)

    def _authorized_session(self, token):
        with self._lock:
            session = self._sessions.get(self._key(token))
        if session is None:
            _bad("$", "A valid session credential is required", "unauthorized")
        return session

    def expire_sessions(self):
        with self._lock:
            sessions = tuple(self._sessions.values())
        for session in sessions:
            session.expire_if_needed()

    def handle(self, token, request):
        try:
            session = self._authorized_session(token)
            if not isinstance(request, dict) or set(request) != {"protocol_version", "method", "params"}:
                _bad("$", "Expected protocol_version, method and params only")
            if request["protocol_version"] != CONSOLE_PROTOCOL_VERSION:
                _bad("$.protocol_version", "Unsupported console protocol version", "unsupported_version")
            if not isinstance(request["method"], str):
                _bad("$.method", "Expected an operation name")
            return {"ok": True, "result": _copy(session.dispatch(request["method"], request["params"]))}
        except ConsoleRequestError as exc:
            return {"ok": False, "error": exc.as_dict()}
        except ConsoleInfrastructureError:
            return {"ok": False, "error": {"code": "service_unavailable", "path": "$",
                                             "message": "The private service failed; the organizer must repair and re-evaluate"}}


def _json_request(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                _bad("$", "Duplicate JSON keys are not accepted")
            result[key] = value
        return result
    def constant(_):
        _bad("$", "Non-finite JSON constants are not accepted")
    try:
        return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=pairs, parse_constant=constant)
    except (UnicodeError, ValueError, RecursionError):
        _bad("$", "Malformed JSON request")


class _ConsoleHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_):
        pass  # In particular never emit Authorization headers or raw bodies.

    def _respond(self, envelope, status=200):
        raw = json.dumps(envelope, ensure_ascii=False, allow_nan=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(raw)
        except OSError as exc:
            # A parent may stop an expired agent while this response is being
            # sent. Connection loss does not invalidate a sealed artifact or
            # become a physics failure. Do not hide unrelated OS errors.
            if (exc.errno not in {errno.EPIPE, errno.ECONNRESET, errno.ECONNABORTED, errno.ENOTCONN}
                    and getattr(exc, "winerror", None) not in {10053, 10054, 10057}):
                raise
        finally:
            self.close_connection = True

    def do_POST(self):
        try:
            if self.path != "/v1/console":
                self._respond({"ok": False, "error": {"code": "not_found", "path": "$", "message": "Unknown endpoint"}}, 404)
                return
            if self.headers.get("Transfer-Encoding"):
                _bad("$", "Transfer-Encoding is not supported")
            content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
            if content_type != "application/json":
                _bad("$", "Content-Type must be application/json")
            try:
                length = int(self.headers.get("Content-Length", ""))
            except ValueError:
                _bad("$", "A valid Content-Length is required")
            if not 0 < length <= self.server.max_request_bytes:
                _bad("$", "Request exceeds the transport size guard")
            authorization = self.headers.get("Authorization", "")
            token = authorization[7:] if authorization.startswith("Bearer ") else None
            # Authenticate before spending time parsing untrusted payloads.
            self.server.service._authorized_session(token)
            raw = self.rfile.read(length)
            if len(raw) != length:
                _bad("$", "Incomplete JSON request")
            envelope = self.server.service.handle(token, _json_request(raw))
            code = envelope.get("error", {}).get("code")
            self._respond(envelope, 503 if code == "service_unavailable" else 200)
        except ConsoleRequestError as exc:
            self._respond({"ok": False, "error": exc.as_dict()}, 401 if exc.code == "unauthorized" else 400)

    def do_GET(self):
        self._respond({"ok": False, "error": {"code": "not_found", "path": "$", "message": "Unknown endpoint"}}, 404)


def make_http_server(service, host="127.0.0.1", port=0, *, max_request_bytes=MAX_REQUEST_BYTES):
    server = ThreadingHTTPServer((host, port), _ConsoleHandler)
    server.daemon_threads = True
    server.service = service
    server.max_request_bytes = max_request_bytes
    return server


def make_unix_server(service, socket_path, *, max_request_bytes=MAX_REQUEST_BYTES):
    """HTTP over one Unix socket; socket directory must contain no private data.

    Start/shutdown/server_close follow socketserver's normal API. Existing
    socket paths are never deleted automatically. Caller owns removing its own
    path after close and must verify the intended socket directory before use.
    """
    if not hasattr(socketserver, "UnixStreamServer"):
        raise NotImplementedError("Unix-domain console transport requires a Unix platform")
    path = Path(socket_path)
    if not path.parent.is_dir() or path.exists():
        raise ValueError("Socket parent must exist and the target path must be unused")
    class UnixConsoleServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
        daemon_threads = True
    server = UnixConsoleServer(str(path), _ConsoleHandler)
    server.service = service
    server.max_request_bytes = max_request_bytes
    os.chmod(path, 0o660)
    return server


__all__ = ["ConsoleSession", "ConsoleService", "ConsoleRequestError", "ConsoleInfrastructureError",
           "make_http_server", "make_unix_server", "CONSOLE_PROTOCOL_VERSION"]
