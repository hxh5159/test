"""Trusted organizer model mounts and Docker deployment configuration.

configure writes a new site profile without silently approving production.
preflight inspects the actual target Linux host and installed image. Neither
command downloads models or calls a remote inference provider.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from uuid import uuid4

PRIVATE=Path(__file__).resolve().parent
PUBLIC=Path(os.environ.get('RIFT_PUBLIC_ROOT', PRIVATE.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0,str(PUBLIC))
from rift.model_registry import model_spec, catalog
from contest_platform import read_profile, PROFILE_SOURCES
from contest_execution import immutable_image, public_runtime_digest, ContainerLimits
from law_program_evaluation import OrganizerConfigurationError


def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _save_new(path,value):
    path=Path(path).resolve()
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,allow_nan=False,indent=2)+'\n')


def configure(source, output, *, candidate_image, model_root, models, gpu_devices=('0','1','2','3')):
    source=Path(source).resolve();output=Path(output).resolve()
    profile=read_profile(source)
    _check_identity(profile)
    root=Path(model_root).expanduser().resolve()
    if not root.is_dir():raise OrganizerConfigurationError('Model root must be an existing mounted directory')
    if len(gpu_devices)!=4 or len(set(gpu_devices))!=4 or any(not x.isdigit() for x in gpu_devices):
        raise OrganizerConfigurationError('Exactly four distinct GPU device IDs are required')
    mounts=[];seen=set()
    for selected in models:
        item=model_spec(selected)
        if item['id'] in seen:raise OrganizerConfigurationError('Duplicate model selection')
        seen.add(item['id'])
        choices=[root/item['directory']]+[root/name for name in item.get('directory_aliases',[])]
        available=[p for p in choices if p.is_dir()]
        if not available:raise OrganizerConfigurationError('Model directory is missing for '+item['id'])
        directory=available[0]
        if not (directory/'config.json').is_file():raise OrganizerConfigurationError('Model config.json is missing')
        if not any(directory.glob('*.safetensors')):
            raise OrganizerConfigurationError('No local safetensors weights found for '+item['id'])
        mounts.append([str(directory),'/models/'+item['directory']])
    if not mounts:raise OrganizerConfigurationError('Select at least one model')
    for entry in profile['worlds'].values():
        entry['calibration_file']=Path(os.path.relpath(entry['calibration_file'],output.parent)).as_posix()
    profile.update(profile_id=output.stem,candidate_image=immutable_image(candidate_image),
        model_mounts=mounts,gpu_devices=list(gpu_devices),status='internal_validation',
        release_approved=False,runtime_limits_approved=False,domains_and_validation_approved=False,
        public_runtime_sha256=public_runtime_digest(),
        private_source_sha256={name:_sha(PRIVATE/name) for name in PROFILE_SOURCES})
    profile['policies'].update(hidden_run_artifacts='organizer_retained_no_contest_export',
        scientific_dataset='fixed-six-public-nine-hidden-20261102',exploration_wall_clock_seconds=300)
    profile['resource_values_status']='site model mounts configured; target runtime/model load and operator review still required'
    _save_new(output,profile)
    return {'profile':str(output),'status':'configured_internal','model_mount_count':len(mounts),
            'candidate_image':profile['candidate_image'],'official_release_approved':False,
            'next_step':'preflight on target Linux; actual model loading and full run remain separate checks'}


def preflight(source, *, docker='docker'):
    profile=read_profile(source)
    records={}
    def check(name,fn):
        try:records[name]={'ok':True,'details':fn()}
        except Exception as exc:records[name]={'ok':False,'error':str(exc)}
    def command(args):
        done=subprocess.run(args,check=False,text=True,capture_output=True,timeout=90)
        if done.returncode:raise OrganizerConfigurationError('Target command failed: '+done.stderr.strip()[:500])
        return done.stdout.strip()
    def linux():
        if sys.platform!='linux':raise OrganizerConfigurationError('Production execution requires Linux')
        if not shutil.which(docker):raise OrganizerConfigurationError('Docker executable is unavailable')
        return sys.platform
    check('linux_docker',linux)
    check('source_identity',lambda: _check_identity(profile))
    def image():
        target=immutable_image(profile['candidate_image'])
        resolved=command([docker,'image','inspect','--format','{{.Id}}',target])
        if resolved!=target:raise OrganizerConfigurationError('Candidate image digest mismatch')
        command([docker,'run','--rm','--network','none','--read-only','--entrypoint','python',target,
                 '-c','import numpy,scipy; print(numpy.__version__,scipy.__version__)'])
        return target
    check('candidate_image',image)
    def models():
        result=[]
        for source,target in profile['model_mounts']:
            p=Path(source)
            if not p.is_dir() or not (p/'config.json').is_file():
                raise OrganizerConfigurationError('Configured model directory is not mounted: '+target)
            if not target.startswith('/models/') or '..' in Path(target).parts:
                raise OrganizerConfigurationError('Unsafe model mount target')
            result.append({'target':target,'config_sha256':_sha(p/'config.json')})
        if not result:raise OrganizerConfigurationError('No model mounts configured')
        return result
    check('model_mounts',models)
    def gpus():
        data=command(['nvidia-smi','--query-gpu=index,name,memory.total','--format=csv,noheader,nounits'])
        rows={r.split(',')[0].strip():r for r in data.splitlines() if r.strip()}
        selected=[rows[str(i)] for i in profile['gpu_devices']]
        if len(selected)!=4 or any('H200' not in r for r in selected):
            raise OrganizerConfigurationError('Configured profile requires four complete H200 GPUs')
        if any(float(r.rsplit(',',1)[1].strip())<130*1024 for r in selected):
            raise OrganizerConfigurationError('Insufficient per-GPU memory for the H200 profile')
        return selected
    check('four_h200',gpus)
    ok=all(r['ok'] for r in records.values())
    return {'status':'basic_target_checks_passed' if ok else 'target_checks_failed',
        'schema_version':'shore-site-preflight-1.0','profile_sha256':_sha(source),
        'candidate_image':profile['candidate_image'],
        'checks':records,'model_loaded':False,'model_or_external_api_calls':0,
        'official_release_approved':False,
        'remaining':'real model generation, complete isolated run and reviewed release profile are required'}


def _mount_fingerprint(profile):
    inventory=[]
    for source,target in profile['model_mounts']:
        root=Path(source)
        files=[]
        for path in sorted(root.glob('*.safetensors')):
            stat=path.stat();files.append([path.name,stat.st_size,stat.st_mtime_ns])
        inventory.append({'source':str(root.resolve()),'target':target,
            'config_sha256':_sha(root/'config.json'),
            'index_sha256':_sha(root/'model.safetensors.index.json') if (root/'model.safetensors.index.json').is_file() else None,
            'shard_metadata':files})
    return hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def model_smoke(source, *, agent_image, models, docker='docker', output, startup_seconds=900):
    """Actually load selected local weights inside the immutable agent image."""
    profile=read_profile(source);_check_identity(profile)
    if not math.isfinite(float(startup_seconds)) or float(startup_seconds)<=0:
        raise OrganizerConfigurationError('Model startup guard must be finite and positive')
    image=immutable_image(agent_image)
    available={target for _,target in profile['model_mounts']}
    selected=[model_spec(key) for key in models]
    if not selected or any('/models/'+item['directory'] not in available for item in selected):
        raise OrganizerConfigurationError('Every smoke model must have a configured mount')
    if sys.platform!='linux':raise OrganizerConfigurationError('Model smoke runs on the target Linux GPU host')
    actual=subprocess.run([docker,'image','inspect','--format','{{.Id}}',image],capture_output=True,text=True,timeout=30)
    if actual.returncode or actual.stdout.strip()!=image:raise OrganizerConfigurationError('Agent image digest is unavailable')
    records=[]
    output=Path(output).resolve()
    if output.exists():raise FileExistsError('Use a new model smoke receipt path')
    logs=output.parent/(output.stem+'-private-logs');logs.mkdir(parents=True,exist_ok=False)
    for item in selected:
        folder=logs/item['id'];folder.mkdir()
        container_name='shore-model-smoke-'+uuid4().hex
        command=[docker,'run','--rm','--name',container_name,'--network','none','--read-only','--shm-size','16g',
            '--cap-drop','ALL','--security-opt','no-new-privileges','--user',f'{os.getuid()}:{os.getgid()}',
            '--gpus','"device='+','.join(profile['gpu_devices'])+'"',
            *ContainerLimits(**profile['agent_limits']).arguments(),
            '--mount',f'type=bind,src={folder},dst=/output',
            '--env','HOME=/output','--env','RIFT_OUTPUT_DIR=/output',
            '--env','HF_HUB_OFFLINE=1','--env','TRANSFORMERS_OFFLINE=1']
        for host,target in profile['model_mounts']:
            if ',' in str(host):raise OrganizerConfigurationError('Comma in Docker mount path')
            command+=['--mount',f'type=bind,src={host},dst={target},readonly']
        code="""import json
from shore_agent.models import managed_model
with managed_model(model_key=MODEL_KEY,model_root='/models',startup_timeout=STARTUP,log_dir='/output') as client:
    client.complete([{'role':'user','content':'Return the word ready.'}],max_tokens=32,timeout=120)
    usage=client.last_response.get('usage',{})
    tokens=usage.get('completion_tokens',usage.get('output_tokens',0))
    assert isinstance(tokens,int) and tokens>0,'No generated tokens in model smoke'
    print(json.dumps({'status':'model_smoke_passed','model':MODEL_KEY,'generated_tokens':tokens}))
""".replace('MODEL_KEY',repr(item['id'])).replace('STARTUP',str(float(startup_seconds)))
        command+=['--entrypoint','python',image,'-c',code]
        try:
            done=subprocess.run(command,capture_output=True,text=True,timeout=float(startup_seconds)+180)
        except subprocess.TimeoutExpired as exc:
            (folder/'stderr.log').write_text('Model smoke exceeded the configured startup/generation guard.',encoding='utf-8')
            raise OrganizerConfigurationError('Model smoke timed out; its container was stopped, no pass receipt was created') from exc
        finally:
            try:subprocess.run([docker,'rm','-f',container_name],capture_output=True,timeout=30,check=False)
            except (OSError,subprocess.TimeoutExpired):pass
        (folder/'stdout.log').write_text(done.stdout,encoding='utf-8')
        (folder/'stderr.log').write_text(done.stderr,encoding='utf-8')
        if done.returncode:raise OrganizerConfigurationError('Model smoke failed; inspect private logs for '+item['id'])
        row=json.loads(done.stdout.strip().splitlines()[-1])
        if row.get('status')!='model_smoke_passed':raise OrganizerConfigurationError('Invalid model smoke response')
        records.append(row)
    result={'schema_version':'shore-model-smoke-1.0','status':'model_smoke_passed',
        'profile_sha256':_sha(source),'candidate_image':profile['candidate_image'],'agent_image':image,
        'models':records,'mount_metadata_fingerprint':_mount_fingerprint(profile),
        'artifact_verification':'config/index SHA and shard size/mtime; not cryptographic provenance of every tensor',
        'real_local_model_generated':True,'external_api_calls':0}
    _save_new(output,result);return result


def release_reviewed(source, output, *, preflight_receipt, model_receipt, domains_reviewed, resources_reviewed):
    """Freeze a new released profile from matching target-host evidence."""
    source=Path(source).resolve();output=Path(output).resolve();profile=read_profile(source)
    _check_identity(profile)
    if not domains_reviewed or not resources_reviewed:
        raise OrganizerConfigurationError('The trusted operator must review actual domains and resource values')
    hardware=json.loads(Path(preflight_receipt).read_text(encoding='utf-8'))
    model=json.loads(Path(model_receipt).read_text(encoding='utf-8'))
    identity=_sha(source)
    if (hardware.get('schema_version')!='shore-site-preflight-1.0'
        or hardware.get('status')!='basic_target_checks_passed'
        or hardware.get('profile_sha256')!=identity
        or hardware.get('candidate_image')!=profile['candidate_image']
        or set(hardware.get('checks',{}))!={'linux_docker','source_identity','candidate_image','model_mounts','four_h200'}
        or not all(r.get('ok') is True for r in hardware['checks'].values())):
        raise OrganizerConfigurationError('A successful matching target-host preflight receipt is required')
    if (model.get('schema_version')!='shore-model-smoke-1.0' or model.get('status')!='model_smoke_passed'
        or model.get('profile_sha256')!=identity or model.get('candidate_image')!=profile['candidate_image']
        or model.get('real_local_model_generated') is not True
        or model.get('mount_metadata_fingerprint')!=_mount_fingerprint(profile)
        or not model.get('models')):
        raise OrganizerConfigurationError('Matching real model generation evidence is required')
    checked={row.get('model') for row in model['models'] if row.get('generated_tokens',0)>0}
    configured={model_spec(Path(target).name)['id'] for _,target in profile['model_mounts']}
    if checked!=configured:raise OrganizerConfigurationError('Every configured model requires successful generation evidence')
    immutable_image(model.get('agent_image'))
    for entry in profile['worlds'].values():
        entry['calibration_file']=Path(os.path.relpath(entry['calibration_file'],output.parent)).as_posix()
    profile.update(profile_id=output.stem,status='released',release_approved=True,
        runtime_limits_approved=True,domains_and_validation_approved=True,
        resource_values_status='trusted operator reviewed; target Docker/H200/model generation receipts matched')
    _save_new(output,profile)
    read_profile(output,require_released=True)
    return {'profile':str(output),'status':'released','source_profile_sha256':identity,
        'preflight_receipt_sha256':_sha(preflight_receipt),'model_receipt_sha256':_sha(model_receipt)}


def _check_identity(profile):
    if profile['public_runtime_sha256']!=public_runtime_digest():raise OrganizerConfigurationError('SDK identity changed')
    if profile['private_source_sha256']!={n:_sha(PRIVATE/n) for n in PROFILE_SOURCES}:
        raise OrganizerConfigurationError('Organizer source identity changed')
    return 'frozen SDK, private sources and references match'


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    c=sub.add_parser('configure');c.add_argument('--profile',required=True);c.add_argument('--output',required=True)
    c.add_argument('--candidate-image-id',required=True)
    c.add_argument('--model-root',default=catalog()['model_root']);c.add_argument('--models',nargs='+',default=['27b'])
    c.add_argument('--gpu-devices',nargs=4,default=['0','1','2','3'])
    c=sub.add_parser('preflight');c.add_argument('--profile',required=True);c.add_argument('--docker',default='docker')
    c.add_argument('--output',required=True)
    c=sub.add_parser('model-smoke');c.add_argument('--profile',required=True);c.add_argument('--agent-image-id',required=True)
    c.add_argument('--models',nargs='+',required=True);c.add_argument('--output',required=True);c.add_argument('--docker',default='docker')
    c.add_argument('--startup-seconds',type=float,default=900)
    c=sub.add_parser('release-reviewed');c.add_argument('--profile',required=True);c.add_argument('--output',required=True)
    c.add_argument('--preflight-receipt',required=True);c.add_argument('--model-receipt',required=True)
    c.add_argument('--domains-reviewed',action='store_true');c.add_argument('--resources-reviewed',action='store_true')
    a=p.parse_args(argv)
    if a.command=='configure':
        result=configure(a.profile,a.output,candidate_image=a.candidate_image_id,
            model_root=a.model_root,models=a.models,gpu_devices=tuple(a.gpu_devices))
    elif a.command=='preflight':
        result=preflight(a.profile,docker=a.docker);_save_new(a.output,result)
    elif a.command=='model-smoke':
        result=model_smoke(a.profile,agent_image=a.agent_image_id,models=a.models,
            output=a.output,docker=a.docker,startup_seconds=a.startup_seconds)
    else:
        result=release_reviewed(a.profile,a.output,preflight_receipt=a.preflight_receipt,
            model_receipt=a.model_receipt,domains_reviewed=a.domains_reviewed,resources_reviewed=a.resources_reviewed)
    print(json.dumps(result,ensure_ascii=False,allow_nan=False));return 0 if result.get('status')!='target_checks_failed' else 2


if __name__=='__main__':raise SystemExit(main())
