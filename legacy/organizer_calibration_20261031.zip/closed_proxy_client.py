"""PRIVATE closed-model calibration transport, exclusively for llmtoken.io.

Not a contest-permitted model client. Importing this module never contacts a
server. Keys are read only from an environment variable/stdin/getpass and are
never included in logs/metadata. Only the fixed HTTPS host below can receive
Authorization. No redirects, automatic retries or automatic API fallbacks.
Server model identities are self-reported; the provider supports model routing,
so a requested alias is not proof of the actual model used.
"""
from __future__ import annotations

import argparse
import getpass
import json
import math
import os
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener


BASE_URL = "https://llmtoken.io/v1"
LABEL = "closed_model_organizer_calibration_not_contest_permitted"


def read_api_key(env_name="LLMTOKEN_API_KEY", *, from_stdin=False, prompt=False):
    key = sys.stdin.readline().strip() if from_stdin else os.environ.get(env_name, "").strip()
    if not key and prompt:
        if not sys.stdin.isatty():
            raise ValueError("Interactive key entry requires a TTY; use the environment or --key-stdin.")
        key = getpass.getpass("llmtoken.io API key (not saved): ").strip()
    if not key or any(c in key for c in "\r\n"):
        raise ValueError("Provide the API key through the selected environment variable, stdin or getpass.")
    return key


class ClosedProxyError(RuntimeError):
    def __init__(self, status, message):
        self.status = status
        super().__init__(f"llmtoken.io HTTP {status}: {message}")


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class ClosedProxyClient:
    capability_label = LABEL

    def __init__(self, model, *, api_key=None, key_env="LLMTOKEN_API_KEY",
                 api_style="chat", timeout=180., max_requests=32,
                 max_output_tokens_total=16384, send_seed=False, send_temperature=False,
                 chat_token_field="max_tokens", reasoning_effort=None):
        if not isinstance(model,str) or not model.strip() or len(model)>256 or any(c in model for c in "\r\n"):
            raise ValueError("Provide an explicit provider model ID.")
        if api_style not in ("chat","responses"):
            raise ValueError("api_style must be chat or responses.")
        if chat_token_field not in ("max_tokens","max_completion_tokens"):
            raise ValueError("Unsupported chat token-limit field.")
        for value in (max_requests,max_output_tokens_total):
            if type(value) is not int or value<=0: raise ValueError("Billing caps must be positive integers.")
        if not math.isfinite(timeout) or timeout<=0: raise ValueError("timeout must be finite and positive.")
        self._api_key=api_key if api_key is not None else read_api_key(key_env)
        if not isinstance(self._api_key,str) or not self._api_key or any(c in self._api_key for c in "\r\n"):
            raise ValueError("Invalid API key input.")
        self.model=model.strip(); self.api_style=api_style; self.timeout=float(timeout)
        self.max_requests=max_requests; self.max_output_tokens_total=max_output_tokens_total
        self.send_seed=bool(send_seed); self.send_temperature=bool(send_temperature)
        self.chat_token_field=chat_token_field; self.reasoning_effort=reasoning_effort
        self._opener=build_opener(NoRedirect())
        self._requests=0; self._reserved_output=0; self._reported_output=0
        self.request_log=[]
        self.metadata={"base_url":BASE_URL,"requested_model":self.model,"calibration_label":LABEL,
            "contest_permitted":False,"api_style":api_style,"server_model_metadata":None,
            "reported_response_models":[],"model_identity_limit":"Provider self-report; aliases/routing may map to other models.",
            "billing_caps":{"max_requests":max_requests,"max_output_tokens_total":max_output_tokens_total,
                "cap_is_contest_rule":False},
            "seed_sent":self.send_seed and api_style=="chat","temperature_sent":self.send_temperature}

    @property
    def budget(self):
        return {"requests_used":self._requests,"requests_remaining":self.max_requests-self._requests,
            "output_tokens_accounted":self._reserved_output,"reported_output_tokens":self._reported_output,
            "output_tokens_remaining":max(0,self.max_output_tokens_total-self._reserved_output)}

    def _safe(self, value):
        if isinstance(value,str):
            value=value.replace(self._api_key,"[REDACTED]")
            value=re.sub(r"(?i)bearer\s+[^\s\"']+","Bearer [REDACTED]",value)
            return re.sub(r"sk-[A-Za-z0-9_-]+","[REDACTED]",value)
        if isinstance(value,list):return [self._safe(v) for v in value]
        if isinstance(value,dict):
            return {k:self._safe(v) for k,v in value.items() if k.lower() not in ("authorization","api_key","apikey","access_token")}
        return value

    def _request(self, suffix, body=None, *, reserved_output=0):
        if suffix not in ("/models","/chat/completions","/responses"):
            raise ValueError("Only fixed llmtoken.io model/chat/Responses endpoints are permitted.")
        if self._requests>=self.max_requests:raise RuntimeError("Closed calibration request cap exhausted.")
        if reserved_output>self.budget['output_tokens_remaining']:raise RuntimeError("Closed calibration output-token cap exhausted.")
        data=None if body is None else json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf8')
        req=Request(BASE_URL+suffix,data=data,method="GET" if body is None else "POST",
            headers={"Accept":"application/json","Content-Type":"application/json","Authorization":"Bearer "+self._api_key})
        self._requests+=1
        # Conservatively reserve for failures/missing usage: no hidden retry can
        # spend repeatedly without consuming the billing cap.
        self._reserved_output+=reserved_output
        started=time.monotonic();entry={"request_number":self._requests,"endpoint":suffix,
            "requested_model":None if body is None else self.model,"requested_output_limit":reserved_output}
        try:
            with self._opener.open(req,timeout=self.timeout) as response:
                raw=response.read(8*1024*1024+1)
                if len(raw)>8*1024*1024:raise RuntimeError("Response size limit exceeded.")
            payload=json.loads(raw)
            if not isinstance(payload,dict):raise ValueError("Invalid response object.")
        except HTTPError as exc:
            message="Request rejected; no automatic retry or protocol fallback."
            try:
                detail=json.loads(exc.read(4096))
                err=detail.get("error",{})
                supplied=err.get("message") if isinstance(err,dict) else None
                if isinstance(supplied,str):message=" ".join(self._safe(supplied).split())[:240]
            except Exception:pass
            entry.update(status=int(exc.code),error=message)
            raise ClosedProxyError(int(exc.code),message) from None
        except (URLError,TimeoutError,OSError):
            entry.update(status="transport_error",error="Connection failed or timed out; no automatic retry.")
            raise RuntimeError(entry['error']) from None
        except (ValueError,UnicodeError,RuntimeError):
            entry.update(status="invalid_response",error="Invalid or oversized provider response.")
            raise RuntimeError(entry['error']) from None
        else:
            usage=payload.get('usage',{})
            usage=usage if isinstance(usage,dict) else {}
            output=usage.get('completion_tokens',usage.get('output_tokens'))
            if type(output) is int and output>=0:
                self._reserved_output+=output-reserved_output
                self._reported_output+=output
            reported=payload.get('model')
            if isinstance(reported,str) and reported not in self.metadata['reported_response_models']:
                self.metadata['reported_response_models'].append(self._safe(reported))
            entry.update(status=200,server_reported_model=self._safe(reported),usage=self._safe(usage),
                         usage_missing=not bool(usage),output_usage_missing=not(type(output)is int and output>=0),
                         accounted_output=(output if type(output)is int and output>=0 else reserved_output))
            return self._safe(payload)
        finally:
            entry['elapsed_seconds']=time.monotonic()-started
            entry['budget_after']=self.budget
            self.request_log.append(entry)
            self.metadata['billing_budget']=self.budget

    def discover(self, *, fetch_models=True):
        if fetch_models:
            payload=self._request('/models')
            models=payload.get('data',[])
            if not isinstance(models,list):raise RuntimeError("Provider model list has an invalid shape.")
            self.metadata['available_model_ids']=[self._safe(m['id']) for m in models
                if isinstance(m,dict) and isinstance(m.get('id'),str)]
            selected=[m for m in models if isinstance(m,dict) and m.get('id')==self.model]
            self.metadata['server_model_metadata']=self._safe(selected[0]) if selected else None
            self.metadata['requested_model_listed']=bool(selected)
        else:
            self.metadata['requested_model_listed']=None
        return json.loads(json.dumps(self.metadata,ensure_ascii=False))

    def complete(self, messages, *, seed=0, max_tokens=2048, temperature=.3):
        if type(max_tokens)is not int or max_tokens<=0:raise ValueError("max_tokens must be positive integer.")
        remaining=self.budget['output_tokens_remaining']
        limit=min(max_tokens,remaining)
        if limit<=0:raise RuntimeError("Closed calibration output-token cap exhausted.")
        if self.api_style=='chat':
            body={"model":self.model,"messages":messages,self.chat_token_field:limit,"stream":False}
            if self.send_seed:body['seed']=int(seed)
            if self.send_temperature:body['temperature']=float(temperature)
            if self.reasoning_effort is not None:body['reasoning_effort']=self.reasoning_effort
            return self._request('/chat/completions',body,reserved_output=limit)
        body={"model":self.model,"input":messages,"max_output_tokens":limit,"stream":False,"store":False}
        if self.send_temperature:body['temperature']=float(temperature)
        if self.reasoning_effort is not None:body['reasoning']={"effort":self.reasoning_effort}
        raw=self._request('/responses',body,reserved_output=limit)
        text=raw.get('output_text')
        if not isinstance(text,str):
            pieces=[]
            output=raw.get('output')
            for item in output if isinstance(output,list) else []:
                if isinstance(item,dict) and item.get('type')=='message':
                    pieces.extend(c['text'] for c in item.get('content',[]) if isinstance(c,dict) and c.get('type')=='output_text' and isinstance(c.get('text'),str))
            text=''.join(pieces)
        return {"id":raw.get('id'),"model":raw.get('model'),"usage":raw.get('usage',{}),
            "choices":[{"message":{"role":"assistant","content":text},"finish_reason":"stop" if raw.get('status')=='completed' else raw.get('status')}],
            "calibration_transport":{"api_style":"responses","label":LABEL}}

    def probe(self, *, max_tokens=16):
        return self.complete([{"role":"user","content":"Reply only with OK."}],seed=0,max_tokens=max_tokens,temperature=0.)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',required=True)
    parser.add_argument('--api-style',choices=['chat','responses'],default='chat')
    parser.add_argument('--key-env',default='LLMTOKEN_API_KEY')
    parser.add_argument('--key-stdin',action='store_true')
    parser.add_argument('--key-prompt',action='store_true')
    parser.add_argument('--list-models',action='store_true')
    parser.add_argument('--probe',action='store_true')
    parser.add_argument('--probe-max-tokens',type=int,default=16)
    parser.add_argument('--max-requests',type=int,default=4)
    parser.add_argument('--max-output-tokens-total',type=int,default=128)
    parser.add_argument('--chat-token-field',choices=['max_tokens','max_completion_tokens'],default='max_tokens')
    args=parser.parse_args(argv)
    key=read_api_key(args.key_env,from_stdin=args.key_stdin,prompt=args.key_prompt)
    client=ClosedProxyClient(args.model,api_key=key,api_style=args.api_style,max_requests=args.max_requests,
        max_output_tokens_total=args.max_output_tokens_total,chat_token_field=args.chat_token_field)
    result={'label':LABEL,'contest_permitted':False}
    if args.list_models:result['discovery']=client.discover()
    if args.probe:result['probe']=client.probe(max_tokens=args.probe_max_tokens)
    result['requests']=client.request_log;result['budget']=client.budget
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0


if __name__=='__main__':raise SystemExit(main())
