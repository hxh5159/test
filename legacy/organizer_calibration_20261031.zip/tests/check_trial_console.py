"""Meaningful regression checks for the private calibration console only."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import time
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from trial_console import TrialConsole
from contest_simulator import ContestSimulator, SINGLE_CENTER


class Clock:
    def __init__(self): self.value = 100.0
    def __call__(self): return self.value


def configuration(world="Adam"):
    single = world in SINGLE_CENTER
    source = {"p1": {"min": .5, "max": 2., "default": 1.}} if single else {}
    props = {"p2" if single else "mass": {"min": .5, "max": 4., "default": 1.}}
    selected = {key: item["default"] for key, item in props.items()}
    first = {"t_launch": 0., "readout": [0., .005, .01, .02, .05, .1, .2, .5],
        "source_properties": {key: item["default"] for key,item in source.items()},
        "probes": [{"pos": [2.,0.], "vel": [0.,.2], "properties": selected.copy()},
                   {"pos": [0.,4.], "vel": [-.2,0.], "properties": selected.copy()}]}
    return {"launch_region": {"kind":"annulus", "center":[0.,0.], "radius_min":1., "radius_max":12.},
        "initial_speed_max": 4., "maximum_physical_time": 5., "maximum_single_trajectory_duration": 2.,
        "source_properties": source, "probe_properties": props, "energy_budget": 100,
        "observe_calls":20,"max_probes_per_launch":8,"max_readouts_per_probe":50,
        "max_times_per_observe":50,"wall_clock_seconds":3600,"first_light":first}


def probe(world="Adam", pos=None, vel=None, value=1.):
    return {"pos": [2.,0.] if pos is None else pos, "vel": [0.,.2] if vel is None else vel,
            "properties": {"p2" if world in SINGLE_CENTER else "mass":value}}


class TrialConsoleTests(unittest.TestCase):
    def setUp(self):
        self.clock=Clock()
        self.console=TrialConsole("Adam", .03, 173, configuration(), clock=self.clock)

    def test_mission_first_light_free_cached_and_detached(self):
        first=self.console.mission()
        self.assertEqual(first['budget']['energy_used'],0)
        self.assertEqual(first['budget']['observe_used'],0)
        self.assertEqual(np.asarray(first['first_light']['positions']).shape,(8,2,2))
        self.assertEqual(len(first['first_light']['visible_background_positions']),8)
        self.assertEqual(self.console.mission()['first_light'],first['first_light'])
        self.assertEqual(self.console.archive()['first_light'],first['first_light'])
        first['first_light']['positions'][0][0][0]=123456
        first['background_initial_state']['positions'][0][0]=123456
        self.assertNotEqual(self.console.mission()['first_light']['positions'][0][0][0],123456)
        self.assertEqual(self.console.mission()['background_initial_state']['positions'][0][0],0.)

    def test_fresh_observations_noise_and_cached_archive(self):
        self.console.mission()
        a=self.console.observe([0.,.5])
        b=self.console.observe([0.,.5])
        self.assertNotEqual(a['positions'],b['positions'])
        self.assertNotIn('velocities',a)
        self.assertEqual(a['ids'],['N0'])
        archived=self.console.archive()['observations']
        self.assertEqual(archived[0],a)
        self.assertEqual(archived[1],b)
        again=self.console.archive()['observations']
        self.assertEqual(again,archived)
        archived[0]['positions'][0][0][0]=9999.
        self.assertNotEqual(self.console.archive()['observations'][0]['positions'][0][0][0],9999.)

    def test_energy_and_observe_limits_are_independent(self):
        self.console.mission()
        for _ in range(20): self.console.observe([0.])
        with self.assertRaises(RuntimeError): self.console.observe([0.])
        self.assertEqual(self.console.budget['energy_remaining'],100)
        # Exhaust exactly100 paid probes, even after observe is exhausted.
        for count in [8]*12+[4]: self.console.launch([probe() for _ in range(count)],0.,[0.],{'p1':1.})
        self.assertEqual(self.console.budget['energy_remaining'],0)
        self.assertEqual(self.console.budget['observe_remaining'],0)
        with self.assertRaises(RuntimeError): self.console.launch([probe()],0.,[0.],{'p1':1.})
        other=TrialConsole('Adam',.01,2,configuration(),clock=Clock())
        other.mission()
        for count in [8]*12+[4]: other.launch([probe() for _ in range(count)],0.,[0.],{'p1':1.})
        self.assertEqual(other.observe([0.])['budget']['observe_used'],1)

    def test_probe_velocity_is_clean_position_noisy(self):
        self.console.mission()
        request=dict(probes=[probe(),probe(pos=[0.,4.],vel=[-.2,0.])],t_launch=.5,
                     readout=[0.,.1,.25],source_properties={'p1':1.})
        expected=ContestSimulator('Adam').launch(**request)
        answer=self.console.launch(**request)
        np.testing.assert_array_equal(answer['velocities'],expected['velocities'])
        self.assertGreater(float(np.max(np.abs(np.asarray(answer['positions'])-expected['positions']))),0.)
        self.assertEqual(answer['budget']['energy_used'],2)
        self.assertNotIn('background_positions',answer)
        self.assertNotIn('background_velocities',answer)

    def test_noise_distribution_is_per_coordinate_and_independent(self):
        self.console.mission()
        offsets=(np.arange(50)*.005).tolist()
        noise=[]
        for n in [8]*12+[4]:
            probes=[probe() for _ in range(n)]
            true=ContestSimulator('Adam').launch(probes,0.,offsets,{'p1':1.})
            observed=self.console.launch(probes,0.,offsets,{'p1':1.})
            noise.append((np.asarray(observed['positions'])-true['positions']).reshape(-1,2))
        z=np.concatenate(noise,axis=0)/.03
        self.assertLess(abs(float(z.mean())),.05)
        self.assertLess(abs(float(z.std())-1),.05)
        self.assertLess(abs(float(np.corrcoef(z.T)[0,1])),.05)
        self.assertLess(abs(float(np.corrcoef(z[:-1,0],z[1:,0])[0,1])),.05)

    def test_invalid_inputs_do_not_mutate_normal_accounting(self):
        self.console.mission()
        original=self.console.budget.copy()
        invalid=[dict(probes=[],t_launch=0.,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe()]*9,t_launch=0.,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe(pos=[.2,0.])],t_launch=0.,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe(vel=[5.,0.])],t_launch=0.,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=.003,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[.1,.05],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[0.]*2,source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[0.,float('nan')],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[0.,2.005],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=4.,readout=[0.,2.],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[0.],source_properties={'p1':3.}),
            dict(probes=[probe(value=0.)],t_launch=0.,readout=[0.],source_properties={'p1':1.}),
            dict(probes=[probe()],t_launch=0.,readout=[0.],source_properties={'p1':1.,'kernel':'x'})]
        for request in invalid:
            with self.subTest(request=request):
                with self.assertRaises((ValueError,TypeError)): self.console.launch(**request)
                self.assertEqual(self.console.budget,original)
        for times in [[],[.003],[0.,6.],(np.arange(51)*.005).tolist()]:
            with self.assertRaises(ValueError): self.console.observe(times)
            self.assertEqual(self.console.budget,original)

    def test_wall_clock_first_mission_and_no_reset(self):
        self.assertEqual(self.console.budget['wall_clock_remaining_seconds'],3600)
        with self.assertRaises(RuntimeError): self.console.observe([0.])
        self.clock.value+=10000
        self.console.mission()
        self.clock.value+=123
        a=self.console.mission()
        self.assertEqual(a['budget']['wall_clock_remaining_seconds'],3477)
        self.clock.value+=3477
        with self.assertRaises(TimeoutError): self.console.launch([probe()],0.,[0.],{'p1':1.})
        with self.assertRaises(TimeoutError): self.console.observe([0.])
        with self.assertRaises(TimeoutError): self.console.mission()

    def test_call_order_is_not_physical_time_progress(self):
        c=TrialConsole('Sachiel',0.,1,configuration('Sachiel'),clock=Clock())
        c.mission()
        late=c.observe([3.,4.])
        early=c.observe([0.,1.])
        again=c.observe([3.,4.])
        self.assertEqual(late['positions'],again['positions'])
        self.assertEqual(early['positions'][0][0],[0.,0.])
        np.testing.assert_allclose(np.asarray(late['positions'])[:,0,1],[.45,.8],atol=1e-12,rtol=0)
        data=c.launch([probe('Sachiel',pos=[4.,0.],vel=[0.,1.])],2.,[0.,.5],{})
        np.testing.assert_allclose(data['times'],[2.,2.5],atol=0,rtol=0)

    def test_all_nine_worlds_json_boundary_and_hidden_absence(self):
        names=['Adam','Lilith','Tabris','Sachiel','Ramiel','Matriel','Leliel','Arael','Lilin']
        counts=[1,1,1,21,21,9,1,9,9]
        forbidden={'sigma','truth','ground_truth','fixed_parameters','source','response','hidden','sources','kernel','cache_token'}
        def scan(value):
            if isinstance(value,dict):
                # The transcript's response envelope is not a physical
                # response-charge attribute in the observation payload.
                if set(value)=={'operation','request','response'}:
                    scan(value['request'])
                    scan(value['response'])
                    return
                self.assertTrue(forbidden.isdisjoint(value))
                for x in value.values(): scan(x)
            elif isinstance(value,list):
                for x in value: scan(x)
        for name,count in zip(names,counts):
            with self.subTest(name=name):
                config=configuration(name)
                c=TrialConsole(name,.02,3,config,clock=Clock())
                mission=c.mission()
                self.assertEqual(len(mission['background_initial_state']['ids']),count)
                source={'p1':1.} if name in SINGLE_CENTER else {}
                c.launch([probe(name)],0.,[0.,.1],source)
                c.observe([0.,.1])
                c.archive()
                transcript=c.public_transcript
                scan(transcript)
                json.dumps(transcript,allow_nan=False)
                transcript[0]['response']['world_id']='mutated'
                self.assertEqual(c.public_transcript[0]['response']['world_id'],name)

    def test_seed_reproducibility_and_request_copy(self):
        a=self.console
        b=TrialConsole('Adam',.03,173,configuration(),clock=Clock())
        self.assertEqual(a.mission(),b.mission())
        request={'probes':[probe()], 't_launch':0.,'readout':[0.,.1], 'source_properties':{'p1':1.}}
        saved=copy.deepcopy(request)
        first=a.launch(**request)
        second=b.launch(**request)
        self.assertEqual(first,second)
        self.assertEqual(request,saved)
        request['probes'][0]['pos'][0]=999.
        first['probes'][0]['pos'][0]=888.
        self.assertEqual(a.archive()['observations'][0]['probes'][0]['pos'][0],2.)
        other=TrialConsole('Adam',.03,174,configuration(),clock=Clock())
        self.assertNotEqual(a.mission()['first_light'],other.mission()['first_light'])


if __name__=='__main__':
    started=time.perf_counter()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(TrialConsoleTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'scope':'private calibration console unit/contract checks; not deployment isolation or LLM validation',
        'status':'pass' if result.wasSuccessful() else 'fail','test_methods':result.testsRun,
        'failures':[str(t) for t,_ in result.failures], 'errors':[str(t) for t,_ in result.errors],
        'elapsed_seconds':time.perf_counter()-started}
    path=ROOT/'checks/trial_console_tests.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    sys.exit(0 if result.wasSuccessful() else 1)
