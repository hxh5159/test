"""No-network protocol/billing/secret-handling tests; no actual model call."""
import io
import json
from pathlib import Path
import sys
import time
import unittest
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from closed_proxy_client import ClosedProxyClient,ClosedProxyError,BASE_URL,LABEL,NoRedirect

SECRET='mock-only-secret-not-a-real-key'


class Reply:
    def __init__(self,value):self.raw=json.dumps(value).encode()
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self,limit):return self.raw[:limit]


class MockOpener:
    def __init__(self,items):self.items=list(items);self.calls=[]
    def open(self,request,timeout):
        self.calls.append(request)
        item=self.items.pop(0)
        if isinstance(item,Exception):raise item
        return Reply(item)


class ClosedProxyTests(unittest.TestCase):
    def client(self,items,**kwargs):
        client=ClosedProxyClient('closed-test-model',api_key=SECRET,**kwargs)
        client._opener=MockOpener(items)
        return client

    def test_fixed_host_and_chat_compatibility_metadata(self):
        c=self.client([{'data':[{'id':'closed-test-model','owned_by':'provider'}]},
            {'model':'provider-reported-model','choices':[{'message':{'content':'OK'}}],
             'usage':{'prompt_tokens':7,'completion_tokens':2,'total_tokens':9}}])
        self.assertFalse(c.discover()['contest_permitted'])
        self.assertEqual(c.metadata['available_model_ids'],['closed-test-model'])
        result=c.probe(max_tokens=16)
        self.assertEqual(result['choices'][0]['message']['content'],'OK')
        for req in c._opener.calls:self.assertTrue(req.full_url.startswith(BASE_URL+'/'))
        req=c._opener.calls[1];body=json.loads(req.data)
        self.assertEqual(req.full_url,BASE_URL+'/chat/completions')
        self.assertEqual(body['max_tokens'],16)
        self.assertNotIn('seed',body);self.assertNotIn('temperature',body)
        self.assertEqual(c.metadata['reported_response_models'],['provider-reported-model'])
        self.assertEqual(c.budget['output_tokens_accounted'],2)
        self.assertNotIn(SECRET,json.dumps([result,c.metadata,c.request_log]))
        self.assertEqual(req.get_header('Authorization'),'Bearer '+SECRET)
        self.assertEqual(NoRedirect().redirect_request(None,None,302,'redirect',{},'https://evil.example'),None)
        with self.assertRaises(ValueError):c._request('https://evil.example/v1')

    def test_output_budget_clamps_and_missing_usage_reserves(self):
        c=self.client([{'model':'closed-test-model','choices':[],'usage':{'completion_tokens':3}},
                       {'model':'closed-test-model','choices':[]}],max_requests=5,max_output_tokens_total=8)
        c.complete([],max_tokens=10)
        self.assertEqual(json.loads(c._opener.calls[0].data)['max_tokens'],8)
        c.complete([],max_tokens=10)
        self.assertEqual(json.loads(c._opener.calls[1].data)['max_tokens'],5)
        self.assertEqual(c.budget['output_tokens_remaining'],0)
        with self.assertRaises(RuntimeError):c.complete([],max_tokens=1)
        self.assertEqual(len(c._opener.calls),2)

    def test_request_cap_counts_models_and_failed_requests(self):
        failure=HTTPError(BASE_URL+'/chat/completions',429,'x',{},io.BytesIO(b'{"error":{"message":"rate limited"}}'))
        c=self.client([{'data':[]},failure],max_requests=2,max_output_tokens_total=100)
        c.discover()
        with self.assertRaises(ClosedProxyError):c.complete([],max_tokens=7)
        self.assertEqual(c.budget['output_tokens_accounted'],7)
        self.assertEqual(c.budget['requests_used'],2)
        with self.assertRaises(RuntimeError):c.complete([],max_tokens=7)
        self.assertEqual(len(c._opener.calls),2)

    def test_error_body_secrets_are_redacted_no_headers_logged(self):
        message='Denied key '+SECRET+' Authorization: Bearer sk-FAKE-KEY'
        error=HTTPError(BASE_URL+'/chat/completions',401,'x',{'Authorization':SECRET},
            io.BytesIO(json.dumps({'error':{'message':message}}).encode()))
        c=self.client([error])
        with self.assertRaises(ClosedProxyError) as caught:c.complete([],max_tokens=8)
        self.assertEqual(caught.exception.status,401)
        text=json.dumps([str(caught.exception),c.request_log,c.metadata])
        self.assertNotIn(SECRET,text)
        self.assertNotIn('sk-FAKE-KEY',text)
        self.assertIn('REDACTED',text)

    def test_responses_adapter_and_token_accounting(self):
        c=self.client([{'id':'resp_mock','model':'reported-response-model','status':'completed',
            'output':[{'type':'reasoning','summary':[]},{'type':'message','content':[{'type':'output_text','text':'{"action":"mission"}'}]}],
            'usage':{'input_tokens':10,'output_tokens':4,'total_tokens':14}}],api_style='responses',reasoning_effort='low')
        result=c.complete([{'role':'user','content':'one JSON action'}],seed=8,max_tokens=20,temperature=.2)
        self.assertEqual(result['choices'][0]['message']['content'],'{"action":"mission"}')
        body=json.loads(c._opener.calls[0].data)
        self.assertEqual(c._opener.calls[0].full_url,BASE_URL+'/responses')
        self.assertEqual(body['max_output_tokens'],20)
        self.assertEqual(body['reasoning'],{'effort':'low'})
        self.assertFalse(body['store'])
        self.assertEqual(c.budget['output_tokens_accounted'],4)
        self.assertEqual(result['calibration_transport']['label'],LABEL)

    def test_chat_max_completion_tokens_and_explicit_sampling(self):
        c=self.client([{'choices':[{'message':{'content':'x'}}],'usage':{'completion_tokens':1}}],
            chat_token_field='max_completion_tokens',send_seed=True,send_temperature=True)
        c.complete([],seed=8,max_tokens=30,temperature=.4)
        body=json.loads(c._opener.calls[0].data)
        self.assertEqual(body['max_completion_tokens'],30)
        self.assertNotIn('max_tokens',body)
        self.assertEqual(body['seed'],8)
        self.assertEqual(body['temperature'],.4)


if __name__=='__main__':
    start=time.perf_counter()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ClosedProxyTests))
    report={'status':'pass' if result.wasSuccessful() else 'fail','scope':'MOCK ONLY; no real key, network or model calls',
        'actual_network_calls':0,'test_methods':result.testsRun,'failures':[str(t) for t,_ in result.failures],
        'errors':[str(t) for t,_ in result.errors],'elapsed_seconds':time.perf_counter()-start}
    (ROOT/'checks/closed_proxy_client_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    sys.exit(0 if result.wasSuccessful() else 1)
