"""Private safe-expression tests; synthetic public records, no world truth."""
import copy
from pathlib import Path
import sys
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from expression_candidate import SafeExpression,ExpressionCandidate,fit_expression,SCHEMA,VARIABLES


def mission():
    return {'controls':{'source_properties':{},'probe_properties':{'mass':{'min':.5,'max':4.,'default':1.}}},
        'launch_region':{'center':[0.,0.]},
        'background_initial_state':{'ids':['N0'],'positions':[[0.,0.]],'velocities':[[0.,0.]]}}


def synthetic_transcript():
    probes=[{'pos':[1.+.2*i,(-1.)**i*(.4+.1*i)],'vel':[.1*i,-.03*i],'properties':{'mass':1.}} for i in range(12)]
    times=np.array([0.,.005,.01])
    frequency=np.sqrt(.7)
    pos=np.array([p['pos'] for p in probes]);vel=np.array([p['vel'] for p in probes])
    velocities=np.cos(frequency*times[:,None,None])*vel[None]-frequency*np.sin(frequency*times[:,None,None])*pos[None]
    record={'experiment_id':'L0001','t_launch':0.,'readout':times.tolist(),'source_properties':{},
        'probes':probes,'velocities':velocities.tolist(),
        'positions':np.ones_like(velocities).tolist()}
    return [{'operation':'launch','request':{},'response':record}]


class ExpressionTests(unittest.TestCase):
    def test_allowed_vector_math_and_zero_mask(self):
        expression=SafeExpression('where(r>0, -p0*dx/(maximum(r,1e-12)*rho), 0)',VARIABLES|{'p0'})
        env={'r':np.array([0.,2.]),'rho':np.array([.05,np.sqrt(4+.05**2)]),
             'dx':np.array([0.,2.]),'p0':3.}
        value=expression(env)
        self.assertEqual(value[0],0.)
        self.assertAlmostEqual(value[1],-3/np.sqrt(4+.05**2))

    def test_scientific_functions_are_exact_whitelist_dispatch(self):
        expr=SafeExpression('np.exp(-x)+sin(t)+scipy.special.k1(p0)',VARIABLES|{'p0'})
        value=expr({'x':np.array([0.,1.]),'t':0.,'p0':1.})
        np.testing.assert_allclose(value,[1+.6019072301972346,np.exp(-1)+.6019072301972346])

    def test_arbitrary_python_rejected(self):
        forbidden=['__import__("os").system("whoami")','open("secret")','x.__class__',
                   '(lambda: 1)()','[z for z in x]','x[0]','np.load("file")',
                   'getattr(np,"exp")(x)','np.exp(x,out=x)','(1,2)','True',
                   'p5+x','globals()','np.random.random()','(x:=1)']
        for expression in forbidden:
            with self.subTest(expression=expression):
                with self.assertRaises(ValueError):SafeExpression(expression,VARIABLES|{'p0'})

    def test_public_data_fits_proposed_constant_without_truth_access(self):
        spec={'ax':'-p0*x','ay':'-p0*y','parameters':{'p0':{'initial':.2,'bounds':[.01,2.]}}}
        result=fit_expression(mission(),synthetic_transcript(),spec)
        self.assertAlmostEqual(result['fitted_parameters']['p0'],.7,places=5)
        self.assertFalse(result['diagnostics']['true_world_state_access'])
        self.assertTrue(result['diagnostics']['uses_no_added_velocity_noise'])
        self.assertLess(result['diagnostics']['public_holdout_loss'],1e-9)

    def test_serialization_and_shared_rollout(self):
        fitted=fit_expression(mission(),synthetic_transcript(),
            {'ax':'-p0*x','ay':'-p0*y','parameters':{'p0':{'initial':.2,'bounds':[.01,2.]}}})
        c=fitted['candidate'];restored=ExpressionCandidate.from_dict(c.to_dict())
        case={'t_launch':0.,'readout':[0.,.5,1.],'source_properties':{},
              'probes':[{'pos':[1.,0.],'vel':[0.,0.],'properties':{'mass':1.}}]}
        a=c.predict(case);b=restored.predict(case)
        np.testing.assert_array_equal(a,b)
        self.assertAlmostEqual(a[-1,0,0],np.cos(np.sqrt(.7)),places=5)

    def test_center_acceleration_is_a_parameter_expression_only(self):
        model={'schema_version':SCHEMA,'ax':'p0','ay':'p1','parameters':{'p0':.1,'p1':.2},
            'center_accel':['p0','p1'],
            'bindings':{'center_position':[0.,0.],'center_velocity':[0.,0.],
                        'source_key':None,'source_default':1.,'probe_key':'mass','probe_default':1.}}
        c=ExpressionCandidate(model)
        case={'t_launch':2.,'readout':[0.,1.],'source_properties':{},
              'probes':[{'pos':[1.,0.],'vel':[0.,0.],'properties':{'mass':1.}}]}
        np.testing.assert_allclose(c.predict(case)[-1,0],[1.05,.1],rtol=0,atol=1e-12)
        bad=copy.deepcopy(model);bad['center_accel']=['t','0']
        with self.assertRaises(ValueError):ExpressionCandidate(bad)

    def test_five_parameter_limit_and_velocity_interface_are_explicit(self):
        bad={'ax':'x','ay':'y','parameters':{f'p{i}':{'initial':1.,'bounds':[.1,2.]} for i in range(6)}}
        with self.assertRaises(ValueError):fit_expression(mission(),synthetic_transcript(),bad)
        with self.assertRaises(ValueError):
            fit_expression(mission(),synthetic_transcript(),{'ax':'-vx','ay':'-vy','parameters':{}})


if __name__=='__main__':unittest.main(verbosity=2)
