"""Protocol-only mocks: these tests do not run or assess any real LLM."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from llm_trial_runner import (allowed_model,VLLMClient,parse_action,SimpleCandidate,LLMTrial,
                              claims_valid,candidate_from_artifact,preview_payload,weight_metadata)
from trial_console import TrialConsole
from check_trial_console import configuration,Clock,probe


CLAIMS={'dynamics_order':2,'hidden_matter':False,'time_dependence':False}


class ScriptedTransport:
    capability_label='protocol_mock_only_not_real_LLM'
    metadata={'mock':True,'served_model':'Qwen3.6-35B-A3B-W8A8'}
    def __init__(self,actions):self.actions=list(actions);self.requests=[]
    def complete(self,messages,**kwargs):
        self.requests.append((messages,kwargs))
        action=self.actions.pop(0)
        text=action if isinstance(action,str) else json.dumps(action)
        return {'model':self.metadata['served_model'],'choices':[{'message':{'role':'assistant','content':text},'finish_reason':'stop'}],
                'usage':{'prompt_tokens':100,'completion_tokens':20}}


class Reply:
    def __init__(self,payload):self.raw=json.dumps(payload).encode()
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self,limit):return self.raw[:limit]


class RecordingOpener:
    def __init__(self):self.calls=[]
    def open(self,request,timeout):
        self.calls.append(request)
        if request.full_url.endswith('/models'):
            return Reply({'data':[{'id':'/weights/Qwen3.6-35B-A3B-W8A8','object':'model','owned_by':'vllm','max_model_len':32768}]})
        return Reply({'choices':[{'message':{'content':'{"action":"mission"}'}}]})


class LLMRunnerProtocolTests(unittest.TestCase):
    def console(self):return TrialConsole('Adam',.03,3,configuration(),clock=Clock())

    def test_white_list_quantized_basename_and_rejections(self):
        for name in ['Qwen3.6-35B-A3B','/weights/Qwen3.6-35B-A3B-W8A8','org/GLM-4.7-Flash']:
            self.assertIsInstance(allowed_model(name),str)
        for name in ['gpt-5.5','claude-opus-4-7','Qwen3.6-35B-A3B-evil','',None]:
            with self.assertRaises(ValueError):allowed_model(name)

    def test_http_format_metadata_and_secret_not_logged(self):
        client=VLLMClient('http://127.0.0.1:8000','Qwen3.6-35B-A3B-W8A8',api_key='test-secret-key')
        opener=RecordingOpener();client._opener=opener
        metadata=client.discover()
        result=client.complete([{'role':'user','content':'JSON action please'}],seed=4,max_tokens=100,temperature=.2)
        self.assertEqual(client.model,'/weights/Qwen3.6-35B-A3B-W8A8')
        self.assertNotIn('test-secret-key',json.dumps(metadata))
        self.assertTrue(opener.calls[0].full_url.endswith('/v1/models'))
        request=opener.calls[1]
        body=json.loads(request.data)
        self.assertEqual(request.full_url,'http://127.0.0.1:8000/v1/chat/completions')
        self.assertEqual(body['model'],client.model)
        self.assertEqual(body['seed'],4)
        self.assertNotIn('test-secret-key',request.data.decode())
        self.assertEqual(request.get_header('Authorization'),'Bearer test-secret-key')
        self.assertEqual(parse_action(result['choices'][0]['message']['content']),{'action':'mission'})
        for url in ['https://user:pass@localhost:8000','http://localhost?key=x','http://localhost#key','not-url']:
            with self.assertRaises(ValueError):VLLMClient(url,'Qwen3.6-35B-A3B')

    def test_parser_claim_types_and_simple_candidate(self):
        parsed=parse_action('<think>hidden private reasoning</think>```json\n{"action":"mission"}\n```')
        self.assertEqual(parsed,{'action':'mission'})
        for text in ['{"action":"mission"} {"action":"fit"}','{"action":"fit","action":"mission"}','{"action":"finish","value":NaN}']:
            with self.assertRaises(ValueError):parse_action(text)
        self.assertEqual(claims_valid(CLAIMS),CLAIMS)
        with self.assertRaises(ValueError):claims_valid({**CLAIMS,'time_dependence':'false'})
        with self.assertRaises(ValueError):claims_valid({**CLAIMS,'dynamics_order':True})
        c=candidate_from_artifact({'runner_simple_family':'constant_acceleration','acceleration':[0.,2.]})
        case={'readout':[0.,1.,2.],'probes':[{'pos':[1.,0.],'vel':[0.,1.]}]}
        np.testing.assert_array_equal(c.predict(case),[[[1.,0.]],[[1.,2.]],[[1.,6.]]])

    def test_preview_retains_access_to_omitted_data(self):
        payload={'times':list(range(20)),'positions':[[[i,0.]] for i in range(20)],'velocities':[[[0.,0.]]]*20}
        short=preview_payload(payload,7)
        self.assertNotIn('positions',short)
        self.assertTrue(short['full_data_available'])
        self.assertEqual(short['read_full_data']['record_id'],7)
        self.assertEqual(short['sample_preview']['positions']['omitted_samples'],16)
        self.assertEqual(len(payload['positions']),20)

    def test_mock_closed_loop_fit_only_uses_public_data(self):
        fit_calls=[]
        def fit(mission,transcript):
            fit_calls.append((mission,transcript))
            launches=[r for r in transcript if r['operation']=='launch']
            self.assertEqual(len(launches),1)
            self.assertEqual(launches[0]['response']['budget']['energy_used'],2)
            return {'candidate':SimpleCandidate('ballistic'),'claims':CLAIMS,
                    'diagnostics':{'source':'mock protocol; not model learning','launches':len(launches)}}
        actions=[{'action':'observe','times':[0.,.1]},
            {'action':'launch','probes':[probe(),probe(pos=[0.,3.],vel=[-.2,0.])],
             't_launch':0.,'readout':[0.,.005,.01,.1],'source_properties':{'p1':1.}},
            {'action':'view_record','record_id':2,'start':1,'count':2},
            {'action':'fit'},
            {'action':'finish','candidate_id':'fit_1','claims':CLAIMS,'report':'Protocol mock only'}]
        transport=ScriptedTransport(actions)
        with tempfile.TemporaryDirectory(prefix='white_model_protocol_',dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            trial=LLMTrial(self.console(),transport,seed=10,out_dir=folder,fit_fn=fit)
            result=trial.run()
            self.assertEqual(result['status'],'submitted')
            self.assertEqual(result['energy_used'],2)
            self.assertEqual(result['observe_used'],1)
            self.assertEqual(result['model_turns'],5)
            saved=json.loads((Path(folder)/'run.json').read_text(encoding='utf8'))
            self.assertEqual(saved['capability_label'],'protocol_mock_only_not_real_LLM')
            self.assertEqual(saved['diagnostic_model_turn_cap'],0)
            self.assertFalse(saved['cap_is_contest_rule'])
            events=json.loads((Path(folder)/'model_events.json').read_text(encoding='utf8'))
            self.assertEqual(events[0]['model_request']['messages'],transport.requests[0][0])
            self.assertEqual(json.loads((Path(folder)/'claims.json').read_text()),CLAIMS)
            archive=json.loads((Path(folder)/'public_records.json').read_text())
            self.assertEqual(len(archive[2]['data']['positions']),4)
            model_text=json.dumps(transport.requests,ensure_ascii=False)
            for private_field in ['"fixed_parameters"','"sigma_current"','"truths"','"kernel"']:
                self.assertNotIn(private_field,model_text)
            self.assertEqual(len(fit_calls),1)

    def test_invalid_action_can_recover_without_experiments(self):
        transport=ScriptedTransport(['not json',{'action':'exec','code':'raise Exception'},
            {'action':'finish','candidate':{'runner_simple_family':'ballistic','acceleration':[0.,0.]},'claims':CLAIMS}])
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            trial=LLMTrial(self.console(),transport,seed=0,out_dir=folder)
            result=trial.run()
            self.assertEqual(result['status'],'submitted')
            self.assertEqual(result['energy_used'],0)
            self.assertIn('action_error',trial.events[0]['tool_response'])
            self.assertIn('action_error',trial.events[1]['tool_response'])

    def test_context_trimming_is_explicit_and_turn_limit_not_fake_submission(self):
        transport=ScriptedTransport([{'action':'mission'}])
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            trial=LLMTrial(self.console(),transport,seed=0,out_dir=folder,max_turns=1,context_chars=12000)
            result=trial.run()
            self.assertEqual(result['status'],'turn_limit_no_submission')
            saved=json.loads((Path(folder)/'run.json').read_text(encoding='utf8'))
            self.assertEqual(saved['diagnostic_model_turn_cap'],1)
            self.assertFalse(saved['cap_is_contest_rule'])
            self.assertIsNone(result['candidate'])
            trial.history=[{'role':'assistant','content':'x'*30000},{'role':'user','content':'latest'}]
            context=trial._context(2)
            self.assertIn('"omitted_history_messages": 1',json.dumps(context,ensure_ascii=False).replace('\\"','"'))
            self.assertIn('view_record',context[0]['content'])
            self.assertFalse((Path(folder)/'candidate.json').exists())

    def test_zero_cap_is_unlimited_and_positive_cap_is_diagnostic_only(self):
        actions=[{'action':'mission'} for _ in range(33)]+[
            {'action':'finish','candidate':{'runner_simple_family':'ballistic','acceleration':[0.,0.]},'claims':CLAIMS}]
        transport=ScriptedTransport(actions)
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            trial=LLMTrial(self.console(),transport,seed=0,out_dir=folder,max_turns=0)
            result=trial.run()
            self.assertEqual(result['status'],'submitted')
            self.assertEqual(result['model_turns'],34)
            self.assertIn('No extra model-turn cap',transport.requests[0][0][2]['content'])
        transport=ScriptedTransport([{'action':'mission'}]*2)
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            trial=LLMTrial(self.console(),transport,seed=0,out_dir=folder,max_turns=2)
            self.assertEqual(trial.run()['status'],'turn_limit_no_submission')
            self.assertEqual(len(transport.requests),2)
            self.assertIn('diagnostic-only turn cap',transport.requests[0][0][2]['content'])
        for invalid in [-1,True,1.5]:
            with self.assertRaises(ValueError):LLMTrial(self.console(),transport,seed=0,out_dir='unused',max_turns=invalid)

    def test_optional_weight_config_metadata_no_download(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(ROOT.resolve()))
            config={'model_type':'qwen','hidden_size':4096,'architectures':['ExampleForCausalLM'],
                    'private_access_token':'not-recorded','quantization_config':{'quant_method':'compressed-tensors'}}
            (Path(folder)/'config.json').write_text(json.dumps(config))
            info=weight_metadata(folder)
            self.assertFalse(info['loaded_weight_files_verified'])
            self.assertNotIn('not-recorded',json.dumps(info))
            self.assertEqual(info['config_summary']['hidden_size'],4096)
            (Path(folder)/'config.json').write_text(json.dumps({'model_type':'qwen','quantization_config':None}))
            self.assertEqual(weight_metadata(folder)['quantization_config'],{})


if __name__=='__main__':
    started=time.perf_counter()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(LLMRunnerProtocolTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'scope':'MOCK PROTOCOL TESTS ONLY; no real LLM, GPU, inference endpoint or model capability evaluated',
        'status':'pass' if result.wasSuccessful() else 'fail','test_methods':result.testsRun,
        'failures':[str(t) for t,_ in result.failures],'errors':[str(t) for t,_ in result.errors],
        'elapsed_seconds':time.perf_counter()-started,'actual_model_invocations':0}
    (ROOT/'checks/llm_trial_runner_protocol_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    sys.exit(0 if result.wasSuccessful() else 1)
