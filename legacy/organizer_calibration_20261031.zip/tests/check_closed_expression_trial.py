"""Offline protocol mocks only; no API, key, real model or capability claim."""
from pathlib import Path
import json
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from closed_expression_trial import ClosedExpressionTrial,EXPRESSION_SYSTEM_PROMPT
from expression_candidate import fit_expression
from trial_console import TrialConsole
from check_trial_console import configuration,Clock

CLAIMS={'dynamics_order':2,'hidden_matter':False,'time_dependence':False}
SPEC={'ax':'0','ay':'0','parameters':{}}


class Transport:
    capability_label='protocol_mock_only_not_closed_model'
    metadata={'mock':True,'served_model':'offline-only'}
    budget={'requests_used':0,'output_tokens_accounted':0}
    def __init__(self,actions):self.actions=list(actions);self.requests=[]
    def complete(self,messages,**kwargs):
        self.requests.append(json.loads(json.dumps(messages)))
        return {'model':'offline-only','choices':[{'message':{'content':json.dumps(self.actions.pop(0))}}],
                'usage':{'prompt_tokens':1,'completion_tokens':1}}


def launch():
    return {'action':'launch','t_launch':0.,'readout':[0.,.005,.01],
            'source_properties':{'p1':1.},
            'probes':[{'pos':[2.+.1*i,.2],'vel':[0.,0.],'properties':{'p2':1.}} for i in range(8)]}


class ExpressionLoopTests(unittest.TestCase):
    def console(self):return TrialConsole('Adam',.03,7,configuration(),clock=Clock())
    def test_anonymous_public_loop_and_no_predefined_fit(self):
        actions=[{'action':'fit'},launch(),{'action':'fit_expression','spec':SPEC},
                 {'action':'finish','candidate_id':'expr_1','claims':CLAIMS}]
        client=Transport(actions);console=self.console();calls=[]
        def observed(mission,transcript,spec):
            calls.append((mission,transcript,spec))
            text=json.dumps([mission,transcript])
            self.assertNotIn('Adam',text)
            for key in ['fixed_parameters','sigma_current','truths','claims_truth','global_V']:
                self.assertNotIn('"'+key+'"',text)
            out=fit_expression(mission,transcript,spec)
            out['claims']={'do_not_return':'test'}
            return out
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            trial=ClosedExpressionTrial(console,client,seed=4,out_dir=folder,expression_fit_fn=observed)
            result=trial.run()
            self.assertEqual(result['status'],'submitted')
            self.assertEqual(result['energy_used'],8)
            self.assertEqual(result['claims'],CLAIMS)
            self.assertIn('action_error',trial.events[0]['tool_response'])
            fit_output=trial.events[2]['tool_response']
            self.assertNotIn('suggested_claims',fit_output)
            self.assertNotIn('claims',fit_output)
            self.assertEqual(len(calls),1)
            self.assertEqual(console.mission()['world_id'],'Adam')
            self.assertTrue(trial.mission['world_id'].startswith('U-'))
            for file in ['public_records.json','public_console_transcript.json']:
                text=(Path(folder)/file).read_text(encoding='utf8')
                self.assertNotIn('Adam',text)
                self.assertIn(trial.opaque_world_id,text)
            sent=json.dumps(client.requests,ensure_ascii=False)
            self.assertNotIn('Adam',sent)
            self.assertNotIn('fit_public_transcript',sent)
            self.assertNotIn('"action":"fit"',EXPRESSION_SYSTEM_PROMPT)
            saved=json.loads((Path(folder)/'model_events.json').read_text(encoding='utf8'))
            self.assertEqual(saved[0]['model_request']['messages'],client.requests[0])
            meta=json.loads((Path(folder)/'run.json').read_text(encoding='utf8'))
            self.assertFalse(meta['contest_permitted'])
            self.assertEqual(meta['diagnostic_model_turn_cap'],16)
            self.assertFalse(meta['cap_is_contest_rule'])
    def test_direct_finish_spec_uses_public_fit_not_external_bindings(self):
        client=Transport([launch(),{'action':'finish','spec':SPEC,'claims':CLAIMS,'report':'offline test'}])
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            trial=ClosedExpressionTrial(self.console(),client,seed=1,out_dir=folder)
            result=trial.run()
            self.assertEqual(result['status'],'submitted')
            model=result['candidate'].to_dict()
            self.assertEqual(model['ax'],'0')
            self.assertEqual(model['ay'],'0')
            self.assertEqual(result['energy_used'],8)
    def test_diagnostic_turn_limit_no_fabricated_submission(self):
        client=Transport([{'action':'mission'}])
        with tempfile.TemporaryDirectory(dir=ROOT/'checks') as folder:
            trial=ClosedExpressionTrial(self.console(),client,seed=1,out_dir=folder,max_turns=1)
            result=trial.run()
            self.assertEqual(result['status'],'turn_limit_no_submission')
            self.assertIsNone(result['candidate'])
            self.assertFalse((Path(folder)/'candidate.json').exists())
    def test_prompt_has_no_worlds_or_physical_family_examples(self):
        for value in ('Adam','Lilith','Tabris','Sachiel','Ramiel','Matriel','Leliel','Arael','Lilin',
                      'Yukawa','Helmholtz','three_species','crossover_1to2','sin(2*pi*t/8'):
            self.assertNotIn(value,EXPRESSION_SYSTEM_PROMPT)
        self.assertNotIn('vx,vy',EXPRESSION_SYSTEM_PROMPT)
        self.assertIn('不支持依赖速度',EXPRESSION_SYSTEM_PROMPT)


if __name__=='__main__':
    started=time.perf_counter();suite=unittest.defaultTestLoader.loadTestsFromTestCase(ExpressionLoopTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'scope':__doc__,'status':'pass' if result.wasSuccessful() else 'fail','test_methods':result.testsRun,
            'failures':[str(t) for t,_ in result.failures],'errors':[str(t) for t,_ in result.errors],
            'elapsed_seconds':time.perf_counter()-started,'actual_network_calls':0}
    (ROOT/'checks/closed_expression_trial_protocol_tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
