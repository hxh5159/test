"""Regression tests for the exact draft score and feedback boundary."""
import copy
import sys
from pathlib import Path
import unittest
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from trial_evaluation import prediction_score,score_components,evaluate_model,public_feedback,WORLD_ORDER,noise_sigma

TRUTH={'dynamics_order':2,'hidden_matter':False,'time_dependence':False}


class EvaluationTests(unittest.TestCase):
    def test_saving_boundary_uses_prediction_only(self):
        self.assertEqual(score_components(40.,TRUTH,TRUTH,40)['saving'],3)
        self.assertEqual(score_components(np.nextafter(40.,0.),TRUTH,TRUTH,40)['saving'],0)
        wrong={'dynamics_order':1,'hidden_matter':True,'time_dependence':True}
        self.assertEqual(score_components(40.,wrong,TRUTH,40)['saving'],3)
        self.assertEqual(score_components(80.,TRUTH,TRUTH,100)['total'],95)

    def test_strict_claims_and_energy(self):
        integral_decimal={**TRUTH,'dynamics_order':2.0}
        self.assertEqual(score_components(80,integral_decimal,TRUTH,0)['total'],100)
        for claims in [{'dynamics_order':True,'hidden_matter':False,'time_dependence':False},
                       {'dynamics_order':2,'hidden_matter':0,'time_dependence':False}]:
            with self.assertRaises(ValueError):score_components(80,claims,TRUTH,0)
        for energy in [-1,101,float('nan')]:
            with self.assertRaises(ValueError):score_components(80,TRUTH,TRUTH,energy)

    def test_continuous_mapping(self):
        self.assertEqual(prediction_score(0,1),80)
        self.assertAlmostEqual(prediction_score(.1,1),40)
        self.assertGreater(prediction_score(.0001,1),prediction_score(.0002,1))
        self.assertEqual(prediction_score(float('inf'),1),0)

    def test_invalid_case_not_discarded(self):
        truth=np.array([[[1.,0.]],[[0.,1.]]])
        calibration={'world':'Adam','cases':[{'name':'ok','group':'a'},{'name':'bad','group':'b'}],
            'truths':[{'positions':truth.tolist()},{'positions':truth.tolist()}],'global_V':.5}
        class Invalid:
            def predict(self,case):return truth if case['name']=='ok' else np.full_like(truth,np.nan)
        result=evaluate_model(Invalid(),calibration,TRUTH,0)
        self.assertEqual(result['prediction'],0)
        self.assertEqual(result['total'],15)
        self.assertEqual(len(result['invalid_cases']),1)

    def test_perfect_and_feedback(self):
        truth=np.array([[[1.,0.]],[[0.,1.]]])
        calibration={'world':'Adam','cases':[{'name':'x','group':'a'}],
            'truths':[{'positions':truth.tolist()}],'global_V':.5}
        class Perfect:
            def predict(self,case):return truth
        score=evaluate_model(Perfect(),calibration,TRUTH,0)
        self.assertEqual(score['total'],100)
        feedback=public_feedback({w:copy.deepcopy(score) for w in WORLD_ORDER})
        self.assertEqual(set(feedback),{'total_score','world_scores'})
        self.assertEqual(feedback['total_score'],100)
        self.assertTrue(all(type(v) is float for v in feedback['world_scores'].values()))

    def test_noise_rule_independence(self):
        config={'launch_region':{'radius_min':2.,'radius_max':8.}}
        self.assertEqual(noise_sigma(config,{'global_V':1},'launch01'),noise_sigma(config,{'global_V':10000},'launch01'))
        self.assertNotEqual(noise_sigma(config,{'global_V':1},'legacy05'),noise_sigma(config,{'global_V':10000},'legacy05'))


if __name__=='__main__':unittest.main(verbosity=2)
