"""Score completed self-hosted LLM trials privately, after discovery ends."""
import argparse
import hashlib
import json
from pathlib import Path

from llm_trial_runner import candidate_from_artifact
from trial_catalog import calibrate_world
from trial_evaluation import evaluate_model,public_feedback,WORLD_ORDER


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    manifest=json.loads((args.run_dir/'manifest.json').read_text(encoding='utf8'))
    output={'scope':'organizer-only post-discovery evaluation; never feedback to discovery model',
            'model_metadata':manifest['model_metadata'],'noise_rule':manifest['noise_rule'],'seeds':{}}
    for seed in manifest['seeds']:
        results={}
        for world in manifest['worlds']:
            directory=args.run_dir/world/f'seed_{seed}'
            run=json.loads((directory/'run.json').read_text(encoding='utf8'))
            if run['status']=='running':raise ValueError('Discovery is still running; do not expose test feedback.')
            if run['status']!='submitted':
                results[world]={'world':world,'prediction':0.,'law':0.,'saving':0.,'total':0.,
                    'status':run['status'],'energy_used':run['budget']['energy_used']}
                continue
            artifact=json.loads((directory/'candidate.json').read_text(encoding='utf8'))
            claims=json.loads((directory/'claims.json').read_text(encoding='utf8'))
            scored=evaluate_model(candidate_from_artifact(artifact),calibrate_world(world),claims,run['budget']['energy_used'])
            scored['candidate_artifact_sha256']=hashlib.sha256((directory/'candidate.json').read_bytes()).hexdigest()
            results[world]=scored
        entry={'world_results':results,'complete_nine_world_submission':set(results)==set(WORLD_ORDER)}
        if entry['complete_nine_world_submission']:entry['public_feedback']=public_feedback(results)
        output['seeds'][str(seed)]=entry
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(args.out)


if __name__=='__main__':main()
