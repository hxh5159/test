指挥部物理规律发现带噪闭环试做包

本包包含九宇宙真实模拟器及命题配置，只供指挥部私下运行。不要放入公开Git、攻坚组镜像或参赛客户端。代码中的Python对象尚不构成正式进程/文件权限隔离。

已验证的部分
1. 九宇宙数值核心、24或32探针的私有验证案例、独立噪声/配额控制台、80/15/5计分原型。
2. 数值候选库基线只使用公开观测。它具有预置函数族先验并利用无噪速度，不能当成白名单LLM自主发现能力。
3. LLM运行器只做过协议mock测试，实际模型调用0；需要真正的自托管白名单模型服务才可开始能力验证。
4. 现行位置噪声为sigma=.01*L_launch，环带L_launch=sqrt((r_min^2+r_max^2)/2)。legacy05保留旧.05sqrt(validationV)作为对照。velocity仍无额外噪声。
5. 数值范围和案例是试做配置，正式冻结及公开粒度留待讨论；本包没有将内部案例发布给参赛者。

准备环境
把本包解压到指挥部拥有的单独私有目录；它不需要与公开仓库同目录，代码用脚本所在目录解析私有文件。建议使用独立CPU控制环境，避免改变模型服务器环境。
已测环境为Python3.13.5、NumPy2.1.3、SciPy1.15.3。所需依赖列在requirements-trials.txt。推理服务由用户已有环境提供，本包不下载任何模型。

在远端Linux运行数值试做（在解压目录执行）
python run_budget_trials.py --seeds 0  # 注意seeds多值使用逗号，如0,1,2
python run_budget_trials.py --seeds 0,1,2 --noise-rules legacy05,launch01 --out-dir experiments/numeric_ab_run1

通过自托管白名单模型进行真实工具闭环
先确认模型服务地址，例如本机http://127.0.0.1:8000/v1，并使用实际服务地址替换。运行器不会启动/下载/训练模型；不会回退到闭源外部API。
python llm_trial_runner.py --base-url http://127.0.0.1:8000/v1 --model Qwen3.6-35B-A3B-W8A8 --model-path /inspire/hdd/global_public/models/Qwen3.6-35B-A3B-W8A8 --worlds Adam Lilith Tabris Sachiel Ramiel Matriel Leliel Arael Lilin --seeds 0 1 2 --noise-rule launch01 --out-dir experiments/white_llm_launch01_run1

输出目录必须是新目录。默认不另设模型动作轮数上限，3600秒现实经过时间及实验配额仍由控制台约束；--max-turns正整数仅供诊断，不是正式规则。模型可控制实验、读取公开记录、使用显式数值候选库拟合工具并提交结构化候选；不执行模型生成的任意Python。因此它验证的是这种工具辅助系统，不能代替正式law.py任意程序智能体能力。正式提交接口没有被本包替换。

发现结束后的内部评分
python score_llm_trials.py --run-dir experiments/white_llm_launch01_run1 --out experiments/white_llm_launch01_run1/organizer_scores.json
评分文件包含内部小项、误差和诊断，不给发现模型或普通参赛者。实际对外反馈只能包含total_score和九个world_scores总分，不提前泄漏隐藏测试轨迹。

模型能力边界
必须记录实际模型ID、原权重/量化/训练版本、提示词、上下文/输出长度、token使用、耗时及配额。服务自报ID和config摘要不等于权重文件已验真。本轮依用户要求不运行远端模型，仅考虑能力差距，暂不计SFT/RL/工作流提升；本工具仅留作后续可选校准，不能用闭源或数值结果替代真实模型能力证据。

当前主要发现
这套已知候选族数值方法在80或88能量、1次observe下8界预言近80，1界近似73.46。精确速度可短时差分得到作用估计，使位置噪声几乎不影响该方法；这既不能证明噪声/难度已平衡，也不能推断弱开源模型必能完成。本轮不对模型或队伍得分作数字外推。一次observe返回值未被数值拟合器使用，不能据此断言20次背景额度足够。

文件说明
contest_simulator.py / contest_world_definitions.json：指挥部真实规律与数值核心。
trial_catalog.py：试做操作域、第一束光与私有固定验证案例。
trial_console.py：仅返回公开观测的计费/噪声接口。
blind_numeric_agent.py：不读取真值的受限候选库数值基线。
trial_evaluation.py：现行计分及内部诊断；分场景归一化仍非正式规则。
llm_trial_runner.py：真实自托管白名单模型动作循环。
score_llm_trials.py：发现完成后的独立内部评估。

实际情况截至2026年10月31日：私有数值实验已运行；白名单LLM推理和SFT/RL尚未运行；正式服务隔离/SDK/榜单系统尚未验收。

共享数值实现：rift_numerics目录须与contest_simulator.py同层保留。此包中的候选与真值共用数学积分循环；该目录不含九宇宙真实力场。

闭源API校准（指挥部内部，非正式白名单）
用户另行授权以其指定API进行真实模型校准。closed_proxy_client固定llmtoken.io，不改正式白名单客户端。closed_expression_trial只提供模型自主表达式和通用参数拟合，不使用原候选函数库。
表达工具暂不支持速度依赖和独立HIDDEN几何字段，fit要求至少max(6,2*参数数)个短轨迹，且每个有两个正readout<=0.1。这些是诊断工具限制，不是比赛规则。结果不能作为白名单模型能力或完整自建工具方案的上界。
在私有解压目录运行python closed_api_control.py，按隐藏输入提示输入自己的API key；不要把凭证写进脚本/命令行/Git。随后可输入JSON命令，例如：
{"command":"run_trial","tag":"my_private_trial_01","model":"gpt-6.1-sol","worlds":["Adam"],"max_turns":16,"max_tokens":3072,"max_output_tokens_per_world":24576,"workers":1,"seed":0}
模型名以中转站实际列表为准，服务可能将请求别名映射成其他模型；requested/returned标签都需要记录。动作和token限制仅控制校准费用，不是比赛规则；供应商usage仅自报，非独立货币账单。结束后输入{"command":"exit"}关闭持有内存凭证的进程。
