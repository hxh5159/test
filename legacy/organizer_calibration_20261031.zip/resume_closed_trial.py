"""PRIVATE one-shot recovery of a transport-failed closed calibration.

No score, scientific truth table or validation dataset is read. Reconstruction
uses only saved public console requests/results, model events, run metadata and
the original launch01 manifest. No network occurs until resume_trial.run()
continues the original model loop. Old files are never written.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
from pathlib import Path
import time

from closed_proxy_client import ClosedProxyClient
from closed_expression_trial import ClosedExpressionTrial
from expression_candidate import ExpressionCandidate
from trial_console import TrialConsole
from llm_trial_runner import WORLDS


def _load(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def _comparable(value):
    if isinstance(value,dict):
        return {k:_comparable(v) for k,v in value.items() if k not in ('budget','world_id','universe_id')}
    if isinstance(value,list):return [_comparable(v) for v in value]
    return value


def prepare_resume(source_dir, output_dir):
    """Rebuild and verify public state; no credential/network is involved."""
    source=Path(source_dir).resolve();destination=Path(output_dir).resolve()
    if source==destination:raise ValueError('Resume output must differ from the original directory.')
    if destination.exists() and any(destination.iterdir()):raise FileExistsError('Resume output must be new or empty.')
    run_path=source/'run.json'
    run=_load(run_path)
    if run.get('status')!='model_transport_or_context_error' or run.get('submission') is not None:
        raise ValueError('Only an unsubmitted transport/context-failed run may be resumed.')
    world=source.name
    if world not in WORLDS:raise ValueError('Source directory name must identify the organizer world.')
    manifest=_load(source.parent/'manifest.json')
    if manifest.get('noise_rule')!='launch01':
        raise ValueError('This recovery supports only the recorded launch01 noise policy.')
    old_events=_load(source/'model_events.json')
    old_records=_load(source/'public_records.json')
    old_transcript=_load(source/'public_console_transcript.json')
    if not old_transcript or old_transcript[0].get('operation')!='mission':
        raise ValueError('Missing original mission record.')
    mission=old_transcript[0]['response']
    initial=mission['first_light']
    config={key:copy.deepcopy(mission[key]) for key in ('launch_region','initial_speed_max','maximum_physical_time','maximum_single_trajectory_duration')}
    config.update(copy.deepcopy(mission['limits']))
    config['source_properties']=copy.deepcopy(mission['controls']['source_properties'])
    config['probe_properties']=copy.deepcopy(mission['controls']['probe_properties'])
    config['first_light']={key:copy.deepcopy(initial[key]) for key in ('probes','t_launch','readout','source_properties')}
    limits=run['model_metadata']['billing_caps']
    old_api=run['api_budget']
    requests_used=int(old_api['requests_used']);tokens_used=int(old_api['output_tokens_accounted'])
    remaining_requests=int(limits['max_requests'])-requests_used
    remaining_tokens=int(limits['max_output_tokens_total'])-tokens_used
    remaining_turns=int(run['diagnostic_model_turn_cap'])-int(run['model_turns'])
    if min(remaining_requests,remaining_tokens,remaining_turns)<=0:
        raise RuntimeError('The original calibration spending/action cap has no remaining allowance.')
    deadline_epoch=run_path.stat().st_mtime+float(run['budget']['wall_clock_remaining_seconds'])
    if time.time()>=deadline_epoch:raise TimeoutError('Original3600s exploration window has expired during the pause.')
    region=config['launch_region']
    sigma=.01*math.sqrt((region['radius_min']**2+region['radius_max']**2)/2)
    console=TrialConsole(world,sigma,int(run['seed']),config)
    for index,record in enumerate(old_transcript):
        op,request=record['operation'],record['request']
        if op=='mission':actual=console.mission()
        elif op=='observe':actual=console.observe(request['times'])
        elif op=='launch':actual=console.launch(**request)
        elif op=='archive':actual=console.archive()
        else:raise ValueError('Unsupported saved public console operation.')
        if _comparable(actual)!=_comparable(record['response']):
            raise RuntimeError(f'Public-data replay mismatch at console record{index}; recovery aborted before network.')
    for key in ('energy_used','energy_remaining','observe_used','observe_remaining'):
        if console.budget[key]!=run['budget'][key]:raise RuntimeError('Replayed experiment ledger differs from the original.')
    remaining_wall=deadline_epoch-time.time()
    if remaining_wall<=0:raise TimeoutError('Original exploration deadline passed during replay.')
    # Preserve the original deadline; pause and reconstruction both cost time.
    console._started_at=time.monotonic()-(console._wall_seconds-remaining_wall)
    history=[];fits={}
    for event in old_events:
        response=event.get('model_response')
        if not isinstance(response,dict) or 'tool_response' not in event:continue
        try:content=response['choices'][0]['message']['content']
        except (KeyError,IndexError,TypeError):continue
        if not isinstance(content,str):continue
        history.extend([{'role':'assistant','content':content},
            {'role':'user','content':'工具结果：\n'+json.dumps(event['tool_response'],ensure_ascii=False)}])
        result=event['tool_response']
        if isinstance(result,dict) and isinstance(result.get('candidate_id'),str) and isinstance(result.get('candidate'),dict):
            fits[result['candidate_id']]=ExpressionCandidate.from_dict(result['candidate'])
    successful=[e for e in old_events if isinstance(e.get('model_request'),dict)]
    sampling=successful[-1]['model_request'] if successful else {}
    files=('run.json','model_events.json','public_records.json','public_console_transcript.json')
    info={'source_dir':str(source),'source_sha256':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files},
        'opaque_world_id':run['world_id'],'seed':run['seed'],'replayed_console_records':len(old_transcript),
        'public_data_replay_exact_excluding_budget_and_world_id':True,
        'original_action_cap':run['diagnostic_model_turn_cap'],'original_request_cap':limits['max_requests'],
        'original_output_token_cap':limits['max_output_tokens_total'],'original_request_offset':requests_used,
        'original_action_offset':run['model_turns'],'original_accounted_output_tokens':tokens_used,
        'remaining_requests':remaining_requests,'remaining_output_tokens':remaining_tokens,'remaining_actions':remaining_turns,
        'restored_history_messages':len(history),'restored_candidate_ids':list(fits),
        'original_deadline_epoch':deadline_epoch,'wall_seconds_remaining_after_replay':remaining_wall,
        'pause_deducted_seconds':max(0,time.time()-run_path.stat().st_mtime),
        'resume_turn_numbering':'new event.turn is local; overall action offset is recorded above',
        'score_or_validation_read':False,'automatic_retry_count':0,'cap_is_contest_rule':False}
    return {'console':console,'run':run,'records':old_records,'history':history,'fits':fits,'metadata':info,
            'sampling':sampling,'output_dir':destination}


def resume_trial(source_dir, output_dir, api_key, timeout=300):
    state=prepare_resume(source_dir,output_dir)
    run,info=state['run'],state['metadata']
    client=ClosedProxyClient(run['model_metadata']['requested_model'],api_key=api_key,
        api_style=run['model_metadata'].get('api_style','chat'),timeout=timeout,
        max_requests=info['remaining_requests'],max_output_tokens_total=info['remaining_output_tokens'],
        chat_token_field='max_completion_tokens',send_seed=False,send_temperature=False)
    client.discover(fetch_models=False)  # Metadata only, no billable discovery request.
    client.metadata['resume']=copy.deepcopy(info)
    trial=ClosedExpressionTrial(state['console'],client,seed=int(run['seed']),out_dir=state['output_dir'],
        max_turns=info['remaining_actions'],max_tokens=int(state['sampling'].get('max_tokens',3072)),
        context_chars=90000,temperature=float(state['sampling'].get('temperature',.3)))
    trial.opaque_world_id=info['opaque_world_id']
    trial.records=copy.deepcopy(state['records'])
    trial.history=copy.deepcopy(state['history'])
    trial.fits=state['fits']
    trial.mission=copy.deepcopy(state['records'][0]['data'])
    trial.history.append({'role':'user','content':json.dumps({'transport_resume_notice':{
        'previous_request_count':info['original_request_offset'],'remaining_diagnostic_actions':info['remaining_actions'],
        'same_experiments_and_candidates_restored':True,'original_wall_clock_deadline_preserved':True,
        'note':'Previous transport call failed. Continue from existing public data; no scoring feedback is supplied.'}},ensure_ascii=False)})
    discovery=trial.run()
    metadata={**info,'continuation_api_budget':client.budget,
        'total_model_actions_accounted':info['original_action_offset']+discovery['model_turns'],
        'total_requests_accounted':info['original_request_offset']+client.budget['requests_used'],
        'total_output_tokens_accounted':info['original_accounted_output_tokens']+client.budget['output_tokens_accounted'],
        'continuation_request_log':client.request_log,'continuation_model_metadata':client.metadata}
    for name,digest in info['source_sha256'].items():
        if hashlib.sha256((Path(source_dir)/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Original evidence changed during recovery.')
    (state['output_dir']/'resume_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    return {'discovery':discovery,'metadata':metadata}


__all__=['resume_trial','prepare_resume']
