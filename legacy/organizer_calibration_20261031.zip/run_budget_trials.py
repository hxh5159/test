"""Run reproducible noisy budget trials without exposing truth to the learner.

The built-in learner is a numerical hypothesis-library baseline, not an LLM.
It must not be reported as white-listed model capability or an official event.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time
import traceback

from trial_catalog import WORLDS,trial_config,calibrate_world
from trial_console import TrialConsole
from trial_evaluation import evaluate_model,noise_sigma,public_feedback

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worlds',default=','.join(WORLDS))
    parser.add_argument('--seeds',default='0')
    parser.add_argument('--noise-rules',default='legacy05,launch01')
    parser.add_argument('--out-dir',type=Path,default=ROOT/'checks/budget_trials')
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    from blind_numeric_agent import run
    source_hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        for name in ('blind_numeric_agent.py','trial_console.py','trial_catalog.py','contest_simulator.py',
                     'contest_world_definitions.json','trial_evaluation.py')}
    worlds=args.worlds.split(',')
    if any(w not in WORLDS for w in worlds):parser.error('Unknown world.')
    seeds=[int(v) for v in args.seeds.split(',')]
    rules=args.noise_rules.split(',')
    args.out_dir.mkdir(parents=True,exist_ok=True)
    summary={'scope':'private numerical-library discovery trials; no real LLM or training run',
             'model_capability_established':False,'source_hashes':source_hashes,'runs':[]}
    for rule in rules:
        for seed in seeds:
            complete={}
            for world in worlds:
                path=args.out_dir/f'{rule}_seed{seed}_{world}.json'
                if args.resume and path.exists():
                    record=json.loads(path.read_text(encoding='utf8'))
                else:
                    print(f'START {rule} seed={seed} {world}',flush=True)
                    started=time.perf_counter()
                    calibration=calibrate_world(world)
                    config=trial_config(world)
                    sigma=noise_sigma(config,calibration,rule)
                    console=TrialConsole(world,sigma,seed,config)
                    try:
                        learned=run(console)
                        candidate=learned['candidate']
                        claims=learned['claims']
                        mission=console.mission()
                        budget=mission['budget']
                        energy=budget['energy_used']
                        record={'world':world,'seed':seed,'noise_rule':rule,'sigma_organizer_only':sigma,
                            'status':'completed','scores':evaluate_model(candidate,calibration,claims,energy),
                            'budget':budget,'model':candidate.to_dict(),'diagnostics':learned.get('diagnostics',{}),
                            'source_hashes':source_hashes,
                            'public_transcript':console.public_transcript,
                            'elapsed_seconds':time.perf_counter()-started,
                            'calibration_fingerprint':calibration.get('fingerprint',calibration.get('source_sha256'))}
                    except Exception as exc:
                        record={'world':world,'seed':seed,'noise_rule':rule,'status':'failed',
                            'source_hashes':source_hashes,
                            'error':f'{type(exc).__name__}: {exc}','organizer_traceback':traceback.format_exc(),
                            'elapsed_seconds':time.perf_counter()-started,'public_transcript':console.public_transcript}
                    path.write_text(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
                summary['runs'].append({'world':world,'seed':seed,'noise_rule':rule,'status':record['status'],
                    'file':str(path),'scores':record.get('scores'),'budget':record.get('budget'),
                    'elapsed_seconds':record.get('elapsed_seconds')})
                if record['status']=='completed':
                    complete[world]=record['scores']
                    print('DONE',rule,seed,world,{k:record['scores'][k] for k in ('prediction','law','saving','total')},record['budget'],flush=True)
                else:print('FAILED',rule,seed,world,record.get('error'),flush=True)
            if len(complete)==9:
                (args.out_dir/f'{rule}_seed{seed}_public_feedback.json').write_text(
                    json.dumps(public_feedback(complete),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
            (args.out_dir/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print('Report',args.out_dir/'summary.json',flush=True)


if __name__=='__main__':main()
