"""Private, operator-driven llmtoken calibration process.

The key is entered through a hidden console prompt and kept in process memory.
Only the explicitly requested llmtoken.io host is contacted. Credentials are
never written to the project, request logs, command line or output records.
"""
from __future__ import annotations
import getpass
import json
from pathlib import Path
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

ROOT = Path(__file__).resolve().parent


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def main():
    key = getpass.getpass('API credential (hidden; memory only): ')
    if not key or any(ch.isspace() for ch in key):
        print(json.dumps({'status': 'invalid_credential_format'}), flush=True)
        return
    opener = build_opener(NoRedirect())

    def clean(value):
        if isinstance(value, str):
            return value.replace(key, '[REDACTED]')
        if isinstance(value, dict):
            return {k: clean(v) for k, v in value.items()}
        if isinstance(value, list):
            return [clean(v) for v in value]
        return value

    def emit(value):
        print(json.dumps(clean(value), ensure_ascii=True, allow_nan=False), flush=True)

    def request(suffix, body=None):
        assert suffix in ('models', 'chat/completions', 'responses')
        raw = None if body is None else json.dumps(body).encode('utf-8')
        req = Request('https://llmtoken.io/v1/'+suffix, data=raw,
                      headers={'Authorization': 'Bearer '+key, 'Content-Type': 'application/json',
                               'Accept': 'application/json'}, method='GET' if raw is None else 'POST')
        began = time.monotonic()
        try:
            with opener.open(req, timeout=150) as response:
                payload = response.read(4*1024*1024+1)
                if len(payload) > 4*1024*1024:
                    raise RuntimeError('Bounded response limit exceeded')
                data = json.loads(payload)
                return data, time.monotonic()-began
        except HTTPError as exc:
            # Never print request headers or raw exception representations.
            text = exc.read(2048).decode('utf-8', errors='replace')
            raise RuntimeError(f'HTTP {exc.code}: '+clean(text)) from None
        except URLError as exc:
            raise RuntimeError('Transport error: '+type(exc.reason).__name__) from None

    try:
        data, elapsed = request('models')
        ids = [row.get('id') for row in data.get('data', []) if isinstance(row, dict)]
        emit({'operation': 'discover', 'model_ids': ids, 'elapsed_seconds': elapsed,
              'identity_note': 'gateway-reported aliases; not verification of underlying weights'})
    except Exception as exc:
        emit({'operation': 'discover', 'error': str(exc)})
    emit({'status': 'ready', 'commands': ['probe_chat', 'probe_responses', 'run_trial', 'resume_trial', 'exit']})
    while True:
        try:
            line = input()
        except EOFError:
            break
        try:
            command = json.loads(line)
            operation = command.get('command')
            if operation == 'exit':
                emit({'status': 'closed'})
                return
            if operation in ('probe_chat', 'probe_responses'):
                model = command['model']
                if operation == 'probe_chat':
                    body = {'model': model, 'messages': [{'role': 'user', 'content': 'Reply only with the JSON object {"ok":true}.'}],
                            'max_completion_tokens': 128}
                    response, elapsed = request('chat/completions', body)
                else:
                    body = {'model': model, 'input': 'Reply only with the JSON object {"ok":true}.', 'max_output_tokens': 128,
                            'store': False}
                    response, elapsed = request('responses', body)
                # Connectivity probes contain no contest data.
                emit({'operation': operation, 'response': response, 'elapsed_seconds': elapsed})
            elif operation == 'run_trial':
                from run_closed_calibration import run_trial
                emit(run_trial(command, api_key=key))
            elif operation == 'resume_trial':
                from run_closed_resume import run_resume
                for field in ('source_tag', 'tag', 'world'):
                    if not isinstance(command.get(field), str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', command[field]):
                        raise ValueError('Invalid private resume identifier')
                emit(run_resume(command, api_key=key))
            else:
                raise ValueError('Unsupported command')
        except Exception as exc:
            emit({'operation': 'command_error', 'error_type': type(exc).__name__, 'message': str(exc)[:2000]})


if __name__ == '__main__':
    main()
