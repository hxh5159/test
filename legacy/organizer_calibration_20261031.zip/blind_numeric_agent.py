"""A numerical discovery diagnostic using only public experiment records.

This is NOT an LLM, a claim about white-listed model capability, or an
unconstrained scientific-discovery system.  It compares an explicitly supplied
generic hypothesis library against observations.  It never imports the true
simulator, world definitions, a validation catalogue, or branches on world ID.
Short trajectories exploit the current rule that velocities have no added
noise.  That important information advantage is reported in diagnostics.
"""
from __future__ import annotations

import copy
import math
import os
from pathlib import Path
import sys
import time
import numpy as np
from scipy.optimize import least_squares

try:
    from rift_numerics.rollout import rollout as _shared_rollout, sample_indices as _sample_indices
except ModuleNotFoundError as exc:
    if exc.name != 'rift_numerics':
        raise
    configured=os.environ.get('RIFT_PUBLIC_ROOT')
    public_root=(Path(configured).expanduser().resolve() if configured
                 else Path(__file__).resolve().parent.parent/'DiscoverPhysics')
    sys.path.insert(0,str(public_root))
    from rift_numerics.rollout import rollout as _shared_rollout, sample_indices as _sample_indices

EPS = .05
DT = .005
SCHEMA = 'public-observation-numerical-candidate-1.0.0'


def _geometry(x, centers):
    delta = np.asarray(x)[:, None, :] - np.asarray(centers)[None, :, :]
    r = np.linalg.norm(delta, axis=-1)
    rho = np.sqrt(r*r + EPS*EPS)
    u = np.divide(delta, r[..., None], out=np.zeros_like(delta), where=r[..., None] > 0)
    return rho, u


def _radial(family, rho, params):
    if family == 'power':
        return rho ** -params['power']
    if family == 'screen':
        return np.exp(-rho / params['length']) / rho
    if family == 'crossover_1to2':
        return 1 / (rho*np.sqrt(1+(rho/params['length'])**2))
    if family == 'crossover_2to1':
        return np.sqrt(1+(rho/params['length'])**2) / rho**2
    raise ValueError('Unknown hypothesis family')


class Candidate:
    """Serializable pure-math prediction, with no reference to a console."""
    def __init__(self, model):
        self.model = copy.deepcopy(model)

    def to_dict(self):
        return copy.deepcopy(self.model)

    @classmethod
    def from_dict(cls, model):
        if model.get('schema_version') != SCHEMA:
            raise ValueError('Unsupported numerical candidate schema')
        return cls(model)

    def acceleration(self, t, positions, *, source_properties=None, probe_properties=None,
                     center_position=None):
        m = self.model
        x = np.asarray(positions, dtype=np.float64)
        p = m['parameters']
        center = np.asarray(m['center'] if center_position is None else center_position, dtype=float)
        if m['background'] == 'comoving' and center_position is None:
            center = center + np.asarray(m['center_velocity'])*t + .5*np.asarray(p['constant'])*t*t
        rho, unit = _geometry(x, [center])
        if m['family'] == 'multi_power':
            centers = np.vstack([center, np.asarray(m['hidden_centers']).reshape((-1,2))])
            weights = np.r_[1., m['hidden_weights']]
            all_rho, all_unit = _geometry(x, centers)
            force = -p['strength'] * np.sum((weights[None,:]/all_rho)[...,None]*all_unit,axis=1)
        else:
            amplitude = p['strength'] * _radial(m['family'], rho[:,0], p)
            if m.get('time_dependence'):
                amplitude = amplitude * (1+p['modulation']*np.sin(p['frequency']*float(t)+p['phase']))
            force = -amplitude[:,None]*unit[:,0]
        source = source_properties or {}
        scale = np.ones(len(x))
        skey = m.get('source_key')
        if skey:
            scale *= (np.asarray(source[skey],dtype=float)/m['source_default']) ** m['source_exponent']
        key = m['probe_key']
        prop = probe_properties if isinstance(probe_properties,list) else [probe_properties]*len(x)
        vals = np.array([q[key] for q in prop],dtype=float)
        scale *= (vals/m['probe_default']) ** m['probe_exponent']
        force *= scale[:,None]
        if m['background'] in ('constant','comoving'):
            force += np.asarray(p['constant'])
        elif m['background'] == 'linear':
            force += p['linear']*(x-np.asarray(m['reference_center']))
        return force

    def predict(self, case):
        probes = case['probes']
        x = np.array([q['pos'] for q in probes],dtype=float)
        v = np.array([q['vel'] for q in probes],dtype=float)
        readout = np.asarray(case['readout'],dtype=float)
        ticks = _sample_indices(readout)
        source = case.get('source_properties',{})
        props = [q['properties'] for q in probes]
        start = float(case.get('t_launch',0))
        duration=float(readout[-1])
        if self.model['background']!='comoving':
            history=_shared_rollout(
                lambda t,state:self.acceleration(t,state,source_properties=source,probe_properties=props),
                x,v,t_launch=start,duration=duration)
            return history['positions'][ticks]
        # Advance the inferred center in the SAME discrete drift/kick state as
        # the probes. An analytic center remains useful for instantaneous model
        # fitting, but is not substituted into prediction's internal substeps.
        constant=np.asarray(self.model['parameters']['constant'],dtype=float)
        center0=np.asarray(self.model['center'],dtype=float)[None]
        velocity0=np.asarray(self.model['center_velocity'],dtype=float)[None]
        center_history=_shared_rollout(lambda t,state:np.broadcast_to(constant,state.shape),
            center0,velocity0,t_launch=0.,duration=start)
        positions=np.vstack([center_history['positions'][-1],x])
        velocities=np.vstack([center_history['velocities'][-1],v])
        def acceleration(t,state):
            result=np.empty_like(state)
            result[0]=constant
            result[1:]=self.acceleration(t,state[1:],source_properties=source,
                                         probe_properties=props,center_position=state[0])
            return result
        history=_shared_rollout(acceleration,positions,velocities,t_launch=start,duration=duration)
        return history['positions'][ticks,1:]


def _catalog(mission):
    c=mission['controls']
    source=c['source_properties']
    probes=c['probe_properties']
    if len(probes)!=1 or len(source)>1:
        raise ValueError('This diagnostic handles one public probe scalar and zero/one source scalar')
    pkey=next(iter(probes))
    skey=next(iter(source),None)
    return skey,pkey


def _short_accelerations(record, *, quality=1.):
    offsets=np.asarray(record.get('readout',[]),dtype=float)
    positive=np.flatnonzero((offsets>0)&(offsets<=.10000001))
    if len(positive)<2:
        return []
    positive=positive[:4]
    h=offsets[positive]
    design=np.column_stack([h,h*h])
    velocities=np.asarray(record['velocities'],dtype=float)
    result=[]
    for i,probe in enumerate(record['probes']):
        dv=velocities[positive,i]-np.asarray(probe['vel'])
        fit=np.linalg.lstsq(design,dv,rcond=None)[0]
        # Confidence is numerical-truncation weighting, not observation-noise GT.
        weight=quality*min(1.,(.01/max(h))**2)
        result.append({'position':probe['pos'],'velocity':probe['vel'],
            'time':float(record['t_launch']),'properties':probe['properties'],
            'source_properties':record.get('source_properties',{}),
            'acceleration':fit[0].tolist(),'weight':weight,
            'offset_max':float(max(h))})
    return result


def _observation_records(mission,transcript):
    records=[]
    if mission.get('first_light'):
        records.append((mission['first_light'],.1))
    seen=set()
    for entry in transcript:
        if entry.get('operation')!='launch':
            continue
        response=entry['response']
        key=response.get('experiment_id',id(response))
        if key not in seen:
            seen.add(key)
            records.append((response,1.))
    return records


def _snap_exponent(value):
    return int(min((-1,0,1),key=lambda q:abs(q-value)))


def _infer_scaling(mission,samples):
    skey,pkey=_catalog(mission)
    pd=float(mission['controls']['probe_properties'][pkey]['default'])
    sd=float(mission['controls']['source_properties'][skey]['default']) if skey else 1.
    exponents={pkey:[],skey:[]} if skey else {pkey:[]}
    # Only exact same experimental geometry/time and the other attribute fixed.
    for i,a in enumerate(samples):
        for b in samples[:i]:
            if a['time']!=b['time'] or not np.array_equal(a['position'],b['position']):
                continue
            aa=np.asarray(a['acceleration']); bb=np.asarray(b['acceleration'])
            if np.dot(bb,bb)<1e-16:
                continue
            ratio=float(np.dot(aa,bb)/np.dot(bb,bb))
            if ratio<=0:
                continue
            ap=float(a['properties'][pkey]); bp=float(b['properties'][pkey])
            ass=float(a['source_properties'].get(skey,sd)); bss=float(b['source_properties'].get(skey,sd))
            if ap!=bp and ass==bss and ap>0 and bp>0:
                exponents[pkey].append(math.log(ratio)/math.log(ap/bp))
            if skey and ass!=bss and ap==bp and ass>0 and bss>0:
                exponents[skey].append(math.log(ratio)/math.log(ass/bss))
    pe=_snap_exponent(np.median(exponents[pkey])) if exponents[pkey] else 0
    se=_snap_exponent(np.median(exponents[skey])) if skey and exponents[skey] else 1
    return {'probe_key':pkey,'probe_default':pd,'probe_exponent':pe,
            'source_key':skey,'source_default':sd,'source_exponent':se,
            'scaling_diagnostics':{str(k):v for k,v in exponents.items()}}


def fit_public_transcript(mission,transcript, *, include_hidden=True):
    """Fit explicit generic hypotheses to already acquired public data only.

    No experiments are requested here. The selected family is judged using
    an internal acceleration holdout from the acquired records, never official
    validation truth.  Scientific claims are model-derived hypotheses.
    """
    started=time.perf_counter()
    samples=[]
    for record,quality in _observation_records(mission,transcript):
        samples.extend(_short_accelerations(record,quality=quality))
    if len(samples)<12:
        raise ValueError('Need at least 12 short-trajectory probes with two positive readouts <=0.1')
    scaling=_infer_scaling(mission,samples)
    x=np.asarray([q['position'] for q in samples],dtype=float)
    times=np.asarray([q['time'] for q in samples],dtype=float)
    y=np.asarray([q['acceleration'] for q in samples],dtype=float)
    confidence=np.asarray([q['weight'] for q in samples],dtype=float)
    pvals=np.asarray([q['properties'][scaling['probe_key']] for q in samples],dtype=float)
    attr=(pvals/scaling['probe_default'])**scaling['probe_exponent']
    if scaling['source_key']:
        svals=np.asarray([q['source_properties'][scaling['source_key']] for q in samples],dtype=float)
        attr*= (svals/scaling['source_default'])**scaling['source_exponent']
    norm=np.linalg.norm(y,axis=1)
    weights=np.sqrt(confidence)/np.maximum(norm,.025*np.median(norm)+1e-8)
    indices=np.arange(len(samples))
    train=indices%5!=2
    holdout=~train
    if holdout.sum()<3:
        holdout=train.copy()
    init=mission['background_initial_state']
    all_centers=np.asarray(init['positions'],dtype=float)
    all_vel=np.asarray(init['velocities'],dtype=float)
    ref=np.asarray(mission['launch_region']['center'],dtype=float)
    # Every visible initial object is a candidate source; names/counts are not used.
    center_candidates=[]
    for i,c in enumerate(all_centers):
        rho,u=_geometry(x,[c])
        projection=-np.sum(y*u[:,0],axis=1)
        radial=-projection[:,None]*u[:,0]
        residual=np.mean(((y-radial)*weights[:,None])**2)
        center_candidates.append((float(residual),i))
    center_candidates=sorted(center_candidates)[:3]
    fits=[]

    def make_model(family,background,center_idx):
        model={'schema_version':SCHEMA,'family':family,'background':background,
            'center':all_centers[center_idx].tolist(),'center_velocity':all_vel[center_idx].tolist(),
            'reference_center':ref.tolist(),'time_dependence':False,'parameters':{},
            **{k:v for k,v in scaling.items() if k!='scaling_diagnostics'}}
        return model

    def eval_model(model):
        cand=Candidate(model)
        # Batched by launch time and known attributes; no future true states used.
        result=np.empty_like(y)
        for i,q in enumerate(samples):
            result[i]=cand.acceleration(times[i],x[i:i+1],source_properties=q['source_properties'],
                probe_properties=[q['properties']])[0]
        return result

    def add_fit(model, nparam, tag, optimizer=None):
        pred=eval_model(model)
        per=np.sum(((pred-y)*weights[:,None])**2,axis=1)
        held=float(np.mean(per[holdout])); training=float(np.mean(per[train]))
        fits.append({'model':copy.deepcopy(model),'holdout_loss':held,'training_loss':training,
                     'selection_loss':held+1e-6*nparam,'parameter_count':nparam,'tag':tag,
                     'optimizer_success':bool(optimizer.success) if optimizer is not None else True})

    def fit_one(family,background,center_idx):
        model=make_model(family,background,center_idx)
        center=np.asarray(model['center'])
        rho,u=_geometry(x,[center])
        projected=-np.sum(y*u[:,0],axis=1)/np.maximum(attr,1e-12)
        positive=(projected>0)&train
        pp=1.
        k0=float(np.median(np.maximum(projected,1e-8)*rho[:,0]))
        if positive.sum()>3:
            line=np.polyfit(np.log(rho[positive,0]),np.log(projected[positive]),1)
            pp=float(np.clip(-line[0],.2,3.5))
            if family=='power':k0=float(np.exp(np.clip(line[1],-20,20)))
        initv=[math.log(max(k0,1e-6)),pp if family=='power' else math.log(max(np.median(rho),.1))]
        lower=[-15.,.05 if family=='power' else math.log(.05)]
        upper=[15.,4. if family=='power' else math.log(200.)]
        if background in ('constant','comoving'):
            guess=np.median(y,axis=0)
            initv+=guess.tolist();lower +=[-10.,-10.];upper +=[10.,10.]
        elif background=='linear':
            initv+=[0.];lower +=[-2.];upper +=[2.]
        def unpack(vec):
            p={'strength':float(np.exp(vec[0]))}
            p['power' if family=='power' else 'length']=float(vec[1] if family=='power' else np.exp(vec[1]))
            if background in ('constant','comoving'):p['constant']=[float(vec[2]),float(vec[3])]
            elif background=='linear':p['linear']=float(vec[2])
            model['parameters']=p
            return model
        def residual(vec):
            m=unpack(vec);p=m['parameters']
            centers=np.broadcast_to(center,(len(x),2)).copy()
            if background=='comoving':
                centers+=times[:,None]*np.asarray(m['center_velocity'])+.5*times[:,None]**2*np.asarray(p['constant'])
            delta=x-centers;r=np.linalg.norm(delta,axis=1);rho=np.sqrt(r*r+EPS*EPS)
            unit=np.divide(delta,r[:,None],out=np.zeros_like(delta),where=r[:,None]>0)
            prediction=-(p['strength']*_radial(family,rho,p)*attr)[:,None]*unit
            if background in ('constant','comoving'):prediction+=p['constant']
            elif background=='linear':prediction+=p['linear']*(x-ref)
            return ((prediction-y)*weights[:,None])[train].ravel()
        initv=np.clip(initv,np.asarray(lower)+1e-9,np.asarray(upper)-1e-9)
        fitted=least_squares(residual,initv,bounds=(lower,upper),max_nfev=180,ftol=1e-9,xtol=1e-9,gtol=1e-9)
        unpack(fitted.x)
        add_fit(model,len(initv),family+'/'+background,fitted)

    families=('power','screen','crossover_1to2','crossover_2to1')
    for _,center_idx in center_candidates:
        for family in families:
            fit_one(family,'none',center_idx)
        for background in ('constant','linear','comoving'):
            fit_one('power',background,center_idx)

    # Test positive sinusoidal modulation, using all acquisition times.
    # Linear frequency scan supplies starts; joint refinement still fits only public data.
    static=sorted([q for q in fits if q['model']['background']=='none'],key=lambda q:q['selection_loss'])
    if len(np.unique(times[confidence>.5]))>=6:
        for base in static[:3]:
            model=copy.deepcopy(base['model']);model['time_dependence']=True
            rho,u=_geometry(x,[model['center']]); radial=_radial(model['family'],rho[:,0],model['parameters'])*attr
            coefficient=-np.sum(y*u[:,0],axis=1)/np.maximum(radial,1e-12)
            tspan=max(float(times.max()-times.min()),1.)
            frequencies=np.linspace(2*np.pi/(2*tspan),2*np.pi,1200)
            candidates=[]
            for freq in frequencies:
                design=np.column_stack([np.ones(len(times)),np.sin(freq*times),np.cos(freq*times)])
                v=np.linalg.lstsq(design[train],coefficient[train],rcond=None)[0]
                if v[0]<=0 or np.linalg.norm(v[1:])>=.99*v[0]:continue
                loss=float(np.mean((design[train]@v-coefficient[train])**2))
                candidates.append((loss,freq,v))
            best_starts=[]
            for item in sorted(candidates,key=lambda q:q[0]):
                if all(abs(item[1]-q[1])>.1 for q in best_starts):best_starts.append(item)
                if len(best_starts)==3:break
            for _,freq,coef in best_starts:
                shape0=model['parameters'].get('power',math.log(model['parameters'].get('length',1.)))
                initv=[math.log(coef[0]),shape0,float(np.linalg.norm(coef[1:])/coef[0]),freq,float(math.atan2(coef[2],coef[1]))]
                lower=[-15.,.05 if model['family']=='power' else math.log(.05),0.,2*np.pi/(2*tspan),-4*np.pi]
                upper=[15.,4. if model['family']=='power' else math.log(200.),.99,2*np.pi,4*np.pi]
                def unpack(vec):
                    p={'strength':float(np.exp(vec[0])),
                       'power' if model['family']=='power' else 'length':float(vec[1] if model['family']=='power' else np.exp(vec[1])),
                       'modulation':float(vec[2]),'frequency':float(vec[3]),'phase':float(vec[4])}
                    model['parameters']=p
                    return p
                def residual(vec):
                    p=unpack(vec)
                    amplitude=p['strength']*_radial(model['family'],rho[:,0],p)*attr*(1+p['modulation']*np.sin(p['frequency']*times+p['phase']))
                    prediction=-amplitude[:,None]*u[:,0]
                    return ((prediction-y)*weights[:,None])[train].ravel()
                initv=np.clip(initv,np.asarray(lower)+1e-9,np.asarray(upper)-1e-9)
                fitted=least_squares(residual,initv,bounds=(lower,upper),max_nfev=220,ftol=1e-10,xtol=1e-10,gtol=1e-10)
                unpack(fitted.x);add_fit(model,5,'temporal/'+model['family'],fitted)

    # Fit one/two additional static sources only if the single-source library
    # leaves a substantial directional residual; this is a generic hypothesis.
    best_now=min(fits,key=lambda q:q['selection_loss'])
    if include_hidden and best_now['holdout_loss']>.003:
        center_idx=center_candidates[0][1]
        model=make_model('multi_power','none',center_idx)
        model['hidden_centers']=[];model['hidden_weights']=[]
        c0=np.asarray(model['center']);radius=float(mission['launch_region']['radius_max'])
        obs=norm*np.linalg.norm(x-c0,axis=1)/np.maximum(attr,1e-12)
        k0=max(float(np.median(obs)),1e-4)
        rng=np.random.default_rng(70941)
        for n_hidden in (1,2):
            for attempt in range(6 if n_hidden==1 else 10):
                hidden=rng.uniform(-.65*radius,.65*radius,size=(n_hidden,2))
                initv=np.r_[math.log(k0/(1+n_hidden)),hidden.ravel(),np.full(n_hidden,math.log(.6))]
                lower=np.r_[-15.,np.full(n_hidden*2,-radius),np.full(n_hidden,-5.)]
                upper=np.r_[15.,np.full(n_hidden*2,radius),np.full(n_hidden,3.)]
                def unpack(vec):
                    model['parameters']={'strength':float(np.exp(vec[0]))}
                    model['hidden_centers']=vec[1:1+2*n_hidden].reshape((-1,2)).tolist()
                    model['hidden_weights']=np.exp(vec[1+2*n_hidden:]).tolist()
                def residual(vec):
                    unpack(vec)
                    centers=np.vstack([c0,np.asarray(model['hidden_centers'])])
                    rho,u=_geometry(x,centers)
                    pred=-model['parameters']['strength']*attr[:,None]*np.sum((np.r_[1.,model['hidden_weights']][None,:]/rho)[...,None]*u,axis=1)
                    return ((pred-y)*weights[:,None])[train].ravel()
                fitted=least_squares(residual,initv,bounds=(lower,upper),max_nfev=280,ftol=1e-9,xtol=1e-9,gtol=1e-9)
                unpack(fitted.x);add_fit(model,1+3*n_hidden,'additional_static_sources/'+str(n_hidden),fitted)
    best=min(fits,key=lambda q:q['selection_loss'])
    candidate=Candidate(best['model'])
    claims={'dynamics_order':2,'hidden_matter':bool(best['model']['family']=='multi_power' and len(best['model']['hidden_centers'])),
            'time_dependence':bool(best['model'].get('time_dependence'))}
    diagnostics={'method':'generic numerical hypothesis fitting; not an LLM capability result',
        'sample_count':len(samples),'training_count':int(train.sum()),'holdout_count':int(holdout.sum()),
        'velocity_noise_advantage':'velocities have no added noise; initial acceleration estimated from early velocity changes',
        'time_samples':np.unique(times).tolist(),'scaling':scaling,
        'selected':{k:v for k,v in best.items() if k!='model'},
        'ranked_candidates':[{k:v for k,v in row.items() if k!='model'} for row in sorted(fits,key=lambda q:q['selection_loss'])[:12]],
        'elapsed_seconds':time.perf_counter()-started,
        'limitations':['explicit candidate-family prior','no white-listed LLM inference or training measured',
          'no exact arbitrary image-sum hypothesis','local acceleration fitting is not proof of hidden-trajectory accuracy',
          'additional-source coordinates/weights are candidate estimates, not observed truth']}
    return {'candidate':candidate,'claims':claims,'diagnostics':diagnostics}


def _grid_time(value):
    return round(float(value)/DT)*DT


def run(console, *, include_hidden=True):
    """Acquire at most 88 probes and one batched observe under public limits."""
    mission=console.mission()
    skey,pkey=_catalog(mission)
    controls=mission['controls']
    source={skey:float(controls['source_properties'][skey]['default'])} if skey else {}
    prop={pkey:float(controls['probe_properties'][pkey]['default'])}
    region=mission['launch_region'];center=np.asarray(region['center'],dtype=float)
    lo=float(region['radius_min']);hi=float(region['radius_max'])
    radii=np.geomspace(max(lo*1.05,lo+.01),hi*.94,4)
    # A zero initial velocity measures local acceleration, not a preselected orbit.
    spatial=[]
    for r in radii:
        for a in np.arange(8)*np.pi/4+.13:
            spatial.append({'pos':(center+r*np.array([math.cos(a),math.sin(a)])).tolist(),
                'vel':[0.,0.],'properties':copy.deepcopy(prop)})
    for i in range(0,len(spatial),8):console.launch(spatial[i:i+8],0.,[0.,DT,2*DT],source)
    changed=copy.deepcopy(spatial[:8])
    for q in changed:q['properties'][pkey]=float(controls['probe_properties'][pkey]['max'])
    console.launch(changed,0.,[0.,DT,2*DT],source)
    if skey:
        changed_source={skey:float(controls['source_properties'][skey]['max'])}
        console.launch(copy.deepcopy(spatial[:8]),0.,[0.,DT,2*DT],changed_source)
    maximum=float(mission['maximum_physical_time'])
    fractions=[.07,.17,.29,.41,.53,.67,.79,.91]
    launches=[_grid_time(q*(maximum-.02)) for q in fractions]
    # One public observe request batches the full known time axis; no truth fields read.
    console.observe(sorted(set([0.]+launches)))
    probe_indices=[8,12,24,28]
    for t in launches:
        probes=[copy.deepcopy(spatial[i]) for i in probe_indices]
        console.launch(probes,t,[0.,DT,2*DT],source)
    duration=_grid_time(min(float(mission['maximum_single_trajectory_duration']),.4*maximum))
    for t in [0.,_grid_time(.31*maximum)]:
        probes=[copy.deepcopy(spatial[i]) for i in [9,11,25,27]]
        speed=min(float(mission['initial_speed_max'])*.35,1.5)
        for q in probes:
            d=np.asarray(q['pos'])-center;r=np.linalg.norm(d)
            q['vel']=(speed*np.array([-d[1],d[0]])/r).tolist()
        readout=np.unique(np.rint(np.linspace(0,duration,30)/DT).astype(int))*DT
        console.launch(probes,t,readout.tolist(),source)
    result=fit_public_transcript(mission,console.public_transcript,include_hidden=include_hidden)
    result['usage']=copy.deepcopy(console.budget)
    result['diagnostics']['acquisition_policy']='32 spatial +8 probe-attribute +optional8 source-attribute +32 time +8 long-trajectory probes; one batched observe'
    return result


__all__=['Candidate','run','fit_public_transcript','SCHEMA']
