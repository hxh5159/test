"""Organizer-only bounded closed-API calibration; no credential persistence.

Discovery receives only the public console view. Hidden evaluation takes place
after the model loop has ended and is never returned to that loop.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import math
from pathlib import Path
import re
import time

ROOT = Path(__file__).resolve().parent


def _save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def run_trial(command, *, api_key):
    from closed_proxy_client import ClosedProxyClient, LABEL
    from closed_expression_trial import ClosedExpressionTrial
    from trial_catalog import trial_config, calibrate_world, WORLDS
    from trial_console import TrialConsole
    from trial_evaluation import evaluate_model, public_feedback

    tag = command.get('tag', 'closed_pilot_01')
    if not isinstance(tag, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', tag):
        raise ValueError('tag must be a short filename-safe identifier')
    worlds = command.get('worlds', ['Adam', 'Matriel', 'Leliel'])
    if not isinstance(worlds, list) or not worlds or len(worlds)!=len(set(worlds)) or any(w not in WORLDS for w in worlds):
        raise ValueError('Invalid calibration world list')
    turns = command.get('max_turns', 16)
    output_cap = command.get('max_output_tokens_per_world', 24576)
    max_tokens = command.get('max_tokens', 3072)
    workers = command.get('workers', 2)
    for number, lower, upper in ((turns, 1, 24), (output_cap, 512, 49152),
                                  (max_tokens, 128, 8192), (workers, 1, 3)):
        if type(number) is not int or not lower<=number<=upper:
            raise ValueError('Calibration cap outside bounded operator range')
    model = command.get('model', 'gpt-6.1-sol')
    seed = command.get('seed', 0)
    if type(seed) is not int or seed < 0:
        raise ValueError('Invalid noise seed')
    destination = ROOT/'checks/closed_api_trials'/tag
    if destination.exists():
        raise FileExistsError('Choose a new tag to preserve earlier evidence')
    destination.mkdir(parents=True)
    source_names = ('closed_proxy_client.py', 'closed_expression_trial.py', 'expression_candidate.py',
                    'run_closed_calibration.py', 'trial_console.py', 'trial_catalog.py', 'trial_evaluation.py')
    manifest = {
        'scope': LABEL, 'contest_permitted': False, 'requested_model': model,
        'worlds': worlds, 'noise_seed': seed, 'noise_rule': 'launch01',
        'diagnostic_caps_not_contest_rules': {'turns_per_world': turns, 'max_tokens_per_request': max_tokens,
            'max_output_tokens_per_world': output_cap, 'workers': workers},
        'method': 'model-chosen experiments and model-proposed restricted mathematical expressions; generic parameter fitting only',
        'source_sha256': {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in source_names},
        'started_epoch': time.time(), 'status': 'running',
    }
    _save(destination/'manifest.json', manifest)
    results = {}

    def one_world(world):
        config = trial_config(world)
        region = config['launch_region']
        sigma = .01*math.sqrt((region['radius_min']**2+region['radius_max']**2)/2)
        console = TrialConsole(world, sigma, seed, config)
        client = ClosedProxyClient(model, api_key=api_key, max_requests=turns,
            max_output_tokens_total=output_cap, chat_token_field='max_completion_tokens', timeout=150.)
        client.discover(fetch_models=False)
        directory = destination/world
        trial = ClosedExpressionTrial(console, client, seed=seed, out_dir=directory,
                                     max_turns=turns, max_tokens=max_tokens, context_chars=90000)
        began = time.monotonic()
        discovery = trial.run()
        _save(directory/'transport.json', {'metadata': client.metadata, 'requests': client.request_log,
                                           'billing_budget': client.budget})
        if discovery['status']=='submitted':
            scored = evaluate_model(discovery['candidate'], calibrate_world(world),
                                    discovery['claims'], discovery['energy_used'])
        else:
            scored = {'world': world, 'prediction': 0., 'law': 0., 'saving': 0., 'total': 0.,
                      'energy_used': discovery['energy_used'], 'status': discovery['status']}
        summary = {'discovery_status': discovery['status'], 'energy_used': discovery['energy_used'],
                   'observe_used': discovery['observe_used'], 'model_turns': discovery['model_turns'],
                   'elapsed_seconds': time.monotonic()-began, 'scores': scored,
                   'transport_budget': client.budget, 'server_reported_models': client.metadata['reported_response_models']}
        _save(directory/'organizer_scores.json', summary)
        return world, summary

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(one_world, world): world for world in worlds}
        for future in as_completed(futures):
            world = futures[future]
            try:
                _, summary = future.result()
            except Exception as exc:
                summary = {'status': 'organizer_run_error', 'error_type': type(exc).__name__,
                           'error': str(exc).replace(api_key, '[REDACTED]')[:1000]}
            results[world] = summary
            _save(destination/'organizer_summary.json', {'scope': LABEL, 'worlds': results})
            print(json.dumps({'closed_calibration_world_finished': world,
                'status': summary.get('discovery_status', summary.get('status')),
                'total': summary.get('scores', {}).get('total')}, ensure_ascii=True), flush=True)
    manifest['status'] = 'completed'
    manifest['elapsed_seconds'] = time.time()-manifest['started_epoch']
    _save(destination/'manifest.json', manifest)
    credential_matches = [str(path.relative_to(destination)) for path in destination.rglob('*')
                          if path.is_file() and api_key.encode('utf-8') in path.read_bytes()]
    if credential_matches:
        raise RuntimeError('Credential audit failed; affected filenames: '+','.join(credential_matches))
    _save(destination/'credential_audit.json', {'credential_present_in_output_files': False,
                                               'checked_files': sum(path.is_file() for path in destination.rglob('*'))})
    response = {'status': 'completed', 'private_output_dir': str(destination),
                'worlds': {world: {'status': result.get('discovery_status', result.get('status')),
                    'total': result.get('scores', {}).get('total'), 'turns': result.get('model_turns')}
                    for world, result in results.items()}}
    if set(results)==set(WORLDS) and all('scores' in result for result in results.values()):
        feedback = public_feedback({world: result['scores'] for world, result in results.items()})
        _save(destination/'public_feedback.json', feedback)
        response['weighted_total'] = feedback['total_score']
    return response
