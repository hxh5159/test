"""Score one connection-failure recovery, strictly after its model loop ends."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent


def run_resume(command, *, api_key):
    from resume_closed_trial import resume_trial
    from trial_catalog import WORLDS, calibrate_world
    from trial_evaluation import evaluate_model
    world=command['world']
    if world not in WORLDS:raise ValueError('Unknown world')
    source=ROOT/'checks/closed_api_trials'/command['source_tag']/world
    output=ROOT/'checks/closed_api_trials'/command['tag']/world
    resumed=resume_trial(source,output,api_key=api_key,timeout=300.)
    result=dict(resumed['discovery'])
    result['resume_metadata']=resumed['metadata']
    candidate=result.pop('candidate',None)
    if result['status']=='submitted':
        scored=evaluate_model(candidate,calibrate_world(world),result['claims'],result['energy_used'])
    else:
        scored={'world':world,'prediction':0.,'law':0.,'saving':0.,'total':0.,'status':result['status'],
                'energy_used':result['energy_used']}
    result['scores']=scored
    result['scope']='organizer-only independent post-recovery evaluation; never model feedback'
    (output/'organizer_scores.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    matches=[str(p.relative_to(output)) for p in output.rglob('*') if p.is_file() and api_key.encode() in p.read_bytes()]
    if matches:raise RuntimeError('Credential audit failed')
    (output/'credential_audit.json').write_text(json.dumps({'credential_present_in_output_files':False})+'\n',encoding='utf-8')
    return {'status':result['status'],'world':world,'total':scored['total'],
            'energy_used':result['energy_used'],'private_output_dir':str(output)}
