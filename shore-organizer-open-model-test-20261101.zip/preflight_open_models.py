"""PRIVATE organizer-only, read-only local model/header and GPU inventory.

Uses only the Python standard library. It does not import torch/vLLM, load
tensors, download files, contact a model API, or execute model repository code.
Tensor shapes describe stored tensors, including all MoE experts; an active
parameter count such as A17B is not a checkpoint residency/memory estimate.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import struct
import subprocess
import sys


VERSION = "1.0.0"
CONSERVATIVE_CU129_DRIVER = "575.57.08"
DEFAULT_ROOT = "/inspire/hdd/global_public/public_models/Qwen"
MODEL_SPECS = (
    ("27B", "Qwen3.8-27B", "Qwen3.8-27B"),
    ("122B-A10B", "Qwen3.5-122B-A10B", "Qwen3.5-122B-A10B-FP8"),
    ("397B-A17B", "Qwen3.5-397B-A17B-FP8", "Qwen3.5-397B-A17B-FP8"),
)
MAX_JSON_BYTES = 64 * 1024 * 1024
MAX_HEADER_BYTES = 64 * 1024 * 1024
DTYPE_BYTES = {
    "BOOL": 1, "U8": 1, "I8": 1, "U16": 2, "I16": 2,
    "U32": 4, "I32": 4, "U64": 8, "I64": 8,
    "F16": 2, "BF16": 2, "F32": 4, "F64": 8,
    "F8_E4M3": 1, "F8_E5M2": 1, "F8_E4M3FN": 1,
    "F8_E4M3FNUZ": 1, "F8_E5M2FNUZ": 1,
}


class PreflightError(ValueError):
    pass


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise PreflightError("Duplicate JSON field")
        result[key] = value
    return result


def _json(raw):
    def invalid_constant(_):
        raise PreflightError("Non-finite JSON constant")
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs,
                          parse_constant=invalid_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise PreflightError("Invalid bounded UTF-8 JSON") from exc


def read_json(path, limit=MAX_JSON_BYTES):
    with Path(path).open("rb") as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise PreflightError("JSON file exceeds the inspection limit")
    value = _json(raw)
    if not isinstance(value, dict):
        raise PreflightError("Expected a JSON object")
    return value, hashlib.sha256(raw).hexdigest()


def size_record(n):
    return {"bytes": n, "GB": n / 10**9, "GiB": n / 2**30}


def inspect_safetensors(path):
    """Read the 8-byte length and JSON header, never the tensor payload."""
    path = Path(path)
    file_bytes = path.stat().st_size
    with path.open("rb") as stream:
        prefix = stream.read(8)
        if len(prefix) != 8:
            raise PreflightError("Missing safetensors length prefix")
        length = struct.unpack("<Q", prefix)[0]
        if not 2 <= length <= MAX_HEADER_BYTES or 8 + length > file_bytes:
            raise PreflightError("Invalid or oversized safetensors header length")
        header_raw = stream.read(length)
        if len(header_raw) != length:
            raise PreflightError("Truncated safetensors header")
        header = _json(header_raw)
    if not isinstance(header, dict):
        raise PreflightError("Safetensors header must be an object")
    payload_size = file_bytes - 8 - length
    tensors, intervals, warnings = {}, [], []
    for name, item in header.items():
        if name == "__metadata__":
            continue  # Free-text metadata is neither executed nor reproduced.
        if not isinstance(name, str) or not isinstance(item, dict):
            raise PreflightError("Invalid safetensors tensor entry")
        shape, offsets, dtype = item.get("shape"), item.get("data_offsets"), item.get("dtype")
        if (not isinstance(shape, list) or len(shape) > 32
                or any(type(v) is not int or v < 0 for v in shape)):
            raise PreflightError("Invalid tensor shape")
        if (not isinstance(offsets, list) or len(offsets) != 2
                or any(type(v) is not int for v in offsets)
                or not 0 <= offsets[0] <= offsets[1] <= payload_size):
            raise PreflightError("Tensor offsets exceed the local file")
        if not isinstance(dtype, str) or not dtype or len(dtype) > 64:
            raise PreflightError("Invalid tensor dtype")
        count, nbytes = math.prod(shape), offsets[1] - offsets[0]
        if dtype in DTYPE_BYTES and count * DTYPE_BYTES[dtype] != nbytes:
            raise PreflightError("Tensor shape/dtype/byte-size disagreement")
        if dtype not in DTYPE_BYTES:
            warnings.append("Unrecognized dtype %s; offsets provide bytes, original parameter count may be unknown" % dtype)
        tensors[name] = {"dtype": dtype, "elements": count, "bytes": nbytes}
        if nbytes:
            intervals.append(tuple(offsets))
    end = 0
    for start, stop in sorted(intervals):
        if start != end:
            raise PreflightError("Overlapping or unindexed safetensors payload region")
        end = stop
    if end != payload_size:
        raise PreflightError("Safetensors payload has unindexed trailing bytes")
    if not tensors:
        raise PreflightError("No tensors found")
    return {"tensors": tensors, "file_bytes": file_bytes, "header_bytes": 8 + length,
            "header_sha256": hashlib.sha256(prefix + header_raw).hexdigest(),
            "warnings": sorted(set(warnings))}


def _relative_file(root, name):
    if (not isinstance(name, str) or not name or "\\" in name or ":" in name
            or any(ord(c) < 32 for c in name)
            or any(part in ("", ".", "..") for part in name.split("/"))):
        raise PreflightError("Invalid relative shard path")
    path = PurePosixPath(name)
    if path.is_absolute():
        raise PreflightError("Absolute shard paths are not accepted")
    # Follow only the explicitly referenced path; never search sibling users or
    # caches. This also supports ordinary read-only checkpoint file symlinks.
    return Path(root).joinpath(*path.parts)


def inspect_tokenizer(root):
    root = Path(root)
    found, errors = [], []
    config_path = root / "tokenizer_config.json"
    try:
        read_json(config_path, 16 * 1024 * 1024)
        found.append("tokenizer_config.json")
    except (OSError, PreflightError):
        errors.append("Accessible valid tokenizer_config.json is required")
    candidates = (("tokenizer.json",), ("tokenizer.model",), ("vocab.json", "merges.txt"))
    readable = False
    for names in candidates:
        available = True
        for name in names:
            try:
                path = root / name
                if not path.is_file() or path.stat().st_size <= 0:
                    available = False
                    break
                with path.open("rb") as stream:
                    if not stream.read(1):
                        available = False
                        break
            except OSError:
                available = False
                break
        if available:
            found.extend(names)
            readable = True
            break
    if not readable:
        errors.append("Require readable tokenizer.json, tokenizer.model, or vocab.json plus merges.txt")
    return {"accessible_files": found, "errors": errors,
            "validation": "file access/config JSON only; tokenizer behavior and chat template are not executed"}


def inspect_weights(root):
    root = Path(root)
    index_path = root / "model.safetensors.index.json"
    index, index_sha, weight_map = None, None, None
    if index_path.is_file():
        index, index_sha = read_json(index_path)
        weight_map = index.get("weight_map")
        if not isinstance(weight_map, dict) or not weight_map:
            raise PreflightError("Safetensors index has no weight_map")
        if any(not isinstance(k, str) for k in weight_map):
            raise PreflightError("Invalid tensor name in weight_map")
        if any(not isinstance(v, str) for v in weight_map.values()):
            raise PreflightError("Invalid shard name in weight_map")
        names = sorted(set(weight_map.values()))
        paths = [_relative_file(root, n) for n in names]
    else:
        paths = sorted(root.glob("*.safetensors"))  # This directory only.
    if not paths:
        raise PreflightError("No safetensors checkpoint found; pickle/.bin files are not loaded by this preflight")
    all_tensors, dtypes, shards, warnings = {}, {}, [], []
    total_file = total_header = 0
    for path in paths:
        if path.suffix != ".safetensors":
            raise PreflightError("Index references a non-safetensors file")
        inspected = inspect_safetensors(path)
        relative = path.relative_to(root).as_posix()
        shards.append({"file": relative, "file_size": size_record(inspected["file_bytes"]),
                       "header_bytes": inspected["header_bytes"],
                       "header_sha256": inspected["header_sha256"]})
        total_file += inspected["file_bytes"]
        total_header += inspected["header_bytes"]
        warnings.extend(inspected["warnings"])
        for name, info in inspected["tensors"].items():
            if name in all_tensors:
                raise PreflightError("Duplicate tensor name across shards")
            if weight_map is not None and weight_map.get(name) != relative:
                raise PreflightError("Shard header tensor is absent/mismatched in weight_map")
            all_tensors[name] = info
            entry = dtypes.setdefault(info["dtype"], {"tensor_count": 0, "elements": 0, "bytes": 0})
            entry["tensor_count"] += 1
            entry["elements"] += info["elements"]
            entry["bytes"] += info["bytes"]
    if weight_map is not None and set(weight_map) != set(all_tensors):
        raise PreflightError("Index references tensors absent from local shard headers")
    tensor_bytes = sum(v["bytes"] for v in dtypes.values())
    if tensor_bytes <= 0:
        raise PreflightError("Checkpoint contains no tensor data")
    metadata = index.get("metadata", {}) if index else {}
    declared_bytes = metadata.get("total_size") if isinstance(metadata, dict) else None
    if declared_bytes is not None and (type(declared_bytes) is not int or declared_bytes < 0):
        warnings.append("Index metadata.total_size is not a nonnegative integer; ignored")
        declared_bytes = None
    if type(declared_bytes) is int and declared_bytes != tensor_bytes:
        warnings.append("Index metadata.total_size differs from actual tensor header byte offsets")
    return {"format": "safetensors", "shard_count": len(shards), "shards": shards,
            "tensor_count": len(all_tensors), "stored_tensor_elements": sum(v["elements"] for v in dtypes.values()),
            "tensor_payload_size": size_record(tensor_bytes), "checkpoint_file_size": size_record(total_file),
            "total_header_bytes": total_header, "dtype_distribution": dtypes,
            "index_sha256": index_sha, "index_declared_tensor_bytes": declared_bytes,
            "full_weight_hash_verified": False, "warnings": sorted(set(warnings))}


def parse_gpu_csv(text):
    rows = []
    for record in csv.reader(io.StringIO(text)):
        if not record:
            continue
        if len(record) not in (5, 6, 7):
            raise PreflightError("Unexpected nvidia-smi CSV fields")
        index, uuid, name, total, free = (item.strip() for item in record[:5])
        try:
            total_mib, free_mib = float(total), float(free)
        except ValueError as exc:
            raise PreflightError("GPU memory is unavailable") from exc
        if not all(math.isfinite(v) and v >= 0 for v in (total_mib, free_mib)) or free_mib > total_mib:
            raise PreflightError("Invalid GPU memory values")
        rows.append({"index": index, "uuid": uuid, "name": name,
                     "total_memory": size_record(int(total_mib * 2**20)),
                     "free_memory": size_record(int(free_mib * 2**20)),
                     "driver_version": record[5].strip() if len(record) >= 6 else None,
                     "compute_capability": record[6].strip() if len(record) >= 7 else None})
    return rows


def version_tuple(value):
    if not isinstance(value, str) or not value or not all(p.isdigit() for p in value.split(".")):
        return None
    return tuple(int(p) for p in value.split("."))


def inspect_gpus(devices=None, *, runner=subprocess.run, environ=None,
                 min_driver_version=CONSERVATIVE_CU129_DRIVER):
    environ = os.environ if environ is None else environ
    command = ["nvidia-smi", "--query-gpu=index,uuid,name,memory.total,memory.free,driver_version,compute_cap",
               "--format=csv,noheader,nounits"]
    try:
        response = runner(command, capture_output=True, text=True, timeout=15, check=False)
        if response.returncode != 0:
            # Older nvidia-smi may not expose compute_cap. Retry metadata only,
            # without changing any GPU/driver state.
            fallback = ["nvidia-smi", "--query-gpu=index,uuid,name,memory.total,memory.free,driver_version",
                        "--format=csv,noheader,nounits"]
            response = runner(fallback, capture_output=True, text=True, timeout=15, check=False)
        if response.returncode != 0:
            raise PreflightError("nvidia-smi did not complete successfully")
        inventory = parse_gpu_csv(response.stdout)
    except (OSError, subprocess.SubprocessError, PreflightError) as exc:
        return {"status": "unavailable", "selected": [], "warnings": [type(exc).__name__ + ": GPU metadata inspection failed"],
                "allocation_verified": False}
    selector = devices if devices is not None else environ.get("CUDA_VISIBLE_DEVICES")
    requested = [v.strip() for v in selector.split(",")] if selector is not None else [r["index"] for r in inventory[:4]]
    selected, warnings = [], []
    if len(requested) != 4 or len(set(requested)) != 4:
        warnings.append("TP=4 requires exactly four distinct assigned GPUs")
    for key in requested:
        matches = [r for r in inventory if key and key in (r["index"], r["uuid"])]
        if len(matches) != 1:
            warnings.append("A requested GPU is absent from nvidia-smi (MIG/local ordinal mapping may need explicit handling)")
        elif matches[0] not in selected:
            selected.append(matches[0])
    if any("H200" not in r["name"].upper() for r in selected):
        warnings.append("Selected hardware is not uniformly reported as H200")
    required = version_tuple(min_driver_version)
    if required is None:
        raise PreflightError("Invalid minimum driver marker")
    drivers = [version_tuple(r["driver_version"]) for r in selected]
    comparable = bool(selected) and all(v is not None for v in drivers)
    def at_least(actual):
        width = max(len(actual), len(required))
        return actual + (0,) * (width - len(actual)) >= required + (0,) * (width - len(required))
    driver_ok = all(at_least(v) for v in drivers) if comparable else None
    if driver_ok is False:
        warnings.append("Driver is below the conservative cu129 deployment marker; ask the platform administrator, do not install/upgrade the host driver from this script")
    elif driver_ok is None:
        warnings.append("Driver version could not be checked; target wheel/driver compatibility remains unverified")
    if any(r["compute_capability"] not in (None, "N/A", "[N/A]", "9.0") for r in selected):
        warnings.append("Reported compute capability is not uniformly H200-class 9.0; verify FP8/kernel support")
    return {"status": "inspected", "selected": selected, "warnings": warnings,
            "selection_source": "explicit --gpu-devices" if devices is not None else
                ("CUDA_VISIBLE_DEVICES" if selector is not None else "first four nvidia-smi entries; confirm job allocation"),
            "allocation_verified": False,
            "driver_check": {"conservative_minimum_for_cu129": min_driver_version,
                             "meets_conservative_marker": driver_ok,
                             "vllm_cuda_kernel_compatibility_verified": False,
                             "note": "A conservative deployment marker, not proof of package/driver/runtime compatibility; no driver changes are made"},
            "note": "nvidia-smi reports hardware/free memory, not scheduler ownership or vLLM compatibility"}


def memory_assessment(weight_bytes, gpu_report, tp=4):
    selected = gpu_report.get("selected", [])
    per_rank = weight_bytes / tp
    result = {"tensor_parallel_size": tp, "optimistic_weight_bytes_per_rank": per_rank,
              "four_h200_nominal_141GB_capacity_bytes": 4 * 141 * 10**9,
              "four_h200_141GiB_comparison_bytes": 4 * 141 * 2**30,
              "fits_nominal_4x141GB_weights_only": weight_bytes <= 4 * 141 * 10**9,
              "fits_4x141GiB_weights_only": weight_bytes <= 4 * 141 * 2**30,
              "fits_reported_free_memory_weights_only": None,
              "vllm_load_verified": False,
              "assumptions": "all checkpoint tensors resident, optimistic even TP split; excludes KV cache, activations, CUDA/NCCL and replicated tensors; no CPU/disk offload assumed"}
    if len(selected) == tp:
        smallest_free = min(r["free_memory"]["bytes"] for r in selected)
        result["smallest_selected_free_memory"] = size_record(smallest_free)
        result["fits_reported_free_memory_weights_only"] = per_rank < smallest_free
    return result


def inspect_model(root, role, expected_id, gpu_report):
    root = Path(root).expanduser()
    result = {"role": role, "model_path": str(root), "expected_whitelist_id": expected_id,
              "identity_verified": False, "errors": [], "warnings": []}
    if not root.is_dir():
        result["errors"].append("Selected model directory is absent or inaccessible")
        result["status"] = "error"
        return result
    try:
        config, config_sha = read_json(root / "config.json", 16 * 1024 * 1024)
        text = config.get("text_config", config)
        if not isinstance(text, dict):
            raise PreflightError("text_config must be an object")
        fields = ("model_type", "architectures", "torch_dtype", "dtype", "hidden_size", "num_hidden_layers",
                  "num_attention_heads", "num_key_value_heads", "num_experts", "num_experts_per_tok",
                  "intermediate_size", "moe_intermediate_size", "vocab_size", "tie_word_embeddings")
        result["config"] = {"sha256": config_sha,
            "top_level": {k: config[k] for k in fields if k in config},
            "text": {k: text[k] for k in fields if k in text},
            "custom_code_auto_map_present": bool(config.get("auto_map") or text.get("auto_map"))}
        quant = config.get("quantization_config", text.get("quantization_config"))
        if quant is not None and not isinstance(quant, dict):
            raise PreflightError("quantization_config must be an object or null")
        safe_quant_keys = ("quant_method", "bits", "group_size", "weight_block_size", "activation_scheme",
                           "fmt", "weight_bits", "sym", "dynamic")
        result["quantization_config"] = {k: quant[k] for k in safe_quant_keys if k in quant} if quant else {}
        result["quantization_config_present"] = bool(quant)
        result["tokenizer"] = inspect_tokenizer(root)
        result["errors"].extend(result["tokenizer"]["errors"])
        weights = inspect_weights(root)
        result["weights"] = weights
        result["warnings"].extend(weights["warnings"])
        dtypes = weights["dtype_distribution"]
        fp8 = any(k.startswith("F8") and v["bytes"] for k, v in dtypes.items())
        integer_storage = any(k.startswith(("I", "U")) and v["bytes"] for k, v in dtypes.items())
        result["precision_evidence"] = {"FP8_tensor_storage_present": fp8,
            "FP8_tensor_payload_fraction": sum(v["bytes"] for k, v in dtypes.items() if k.startswith("F8")) / weights["tensor_payload_size"]["bytes"],
            "largest_payload_dtype": max(dtypes, key=lambda k: dtypes[k]["bytes"]),
            "BF16_tensor_storage_present": bool(dtypes.get("BF16", {}).get("bytes")),
            "integer_tensor_storage_present": integer_storage,
            "source": "actual local safetensors headers; config dtype is separately reported"}
        result["parameter_estimate"] = {
            "stored_tensor_elements": weights["stored_tensor_elements"],
            "stored_tensor_billions": weights["stored_tensor_elements"] / 10**9,
            "original_unquantized_parameter_count_verified": False,
            "interpretation": "all stored tensor elements, including every expert plus possible buffers/scales; not active parameters; packed integer formats do not directly reveal original parameter count"}
        if integer_storage:
            result["warnings"].append("Integer/packed tensor shapes must not be treated as an original model parameter count")
        if quant and not fp8 and "fp8" in str(quant.get("quant_method", "")).lower():
            result["warnings"].append("Config declares FP8 but headers contain no FP8 tensors; do not assume this is an already FP8-stored checkpoint")
        if role in ("122B-A10B", "397B-A17B") and result["precision_evidence"]["FP8_tensor_payload_fraction"] < .5:
            result["whitelist_alignment"] = "requires_confirmation_or_approved_quantization"
            result["warnings"].append("Published whitelist uses the FP8 model name. A BF16/F16 directory is not made compliant by renaming or using an FP8 served-model alias")
            result["warnings"].append("Use a separately staged, verified FP8 checkpoint path with --model-122b/--model-397b; this preflight never modifies the shared original model")
        else:
            result["whitelist_alignment"] = "storage evidence available; actual release/provenance still unverified"
        for key in ("num_attention_heads", "hidden_size", "intermediate_size", "moe_intermediate_size"):
            value = text.get(key)
            if type(value) is int and value % 4:
                result["warnings"].append("Config %s is not divisible by TP=4; actual architecture support must be checked" % key)
        kv = text.get("num_key_value_heads")
        if type(kv) is int and kv < 4:
            result["warnings"].append("Fewer than four KV heads may require KV replication; memory is not a perfect /4 split")
        if result["config"]["custom_code_auto_map_present"]:
            result["warnings"].append("Config references custom model code; preflight never executes it or proves vLLM support")
        memory = memory_assessment(weights["tensor_payload_size"]["bytes"], gpu_report)
        result["memory"] = memory
        if not memory["fits_4x141GiB_weights_only"]:
            result["warnings"].append("Raw tensor weights alone exceed even 4x141GiB; full GPU residency on four H200 141GB cannot fit without a lower precision/offload plan")
        elif not memory["fits_nominal_4x141GB_weights_only"]:
            result["warnings"].append("Raw tensor weights exceed a decimal 4x141GB budget; use actual nvidia-smi memory, allowing runtime overhead, before deciding fit")
        if memory["fits_reported_free_memory_weights_only"] is False:
            result["warnings"].append("Even an optimistic TP=4 weight-only split exceeds current selected free GPU memory")
        if role == "397B-A17B" and result["precision_evidence"]["BF16_tensor_storage_present"] and not fp8:
            result["warnings"].append("397B-class BF16 requires residency of the full checkpoint, not only active A17B. Four H200 141GB must not be assumed sufficient")
    except (OSError, PreflightError, TypeError, OverflowError) as exc:
        # Never echo free-form repository metadata or raw parser exceptions.
        message = str(exc) if isinstance(exc, PreflightError) else type(exc).__name__ + ": local metadata inspection failed"
        result["errors"].append(message)
    result["warnings"] = sorted(set(result["warnings"]))
    result["status"] = "error" if result["errors"] else ("needs_review" if result["warnings"] else "inspected")
    result["deployment_verified"] = False
    return result


def readable_summary(report):
    lines = ["Organizer-only local model preflight (no model loaded)",
             "GPU inventory: %s; selected %d, TP=4" % (report["gpu"]["status"], len(report["gpu"].get("selected", [])))]
    lines.extend("GPU WARNING: " + value for value in report["gpu"].get("warnings", []))
    for gpu in report["gpu"].get("selected", []):
        lines.append("  GPU %s: %s; driver=%s; compute_cap=%s; free=%.3f GiB" %
                     (gpu["index"], gpu["name"], gpu.get("driver_version"), gpu.get("compute_capability"), gpu["free_memory"]["GiB"]))
    for model in report["models"]:
        lines.append("\n%s | %s | %s" % (model["role"], model["status"], model["model_path"]))
        if "weights" in model:
            w = model["weights"]
            size = w["tensor_payload_size"]
            lines.append("  Header tensor payload: %.3f GB / %.3f GiB; %d shards; dtypes=%s" %
                         (size["GB"], size["GiB"], w["shard_count"], ",".join(sorted(w["dtype_distribution"]))))
            lines.append("  All stored tensor elements: %.3f billion (not active parameters/proven provenance)" %
                         (w["stored_tensor_elements"] / 10**9))
        for label in ("errors", "warnings"):
            lines.extend("  %s: %s" % (label.upper(), value) for value in model[label])
    lines.append("\nHeader-only estimates do not verify weight provenance, tokenizer/model execution, vLLM compatibility or successful four-GPU loading.")
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-root", default=DEFAULT_ROOT)
    parser.add_argument("--model-path", action="append", help="Repeat exactly three times: 27B, 122B, 397B")
    parser.add_argument("--model-27b")
    parser.add_argument("--model-122b")
    parser.add_argument("--model-397b")
    parser.add_argument("--gpu-devices", help="Four nvidia-smi indices or full GPU UUIDs; otherwise CUDA_VISIBLE_DEVICES, then first four inventory entries")
    parser.add_argument("--skip-gpu", action="store_true", help="Skip nvidia-smi (metadata-only/offline inspection)")
    parser.add_argument("--json", action="store_true", help="JSON stdout; readable summary stderr")
    parser.add_argument("--json-output", type=Path, help="Write the private JSON report to an explicit new file")
    args = parser.parse_args(argv)
    explicit = (args.model_27b, args.model_122b, args.model_397b)
    if args.model_path is not None and (len(args.model_path) != 3 or any(explicit)):
        parser.error("Use exactly three --model-path options, or the named model path flags")
    paths = args.model_path or [p or str(Path(args.model_root) / spec[1]) for p, spec in zip(explicit, MODEL_SPECS)]
    gpu = {"status": "skipped", "selected": [], "warnings": [], "allocation_verified": False} if args.skip_gpu else inspect_gpus(args.gpu_devices)
    report = {"schema_version": VERSION, "scope": "organizer_only_local_header_preflight",
        "created_utc": datetime.now(timezone.utc).isoformat(), "gpu": gpu,
        "models": [inspect_model(p, spec[0], spec[2], gpu) for p, spec in zip(paths, MODEL_SPECS)],
        "network_or_model_calls": 0, "torch_or_vllm_imported": False,
        "private_test_workflow_distribution_allowed": False}
    raw = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        with args.json_output.open("x", encoding="utf-8") as stream:
            stream.write(raw)
    print(readable_summary(report), file=sys.stderr if args.json else sys.stdout)
    if args.json:
        print(raw, end="")
    # Incomplete files are a failed inspection. Capacity/compatibility warnings
    # remain report data, allowing the smaller models to be considered.
    return 2 if any(m["errors"] for m in report["models"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
