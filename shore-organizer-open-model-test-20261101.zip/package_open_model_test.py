"""Build an explicit allowlist-only PRIVATE organizer calibration archive."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = (
    "contest_simulator.py", "contest_world_definitions.json", "claims_truth.json",
    "trial_catalog.py", "trial_console.py", "trial_evaluation.py",
    "expression_candidate.py", "closed_expression_trial.py", "llm_trial_runner.py",
    "open_model_calibration.py", "preflight_open_models.py", "serve_open_models.py",
    "check_open_model_service.py", "env_open_models.sh", "requirements-trials.txt",
    "README_三模型远端测试.txt", "package_open_model_test.py",
    "tests/check_open_model_calibration.py", "tests/check_open_model_preflight.py",
    "tests/check_open_model_launch.py", "tests/check_open_model_service_transport.py",
)
NUMERICS = ("__init__.py", "rollout.py")


def package(destination):
    destination = Path(destination).resolve()
    public_repo = (ROOT.parent / "DiscoverPhysics").resolve()
    if destination == public_repo or public_repo in destination.parents:
        raise ValueError("Never write the private archive inside the public repository.")
    if destination.exists():
        raise FileExistsError("Use a new private archive path; existing evidence is not overwritten.")
    sources = {name: ROOT/name for name in FILES}
    math_root = ROOT/"rift_numerics"
    if not math_root.is_dir():
        math_root = public_repo/"rift_numerics"
    sources.update({"rift_numerics/"+name: math_root/name for name in NUMERICS})
    blobs = {name: path.read_bytes() for name, path in sources.items()}
    for name, data in blobs.items():
        if re.search(rb"sk-[A-Za-z0-9]{20,}", data):
            raise ValueError("Possible literal API credential in allowlisted file: " + name)
    manifest = {"schema_version": "1.0.0", "scope": "organizer_only_open_model_calibration",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "contains_true_physics_and_hidden_validation": True,
        "participant_distribution_allowed": False,
        "model_or_api_calls_during_packaging": 0,
        "full_law_py_agent_generation_validated": False,
        "excluded": ["API keys", "closed gateway transports", "historical trial outputs",
            "predefined physical candidate libraries", "model weights", "private memory documents"],
        "files": {name: {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
            for name, data in blobs.items()}}
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in blobs.items():
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100600 << 16
            archive.writestr(info, data)
        archive.writestr("PRIVATE_PACKAGE_MANIFEST.json",
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    return {"archive": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
        "file_count": len(blobs)+1, "private_only": True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
        default=ROOT/"exports"/"shore-organizer-open-model-test-20261101.zip")
    args = parser.parse_args(argv)
    print(json.dumps(package(args.output), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
