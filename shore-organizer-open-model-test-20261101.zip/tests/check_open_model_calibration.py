"""Offline mocks only: no API, real weights, fitting, worlds or physical simulation."""
from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import open_model_calibration as calibration
from closed_expression_trial import EXPRESSION_SYSTEM_PROMPT


CLAIMS = {"dynamics_order": 2, "hidden_matter": False, "time_dependence": False}
SPEC = {"ax": "0", "ay": "0", "parameters": {}}
MODEL = "Qwen3.6-35B-A3B"


class FakeCandidate:
    def to_dict(self):
        return {"schema_version": "offline-mock", "ax": "0", "ay": "0", "parameters": {}}


def configuration(world):
    return {"launch_region": {"kind": "annulus", "center": [0., 0.], "radius_min": 1., "radius_max": 3.},
            "energy_budget": 100, "observe_calls": 20, "wall_clock_seconds": 3600.,
            "max_probes_per_launch": 8, "max_readouts_per_probe": 50, "max_times_per_observe": 50}


class FakeConsole:
    def __init__(self, world="Adam", *args):
        self.world = world
        self._transcript = []
        self.energy = 0
        self.observations = 0

    @property
    def budget(self):
        return {"energy_remaining": 100-self.energy, "energy_used": self.energy,
                "observe_remaining": 20-self.observations, "observe_used": self.observations,
                "wall_clock_remaining_seconds": 3600.}

    @property
    def public_transcript(self):
        return copy.deepcopy(self._transcript)

    def mission(self):
        value = {"world_id": self.world, "task": "Mock public mission only", "controls": {},
                 "background_initial_state": {"ids": [], "positions": [], "velocities": []},
                 "first_light": {"times": [0., .005], "positions": [], "velocities": []}, "budget": self.budget}
        self._transcript.append({"operation": "mission", "request": {}, "response": value})
        return copy.deepcopy(value)

    def observe(self, times):
        self.observations += 1
        result = {"times": list(times), "positions": [[] for _ in times], "ids": [], "budget": self.budget}
        self._transcript.append({"operation": "observe", "request": {"times": list(times)}, "response": result})
        return result


class FakeClient:
    capability_label = "protocol_mock_only_not_model_capability"

    def __init__(self, actions):
        self.actions = list(actions)
        self.requests = []
        self.request_log = []
        self.metadata = {"served_model": MODEL, "mock": True}
        self.last_failure = None

    @property
    def budget(self):
        return {"requests_used": len(self.requests), "output_tokens_accounted": len(self.requests)}

    def discover(self):
        return copy.deepcopy(self.metadata)

    def complete(self, messages, **kwargs):
        self.requests.append(copy.deepcopy(messages))
        action = self.actions.pop(0)
        if isinstance(action, Exception):
            raise action
        content = action if isinstance(action, str) else json.dumps(action)
        return {"model": MODEL, "choices": [{"message": {"content": content}}],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1}}


def fake_fit(mission, transcript, spec):
    return {"candidate": FakeCandidate(), "fitted_parameters": {},
            "claims": {"do_not_send": "PRIVATE_CLAIM_MARKER"}, "diagnostics": {"mock": True}}


def finish():
    return {"action": "finish", "spec": copy.deepcopy(SPEC), "claims": copy.deepcopy(CLAIMS)}


def setUpModule():
    (ROOT / "checks").mkdir(parents=True, exist_ok=True)


class OpenCalibrationTests(unittest.TestCase):
    def args(self, folder, *extra):
        weights = Path(folder)/"weight-folder-without-quant-suffix"
        weights.mkdir(exist_ok=True)
        (weights/"config.json").write_text(json.dumps({"model_type": "fake", "torch_dtype": "bfloat16",
            "quantization_config": {"quant_method": "fp8"}}), encoding="utf-8")
        return calibration.parse_args(["--base-url", "http://127.0.0.1:9000/v1", "--model", MODEL,
            "--model-path", str(weights), "--out-dir", str(Path(folder)/"new-output"), *extra])

    def deps(self, clients, *, score=None, references=None):
        queue = list(clients)
        def client_factory(*args, **kwargs):
            return queue.pop(0)
        def reference(world):
            if references is not None:
                references.append(world)
            return {"world": world, "PRIVATE_VALIDATION_MARKER": True}
        def evaluate(candidate, truth, claims, energy):
            if score is not None:
                return score(candidate, truth, claims, energy)
            return {"world": truth["world"], "prediction": 1., "law": 2., "saving": 0., "total": 3.}
        return {"client_factory": client_factory, "config_factory": configuration,
                "console_factory": FakeConsole, "reference_factory": reference, "evaluate_fn": evaluate,
                "feedback_fn": lambda results: {"total_score": 3., "world_scores": {}}, "expression_fit_fn": fake_fit}

    def test_import_has_no_endpoint_or_world_side_effects(self):
        spec = importlib.util.spec_from_file_location("_open_calibration_import_probe", ROOT/"open_model_calibration.py")
        module = importlib.util.module_from_spec(spec)
        with patch("urllib.request.OpenerDirector.open", side_effect=AssertionError("No network on import")):
            spec.loader.exec_module(module)
        self.assertEqual(module.SCOPE, calibration.SCOPE)

    def test_presets_and_explicit_zero_preserve_full_exploration(self):
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder)
            self.assertEqual((args.max_turns, args.max_output_tokens_per_world, args.max_tokens), (0, 0, 8192))
            self.assertEqual((args.context_token_limit, args.context_token_margin), (32768, 256))
            args = self.args(folder, "--preset", "compare")
            self.assertEqual((args.max_turns, args.max_output_tokens_per_world, args.max_tokens), (16, 24576, 3072))
            args = self.args(folder, "--preset", "compare", "--max-turns", "0", "--max-output-tokens-per-world", "0")
            self.assertEqual((args.max_turns, args.max_output_tokens_per_world), (0, 0))

    def test_fit_finish_are_anonymous_without_library_or_claim_suggestions(self):
        client = FakeClient([{"action": "fit"}, {"action": "fit_expression", "spec": SPEC},
                             {"action": "finish", "candidate_id": "expr_1", "claims": CLAIMS}])
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            trial = calibration.OpenModelExpressionTrial(FakeConsole(), client, seed=0, out_dir=Path(folder)/"trial",
                                                         expression_fit_fn=fake_fit)
            result = trial.run()
            self.assertEqual(result["status"], "submitted")
            self.assertIn("action_error", trial.events[0]["tool_response"])
            self.assertNotIn("claims", trial.events[1]["tool_response"])
            self.assertNotIn("suggested_claims", trial.events[1]["tool_response"])
            for request in client.requests:
                self.assertEqual(request[0]["content"], EXPRESSION_SYSTEM_PROMPT)
            sent = json.dumps(client.requests)
            self.assertNotIn("Adam", sent)
            self.assertNotIn("PRIVATE_CLAIM_MARKER", sent)
            saved = json.loads((Path(folder)/"trial/run.json").read_text(encoding="utf-8"))
            self.assertEqual(saved["scope"], calibration.SCOPE)
            self.assertFalse(saved["run_is_official_competition"])
            self.assertNotIn("Closed-model", json.dumps(saved))

    def test_scoring_is_after_discovery_and_never_in_model_context(self):
        client = FakeClient([finish()])
        references = []
        def score(candidate, truth, claims, energy):
            self.assertEqual(len(client.actions), 0)
            self.assertEqual(claims, CLAIMS)
            return {"world": truth["world"], "total": 3., "PRIVATE_SCORE_MARKER": True}
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam", "--weight-precision", "operator-declared-fp8")
            result = calibration.run_calibration(args, **self.deps([client], score=score, references=references))
            self.assertEqual(result["status"], "completed")
            self.assertEqual(references, ["Adam"])
            self.assertNotIn("PRIVATE_VALIDATION_MARKER", json.dumps(client.requests))
            self.assertNotIn("PRIVATE_SCORE_MARKER", json.dumps(client.requests))
            manifest = json.loads((args.out_dir/"manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["weight_metadata"]["config_declared_dtype"], "bfloat16")
            self.assertEqual(manifest["weight_metadata"]["operator_declared_precision"], "operator-declared-fp8")
            self.assertFalse(manifest["weight_metadata"]["actual_serving_precision_verified"])
            self.assertIn("PRIVATE_SCORE_MARKER", (args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))

    def test_every_world_has_new_context_and_independent_client(self):
        clients = [FakeClient([finish()]), FakeClient([finish()])]
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam", "Lilith")
            calibration.run_calibration(args, **self.deps(clients))
            ids = []
            for client in clients:
                self.assertEqual(len(client.requests[0]), 3)
                control = json.JSONDecoder().raw_decode(client.requests[0][2]["content"].split("\n", 1)[1])[0]
                self.assertEqual(control["available_candidate_ids"], [])
                self.assertEqual(len(control["record_directory"]), 1)
                ids.append(client.requests[0][1]["content"])
            self.assertNotEqual(ids[0], ids[1])

    def test_invalid_text_and_transport_failure_do_not_get_private_evaluation(self):
        client = FakeClient(["not a JSON action", RuntimeError("fake endpoint unavailable")])
        references = []
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            result = calibration.run_calibration(args, **self.deps([client], references=references))
            self.assertEqual(result["status"], "completed_with_errors")
            self.assertEqual(references, [])
            row = json.loads((args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))
            self.assertEqual(row["discovery_status"], "model_transport_or_context_error")
            self.assertEqual(row["action_error_count"], 1)
            self.assertTrue(row["zero_is_calibration_placeholder"])
            self.assertEqual(row["evaluation_status"], "not_evaluated_no_submission")

    def test_context_failure_is_not_a_scientific_zero(self):
        client = FakeClient([RuntimeError("context_failure: fake fixed mission exceeds context")])
        client.last_failure = {"classification": "context_failure"}
        references = []
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            result = calibration.run_calibration(args, **self.deps([client], references=references))
            self.assertEqual(result["status"], "completed_with_errors")
            self.assertEqual(references, [])
            row = json.loads((args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))
            self.assertNotIn("scores", row)
            self.assertEqual(row["failure_classification"], "context_failure")
            self.assertEqual(row["evaluation_status"], "not_evaluated_context_failure")

    def test_evaluation_infrastructure_failure_is_not_scored_as_scientific_zero(self):
        def failed_score(*args):
            raise RuntimeError("fake evaluator configuration failure")
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            calibration.run_calibration(args, **self.deps([FakeClient([finish()])], score=failed_score))
            row = json.loads((args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))
            self.assertNotIn("scores", row)
            self.assertEqual(row["failure_classification"], "post_discovery_evaluation_failure")
            run = json.loads((args.out_dir/"Adam/seed_0/run.json").read_text(encoding="utf-8"))
            self.assertEqual(run["status"], "submitted")
            self.assertEqual(run["evaluation_status"], "failed_without_scientific_zero")

    def test_existing_output_is_rejected_before_any_model_call(self):
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            args.out_dir.mkdir()
            with self.assertRaises(FileExistsError):
                calibration.run_calibration(args, **self.deps([]))

    def test_invalid_candidate_prediction_keeps_the_scorers_law_component(self):
        def score(candidate, truth, claims, energy):
            return {"world": truth["world"], "prediction": 0., "law": 10., "saving": 0., "total": 10.,
                    "invalid_cases": [{"error": "fake candidate prediction failure"}]}
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            result = calibration.run_calibration(args, **self.deps([FakeClient([finish()])], score=score))
            self.assertEqual(result["status"], "completed")
            row = json.loads((args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))
            self.assertEqual(row["scores"]["total"], 10.)
            self.assertEqual(row["failure_classification"], "candidate_prediction_invalid")

    def test_setup_failure_is_recorded_without_fabricated_scores(self):
        class BrokenClient(FakeClient):
            def discover(self):
                raise RuntimeError("fake unavailable service")
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            args = self.args(folder, "--worlds", "Adam")
            calibration.run_calibration(args, **self.deps([BrokenClient([])]))
            row = json.loads((args.out_dir/"Adam/seed_0/organizer_scores.json").read_text(encoding="utf-8"))
            self.assertNotIn("scores", row)
            self.assertEqual(row["failure_classification"], "model_service_setup_failure")
            self.assertEqual(json.loads((args.out_dir/"Adam/seed_0/run.json").read_text(encoding="utf-8"))["scope"], calibration.SCOPE)

    def test_changed_science_limits_are_rejected(self):
        wrong = configuration("Adam")
        wrong["energy_budget"] = 101
        with self.assertRaises(ValueError):
            calibration._exploration_config(wrong)

    def test_transport_sends_explicit_sampling_and_respects_optional_caps(self):
        client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000", MODEL,
                   max_requests=2, max_output_tokens_total=3)
        bodies = []
        def request(suffix, body=None):
            bodies.append((suffix, body))
            if suffix == "/models":
                return {"data": [{"id": MODEL}]}
            return {"model": MODEL, "choices": [{"message": {"content": "{}"}}], "usage": {"completion_tokens": 2}}
        with patch.object(client, "_request", side_effect=request):
            client.discover()
            client.complete([], seed=2, max_tokens=20, temperature=.3)
            self.assertEqual(bodies[-1][1]["max_tokens"], 3)
            self.assertEqual(bodies[-1][1]["seed"], 2)
            self.assertEqual(bodies[-1][1]["temperature"], .3)
            self.assertNotIn("reasoning_effort", bodies[-1][1])
            client.complete([], seed=3, max_tokens=20, temperature=.3)
            self.assertEqual(bodies[-1][1]["max_tokens"], 1)
            with self.assertRaises(RuntimeError):
                client.complete([], seed=4, max_tokens=20, temperature=.3)
        self.assertEqual(client.last_failure["classification"], "diagnostic_request_cap")

    def test_malformed_server_response_is_classified_without_raw_payload(self):
        client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000", MODEL)
        client.model = MODEL
        with patch.object(client, "_request", return_value={"choices": [], "private_server_text": "do-not-log"}):
            with self.assertRaises(RuntimeError):
                client.complete([], seed=0, max_tokens=5)
        self.assertEqual(client.last_failure["classification"], "model_transport_or_response_failure")
        self.assertNotIn("do-not-log", json.dumps(client.request_log))
        self.assertEqual(client.budget["output_tokens_accounted"], 5)

    def test_tokenizer_uses_root_route_same_host_and_chat_template(self):
        captured = []
        class Reply:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def read(self, limit):
                return b'{"count":17,"max_model_len":32768,"tokens":[1,2]}'
        class Opener:
            def open(self, request, *, timeout):
                captured.append(request)
                return Reply()
        client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000/prefix/v1", MODEL,
                                                        context_token_limit=32768)
        client.model = MODEL
        client._opener = Opener()
        result = client._tokenize([{"role": "user", "content": "offline input"}])
        self.assertEqual(result["count"], 17)
        self.assertEqual(captured[0].full_url, "http://127.0.0.1:9000/prefix/tokenize")
        body = json.loads(captured[0].data)
        self.assertEqual(body["model"], MODEL)
        self.assertTrue(body["add_generation_prompt"])
        self.assertEqual(body["messages"], [{"role": "user", "content": "offline input"}])

    def test_token_trimming_reserves_output_and_mutates_actual_request_in_place(self):
        client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000", MODEL,
                                                        context_token_limit=30, context_token_margin=2)
        client.model = MODEL
        fixed = [{"role": "system", "content": "fixed-system"},
                 {"role": "user", "content": "fixed-mission"}, {"role": "user", "content": "fixed-control"}]
        history = [{"role": "assistant", "content": "old action"}, {"role": "user", "content": "old result"},
                   {"role": "assistant", "content": "recent action"}, {"role": "user", "content": "recent result"}]
        messages = copy.deepcopy(fixed+history)
        sent = []
        def generate(suffix, body):
            sent.append(copy.deepcopy(body["messages"]))
            return {"model": MODEL, "choices": [{"message": {"content": "{}"}}], "usage": {"completion_tokens": 1}}
        def tokens(values):
            return {"count": 10+5*(len(values)-3), "max_model_len": 32768}
        with patch.object(client, "_request", side_effect=generate), patch.object(client, "_tokenize", side_effect=tokens):
            client.complete(messages, seed=0, max_tokens=5)
        self.assertEqual(messages[:3], fixed)
        self.assertEqual(messages[3:], history[2:])
        self.assertEqual(sent, [messages])
        check = client.context_checks[0]
        self.assertEqual(check["available_input_tokens"], 23)
        self.assertEqual(check["removed_history_pairs"], 1)
        self.assertEqual(check["input_tokens_before"], 30)
        self.assertEqual(check["input_tokens_after"], 20)

    def test_fixed_context_overflow_and_tokenizer_failure_are_context_failures(self):
        for response in ({"count": 100}, RuntimeError("fake tokenizer unavailable")):
            with self.subTest(response_type=type(response).__name__):
                client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000", MODEL,
                                                                context_token_limit=20, context_token_margin=2)
                client.model = MODEL
                messages = [{"role": "system", "content": "s"}, {"role": "user", "content": "m"},
                            {"role": "user", "content": "c"}]
                tokenize = patch.object(client, "_tokenize", side_effect=response) if isinstance(response, Exception) else \
                           patch.object(client, "_tokenize", return_value=response)
                with tokenize, patch.object(client, "_request", side_effect=AssertionError("No generation on context failure")):
                    with self.assertRaisesRegex(RuntimeError, "context_failure"):
                        client.complete(messages, seed=0, max_tokens=5)
                self.assertEqual(client.last_failure["classification"], "context_failure")
                self.assertEqual(client.budget["requests_used"], 0)
                self.assertFalse(client.request_log[0]["generation_request_sent"])
                self.assertEqual(len(messages), 3)

    def test_logged_messages_match_sent_trimmed_messages_without_erasing_history(self):
        client = calibration.SelfHostedCalibrationClient("http://127.0.0.1:9000", MODEL,
                                                        context_token_limit=40, context_token_margin=2)
        client.model = MODEL
        client.metadata = {"mock": True, "served_model": MODEL}
        actions = [{"action": "mission"}, finish()]
        sent = []
        def generate(suffix, body):
            sent.append(copy.deepcopy(body["messages"]))
            return {"model": MODEL, "choices": [{"message": {"content": json.dumps(actions.pop(0))}}],
                    "usage": {"completion_tokens": 1}}
        def tokens(values):
            return {"count": 10 if len(values) == 3 else 50}
        with tempfile.TemporaryDirectory(dir=ROOT/"checks", prefix="open_model_mock_") as folder:
            trial = calibration.OpenModelExpressionTrial(FakeConsole(), client, seed=0, out_dir=Path(folder)/"trial",
                                                         max_tokens=5, expression_fit_fn=fake_fit)
            with patch.object(client, "_request", side_effect=generate), patch.object(client, "_tokenize", side_effect=tokens):
                result = trial.run()
            self.assertEqual(result["status"], "submitted")
            self.assertEqual(len(trial.history), 4)
            self.assertEqual(len(trial.records), 2)
            self.assertEqual(len(sent[1]), 3)
            self.assertEqual(trial.events[1]["model_request"]["messages"], sent[1])
            saved = json.loads((Path(folder)/"trial/model_events.json").read_text(encoding="utf-8"))
            self.assertEqual(saved[1]["model_request"]["messages"], sent[1])
            self.assertEqual(client.context_checks[1]["removed_history_pairs"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
