"""PRIVATE organizer calibration against an explicitly self-hosted whitelist model.

Importing this module never contacts a model or runs a physical simulation.
The model proposes experiments and restricted mathematical expressions; there
is no predefined physical hypothesis search or scientific-claim suggestion.
This is an organizer tool, not a contestant agent or arbitrary law.py workflow.
All output, including post-discovery scores, belongs in an organizer-only area.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request

from closed_expression_trial import ClosedExpressionTrial
from llm_trial_runner import VLLMClient, WORLDS, allowed_model, json_copy, weight_metadata


ROOT = Path(__file__).resolve().parent
RUNNER_VERSION = "private-open-expression-calibration-1.0.0"
SCOPE = "organizer_only_self_hosted_open_weight_expression_calibration"
PRESETS = {
    "contest": {"max_turns": 0, "max_output_tokens_per_world": 0, "max_tokens": 8192},
    "compare": {"max_turns": 16, "max_output_tokens_per_world": 24576, "max_tokens": 3072},
}


def _save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _redact(value, secret):
    if isinstance(value, dict):
        return {key: _redact(item, secret) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact(item, secret) for item in value]
    if isinstance(value, str) and secret:
        return value.replace(secret, "<redacted>")
    return value


class SelfHostedCalibrationClient(VLLMClient):
    """The existing vLLM transport with optional, explicitly diagnostic caps."""

    def __init__(self, base_url, model, *, api_key=None, timeout=300.,
                 max_requests=0, max_output_tokens_total=0,
                 context_token_limit=0, context_token_margin=256):
        super().__init__(base_url, model, api_key=api_key, timeout=timeout)
        for value in (max_requests, max_output_tokens_total, context_token_limit, context_token_margin):
            if type(value) is not int or value < 0:
                raise ValueError("Caps, context limit and token margin must be nonnegative integers.")
        self.max_requests = max_requests
        self.max_output_tokens_total = max_output_tokens_total
        self.context_token_limit = context_token_limit
        self.context_token_margin = context_token_margin
        self.context_checks = []
        self.request_log = []
        self.last_failure = None
        self._requests_used = self._output_accounted = self._output_reported = 0

    @property
    def budget(self):
        return {"requests_used": self._requests_used,
                "requests_remaining": None if not self.max_requests else max(0, self.max_requests-self._requests_used),
                "output_tokens_accounted": self._output_accounted,
                "reported_output_tokens": self._output_reported,
                "output_tokens_remaining": None if not self.max_output_tokens_total else
                    max(0, self.max_output_tokens_total-self._output_accounted),
                "caps_are_diagnostic_not_contest_rules": True}

    def discover(self):
        super().discover()
        self.metadata.update(scope=SCOPE, model_route="explicit_self_hosted_whitelisted_model",
            seed_sent=True, temperature_sent=True, reasoning_effort_sent=False,
            transport="OpenAI-compatible GET /v1/models and POST /v1/chat/completions",
            extra_request_cap=self.max_requests, extra_output_token_cap=self.max_output_tokens_total,
            cap_zero_meaning="No additional cap; world wall-clock and experiment quotas still apply.",
            context_protection={"configured_token_limit": self.context_token_limit,
                "output_reservation": "Actual requested output tokens plus the configured margin.",
                "token_margin": self.context_token_margin,
                "tokenizer_route": self.base_url[:-3]+"/tokenize",
                "enabled": bool(self.context_token_limit),
                "zero_limit_meaning": "Token protection disabled explicitly; caller must ensure context compatibility.",
                "history_policy": "Preserve the first three fixed messages; omit oldest history pairs from this request only."},
            usage_verification="Inference-server self-report; not independent token or weight verification.")
        self.metadata = _redact(self.metadata, self._api_key)
        return json_copy(self.metadata)

    def _tokenize(self, messages):
        """Use the same server/chat template; vLLM exposes /tokenize outside /v1."""
        if self.model is None:
            raise RuntimeError("Call discover() before token counting.")
        body = {"model": self.model, "messages": messages,
                "add_generation_prompt": True, "return_token_strs": False}
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = "Bearer " + self._api_key
        # base_url is normalized to end in /v1 by the existing client.
        # Keep any operator-configured reverse-proxy prefix on the same host.
        request = Request(self.base_url[:-3]+"/tokenize",
            data=json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8"),
            headers=headers, method="POST")
        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                raw = response.read(8*1024*1024+1)
            if len(raw) > 8*1024*1024:
                raise ValueError("Tokenizer response exceeded the transport guard.")
            result = json.loads(raw)
        except HTTPError as exc:
            raise RuntimeError(f"Self-hosted tokenizer returned HTTP {exc.code}; context protection cannot be verified.") from None
        except URLError:
            raise RuntimeError("Self-hosted tokenizer is unavailable; context protection cannot be verified.") from None
        except (UnicodeError, ValueError):
            raise RuntimeError("Self-hosted tokenizer returned invalid JSON or an oversized response.") from None
        if not isinstance(result, dict) or type(result.get("count")) is not int or result["count"] < 0:
            raise RuntimeError("Self-hosted tokenizer did not return a nonnegative integer count.")
        return result

    def _prepare_context(self, messages, output_limit):
        audit = {"enabled": bool(self.context_token_limit), "configured_token_limit": self.context_token_limit,
                 "reserved_output_tokens": output_limit, "token_margin": self.context_token_margin,
                 "input_tokens_before": None, "input_tokens_after": None,
                 "removed_history_pairs": 0, "removed_unpaired_history_messages": 0,
                 "tokenize_calls": 0}
        if not self.context_token_limit:
            audit["status"] = "protection_disabled_explicitly"
            self.context_checks.append(audit)
            return audit
        effective = self.context_token_limit
        server_metadata = (self.metadata or {}).get("server_model_metadata") or {}
        reported = server_metadata.get("max_model_len")
        if type(reported) is int and reported > 0:
            effective = min(effective, reported)
        try:
            if not isinstance(messages, list) or len(messages) < 3:
                raise ValueError("Token protection requires the three fixed system/mission/control messages.")
            while True:
                audit["tokenize_calls"] += 1
                tokenized = self._tokenize(messages)
                server_limit = tokenized.get("max_model_len")
                if type(server_limit) is int and server_limit > 0:
                    effective = min(effective, server_limit)
                count = tokenized["count"]
                if type(count) is not int or count < 0:
                    raise ValueError("Tokenizer count must be a nonnegative integer.")
                if audit["input_tokens_before"] is None:
                    audit["input_tokens_before"] = count
                budget = effective-output_limit-self.context_token_margin
                audit.update(effective_token_limit=effective, available_input_tokens=budget, input_tokens_after=count)
                if count <= budget:
                    audit["status"] = "trimmed" if (audit["removed_history_pairs"] or
                        audit["removed_unpaired_history_messages"]) else "within_limit"
                    return audit
                if len(messages) == 3:
                    raise ValueError("Fixed system/mission/control context plus output reservation exceeds the context-token limit.")
                # The legacy character guard may have retained a leading tool
                # result without its assistant message. Omit that incomplete
                # oldest fragment before removing complete history pairs.
                if messages[3].get("role") != "assistant":
                    del messages[3]
                    audit["removed_unpaired_history_messages"] += 1
                elif len(messages) >= 5 and messages[4].get("role") == "user":
                    del messages[3:5]
                    audit["removed_history_pairs"] += 1
                else:
                    raise ValueError("Retained history does not contain a removable assistant/tool-result pair.")
        except Exception as exc:
            audit.update(status="context_failure", error_type=type(exc).__name__,
                         error=_redact(str(exc), self._api_key)[:1000])
            self.last_failure = {"classification": "context_failure", "error_type": type(exc).__name__,
                                 "message": audit["error"]}
            raise RuntimeError("context_failure: " + audit["error"]) from None
        finally:
            self.context_checks.append(audit)

    def complete(self, messages, *, seed, max_tokens=8192, temperature=.3):
        if type(max_tokens) is not int or max_tokens <= 0:
            raise ValueError("max_tokens must be a positive integer.")
        if self.max_requests and self._requests_used >= self.max_requests:
            self.last_failure = {"classification": "diagnostic_request_cap", "message": "Extra request cap reached."}
            raise RuntimeError(self.last_failure["message"])
        remaining = self.budget["output_tokens_remaining"]
        limit = max_tokens if remaining is None else min(max_tokens, remaining)
        if limit <= 0:
            self.last_failure = {"classification": "diagnostic_output_token_cap", "message": "Extra output-token cap reached."}
            raise RuntimeError(self.last_failure["message"])
        try:
            context_audit = self._prepare_context(messages, limit)
        except RuntimeError:
            self.request_log.append({"status": "context_failure", "generation_request_sent": False,
                "requested_output_limit": limit, "context": self.context_checks[-1], "error": self.last_failure,
                "budget_after": self.budget})
            raise
        self._requests_used += 1
        row = {"request_number": self._requests_used, "requested_model": self.requested_model,
               "requested_output_limit": limit, "seed_sent": int(seed),
               "temperature_sent": float(temperature), "reasoning_effort_sent": False,
               "context": context_audit, "generation_request_sent": True}
        began = time.monotonic()
        try:
            response = super().complete(messages, seed=seed, max_tokens=limit, temperature=temperature)
            if (not isinstance(response, dict) or not isinstance(response.get("choices"), list)
                    or not response["choices"] or not isinstance(response["choices"][0], dict)
                    or not isinstance(response["choices"][0].get("message"), dict)
                    or not isinstance(response["choices"][0]["message"].get("content"), str)):
                raise ValueError("Inference server did not return textual choices[0].message.content.")
            usage = response.get("usage")
            reported = usage.get("completion_tokens") if isinstance(usage, dict) else None
            valid_usage = type(reported) is int and reported >= 0
            accounted = reported if valid_usage else limit
            self._output_accounted += accounted
            if valid_usage:
                self._output_reported += reported
            row.update(status="ok", response_model=response.get("model"),
                usage=_redact(usage, self._api_key), output_usage_missing=not valid_usage,
                accounted_output=accounted,
                accounting_policy="Reported completion_tokens when valid; otherwise reserve requested limit conservatively.")
            self.last_failure = None
            return _redact(response, self._api_key)
        except Exception as exc:
            # A failed/unknown response may already have generated tokens.
            self._output_accounted += limit
            self.last_failure = {"classification": "model_transport_or_response_failure",
                "error_type": type(exc).__name__, "message": _redact(str(exc), self._api_key)[:1000]}
            row.update(status="failed", accounted_output=limit, error=self.last_failure)
            raise RuntimeError(self.last_failure["message"]) from None
        finally:
            row.update(elapsed_seconds=time.monotonic()-began, budget_after=self.budget)
            self.request_log.append(_redact(row, self._api_key))


def discovery_failure(status, client):
    if status in ("running", "submitted"):
        return None
    if status == "model_transport_or_context_error":
        return (getattr(client, "last_failure", None) or {}).get("classification", "model_transport_or_context_failure")
    return {"turn_limit_no_submission": "diagnostic_turn_limit_no_submission",
            "wall_clock_expired_no_submission": "exploration_wall_clock_no_submission"}.get(status, status)


class OpenModelExpressionTrial(ClosedExpressionTrial):
    """Reuse exactly the expression prompt/actions; record the actual open route."""

    def _write(self, status):
        self.out_dir.mkdir(parents=True, exist_ok=True)
        _save(self.out_dir/"public_records.json", self._anonymous(self.records))
        _save(self.out_dir/"model_events.json", self.events)
        _save(self.out_dir/"public_console_transcript.json", self._public_transcript())
        _save(self.out_dir/"run.json", {
            "runner_version": RUNNER_VERSION, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "scope": SCOPE, "status": status, "failure_classification": discovery_failure(status, self.client),
            "capability_label": getattr(self.client, "capability_label", "protocol_mock_only_not_model_capability"),
            "model_route": "self_hosted_whitelisted_open_weight", "run_is_official_competition": False,
            "world_id": self.opaque_world_id, "seed": self.seed,
            "diagnostic_model_turn_cap": self.max_turns, "cap_is_contest_rule": False,
            "model_turns": len(self.events), "budget": self.console.budget,
            "model_metadata": getattr(self.client, "metadata", None), "api_budget": getattr(self.client, "budget", None),
            "context_checks": getattr(self.client, "context_checks", []),
            "submission": self.finished,
            "limitations": ["Restricted mathematical expressions, not arbitrary law.py or contestant workflow.",
                "No predefined physical family search or scientific-claim suggestion.",
                "Expression tool does not support velocity-dependent acceleration or arbitrary hidden-object arrays.",
                "Serving metadata/config summaries do not prove the actual loaded weight files.",
                "All records and post-discovery scores remain organizer-only."]})
        if self.finished is not None:
            _save(self.out_dir/"candidate.json", self.finished["candidate"])
            _save(self.out_dir/"claims.json", self.finished["claims"])


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--base-url", required=True, help="Explicit self-hosted OpenAI-compatible server URL.")
    parser.add_argument("--model", required=True, help="Canonical whitelist served model ID (not an arbitrary alias).")
    parser.add_argument("--model-path", type=Path, required=True, help="Existing readable weight directory; config metadata only.")
    parser.add_argument("--weight-precision", default="unspecified", help="Operator declaration of actual dtype/quantization; not weight proof.")
    parser.add_argument("--out-dir", type=Path, required=True, help="NEW organizer-only directory; never overwrite an existing directory.")
    parser.add_argument("--worlds", nargs="+", choices=WORLDS, default=list(WORLDS))
    parser.add_argument("--seeds", nargs="+", type=int, default=[0])
    parser.add_argument("--noise-rule", choices=["launch01"], default="launch01")
    parser.add_argument("--preset", choices=PRESETS, default="contest",
                        help="contest: no extra turn/token-total caps, 8192/request; compare: 16/24576/3072.")
    parser.add_argument("--max-turns", type=int, help="Extra diagnostic cap; 0 means no extra turn cap.")
    parser.add_argument("--max-output-tokens-per-world", type=int, help="Extra output-token cap; 0 means no extra total cap.")
    parser.add_argument("--max-tokens", type=int, help="Requested single-response output limit, including reasoning when the server counts it there.")
    parser.add_argument("--context-chars", type=int, default=90000)
    parser.add_argument("--context-token-limit", type=int, default=32768,
                        help="Total prompt+output context limit; 0 explicitly disables server-tokenizer protection.")
    parser.add_argument("--context-token-margin", type=int, default=256,
                        help="Extra token reserve beyond the requested response length.")
    parser.add_argument("--temperature", type=float, default=.3)
    parser.add_argument("--http-timeout", type=float, default=300.)
    parser.add_argument("--api-key-env", default="TRIAL_VLLM_API_KEY", help="Optional environment-variable name; never a literal key.")
    return parser


def parse_args(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    for key, value in PRESETS[args.preset].items():
        if getattr(args, key) is None:
            setattr(args, key, value)
    if min(args.max_turns, args.max_output_tokens_per_world, args.context_token_limit, args.context_token_margin) < 0:
        parser.error("Extra caps must be nonnegative; 0 means no extra cap.")
    if args.max_tokens <= 0 or args.context_chars < 8000:
        parser.error("max-tokens must be positive and context-chars must be at least 8000.")
    if (not math.isfinite(args.temperature) or args.temperature < 0
            or not math.isfinite(args.http_timeout) or args.http_timeout <= 0):
        parser.error("temperature must be finite/nonnegative and http-timeout finite/positive.")
    if (not args.seeds or any(seed < 0 for seed in args.seeds)
            or len(args.seeds) != len(set(args.seeds)) or len(args.worlds) != len(set(args.worlds))):
        parser.error("Use distinct worlds and distinct nonnegative seeds.")
    if not args.weight_precision or not args.weight_precision.isprintable() or len(args.weight_precision) > 256:
        parser.error("weight-precision must be a short printable operator declaration.")
    return args


def _weights(path, precision):
    result = weight_metadata(path)
    config = json.loads((Path(path)/"config.json").read_text(encoding="utf-8-sig"))
    result.update(operator_declared_precision=precision, operator_declaration_is_weight_proof=False,
                  config_declared_dtype=config.get("dtype", config.get("torch_dtype")),
                  actual_serving_precision_verified=False)
    return result


def _source_hashes():
    names = ("open_model_calibration.py", "closed_expression_trial.py", "llm_trial_runner.py",
             "expression_candidate.py", "trial_console.py", "trial_catalog.py", "trial_evaluation.py",
             "contest_simulator.py", "contest_world_definitions.json", "claims_truth.json")
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}


def _exploration_config(config):
    expected = {"energy_budget": 100, "observe_calls": 20, "wall_clock_seconds": 3600,
                "max_probes_per_launch": 8, "max_readouts_per_probe": 50, "max_times_per_observe": 50}
    if any(config.get(key, value) != value for key, value in expected.items()):
        raise ValueError("This calibration must preserve the current 100/20/3600 exploration and instrument limits.")
    region = config["launch_region"]
    lower, upper = float(region["radius_min"]), float(region["radius_max"])
    if not math.isfinite(lower+upper) or not 0 <= lower < upper:
        raise ValueError("Invalid organizer launch-region reference length.")
    return .01*math.sqrt((lower*lower+upper*upper)/2)


def run_calibration(args, *, api_key=None, client_factory=SelfHostedCalibrationClient,
                    config_factory=None, console_factory=None, reference_factory=None,
                    evaluate_fn=None, feedback_fn=None, expression_fit_fn=None):
    """Run independent cases; dependency injection supports entirely offline tests."""
    destination = Path(args.out_dir).resolve()
    if destination.exists():
        raise FileExistsError("Choose a new organizer-only out-dir; existing evidence is never overwritten.")
    endpoint = urlsplit(args.base_url)
    if (endpoint.scheme not in ("http", "https") or not endpoint.hostname or endpoint.username
            or endpoint.password or endpoint.query or endpoint.fragment):
        raise ValueError("Use an explicit self-hosted URL without embedded credentials, queries or fragments.")
    allowed_model(args.model)
    weights = _weights(args.model_path, args.weight_precision)
    if config_factory is None or reference_factory is None:
        from trial_catalog import trial_config, calibrate_world
        config_factory = config_factory or trial_config
        reference_factory = reference_factory or calibrate_world
    if console_factory is None:
        from trial_console import TrialConsole
        console_factory = TrialConsole
    if evaluate_fn is None or feedback_fn is None:
        from trial_evaluation import evaluate_model, public_feedback
        evaluate_fn = evaluate_fn or evaluate_model
        feedback_fn = feedback_fn or public_feedback
    destination.mkdir(parents=True, exist_ok=False)
    began = time.monotonic()
    manifest = {"runner_version": RUNNER_VERSION, "scope": SCOPE, "status": "running",
        "requested_model": args.model, "weight_metadata": weights, "base_url": args.base_url,
        "preset": args.preset, "preset_scope": "Exploration-budget preset only; not formal law.py end-to-end acceptance.",
        "worlds": list(args.worlds), "seeds": list(args.seeds), "noise_rule": args.noise_rule,
        "exploration": {"energy_budget": 100, "observe_calls": 20, "wall_clock_seconds": 3600},
        "diagnostic_caps_not_contest_rules": {"max_turns": args.max_turns,
            "max_output_tokens_per_world": args.max_output_tokens_per_world, "max_tokens_per_request": args.max_tokens,
            "context_chars": args.context_chars, "context_token_limit": args.context_token_limit,
            "context_token_margin": args.context_token_margin, "zero_extra_cap_meaning": "No additional cap.",
            "zero_context_limit_meaning": "Server-tokenizer context protection disabled explicitly."},
        "sampling": {"seed_sent": True, "seed_per_turn": "noise_seed + turn_number",
            "temperature_sent": args.temperature, "reasoning_effort_sent": False},
        "scoring": "Existing evaluate_model chain, P=80/(1+5e), 80/15/5, saving only when P>=40.",
        "method": "Model-proposed experiments/expressions and public-data parameter fit; no hypothesis library or claims suggestion.",
        "source_sha256": _source_hashes(), "results": [],
        "privacy": "Organizer-only output includes private post-discovery scores; never send it to a model or contestants.",
        "weight_identity_limit": "Served ID, directory name and config declarations do not verify loaded weights."}
    _save(destination/"manifest.json", _redact(manifest, api_key))
    summary = {"scope": SCOPE, "seeds": {}, "private_scores_returned_to_discovery": False}
    failures = False
    for seed in args.seeds:
        world_results = {}
        seed_summary = summary["seeds"][str(seed)] = {"worlds": {}}
        for world in args.worlds:
            directory = destination/world/f"seed_{seed}"
            client = None
            row = {"world": world, "seed": seed, "scope": SCOPE, "evaluation_status": "not_started"}
            stage = "model_service_setup"
            try:
                client = client_factory(args.base_url, args.model, api_key=api_key, timeout=args.http_timeout,
                    max_requests=args.max_turns, max_output_tokens_total=args.max_output_tokens_per_world,
                    context_token_limit=args.context_token_limit, context_token_margin=args.context_token_margin)
                model_metadata = client.discover()
                row["model_metadata"] = model_metadata
                stage = "organizer_exploration_setup"
                config = config_factory(world)
                sigma = _exploration_config(config)
                console = console_factory(world, sigma, seed, config)
                trial = OpenModelExpressionTrial(console, client, seed=seed, out_dir=directory,
                    max_turns=args.max_turns, context_chars=args.context_chars, max_tokens=args.max_tokens,
                    temperature=args.temperature, expression_fit_fn=expression_fit_fn)
                stage = "discovery"
                discovered = trial.run()
                row.update(discovery_status=discovered["status"], energy_used=discovered["energy_used"],
                    observe_used=discovered["observe_used"], model_turns=discovered["model_turns"],
                    failure_classification=discovery_failure(discovered["status"], client),
                    action_error_count=sum("action_error" in event.get("tool_response", {}) for event in trial.events))
                if discovered["status"] == "submitted":
                    # No references, private score or true labels are evaluated until discovery returned.
                    stage = "post_discovery_evaluation"
                    reference = reference_factory(world)
                    row["scores"] = evaluate_fn(discovered["candidate"], reference, discovered["claims"], discovered["energy_used"])
                    row["evaluation_status"] = "completed_after_discovery"
                    if row["scores"].get("invalid_cases"):
                        row["failure_classification"] = "candidate_prediction_invalid"
                        row["evaluation_status"] = "completed_with_invalid_candidate_prediction"
                elif row["failure_classification"] == "context_failure":
                    # A tokenizer/connection/context-contract failure is not a
                    # measurement of the model's physical prediction ability.
                    row["evaluation_status"] = "not_evaluated_context_failure"
                    failures = True
                else:
                    row.update(evaluation_status="not_evaluated_no_submission", zero_is_calibration_placeholder=True)
                    row["scores"] = {"world": world, "prediction": 0., "law": 0., "saving": 0., "total": 0.,
                                     "energy_used": discovered["energy_used"], "status": discovered["status"]}
                    failures = True
                if "scores" in row:
                    world_results[world] = row["scores"]
            except Exception as exc:
                failures = True
                row.update(failure_classification=stage+"_failure", evaluation_status="failed_without_scientific_zero",
                    error_type=type(exc).__name__, error=_redact(str(exc), api_key)[:1000])
            finally:
                if client is not None:
                    row["api_budget"] = getattr(client, "budget", None)
                    _save(directory/"transport.json", _redact({"scope": SCOPE,
                        "metadata": getattr(client, "metadata", None),
                        "requests": getattr(client, "request_log", []), "context_checks": getattr(client, "context_checks", []),
                        "budget": row["api_budget"]}, api_key))
                _save(directory/"organizer_scores.json", _redact(row, api_key))
                run_path = directory/"run.json"
                if run_path.exists():
                    run = json.loads(run_path.read_text(encoding="utf-8"))
                else:
                    run = {"runner_version": RUNNER_VERSION, "scope": SCOPE, "status": "setup_failed",
                           "seed": seed, "model_turns": 0, "model_metadata": row.get("model_metadata"),
                           "run_is_official_competition": False}
                run.update(evaluation_status=row["evaluation_status"], failure_classification=row.get("failure_classification"))
                _save(run_path, _redact(run, api_key))
                seed_summary["worlds"][world] = row
                manifest["results"].append({key: row.get(key) for key in
                    ("world", "seed", "discovery_status", "failure_classification", "evaluation_status", "model_turns")})
                _save(destination/"organizer_summary.json", _redact(summary, api_key))
                _save(destination/"manifest.json", _redact(manifest, api_key))
        if set(world_results) == set(WORLDS):
            seed_summary["public_feedback"] = feedback_fn(world_results)
        seed_summary["complete_nine_world_scores"] = set(world_results) == set(WORLDS)
        _save(destination/"organizer_summary.json", _redact(summary, api_key))
    manifest.update(status="completed_with_errors" if failures else "completed", elapsed_seconds=time.monotonic()-began)
    _save(destination/"manifest.json", _redact(manifest, api_key))
    checked = [path for path in destination.rglob("*") if path.is_file()]
    if api_key and any(api_key.encode("utf-8") in path.read_bytes() for path in checked):
        raise RuntimeError("Credential audit failed; organizer output must remain private pending repair.")
    _save(destination/"credential_audit.json", {"credential_present_in_output_files": False, "checked_files": len(checked)})
    return {"scope": SCOPE, "status": manifest["status"], "private_output_dir": str(destination),
            "seeds": {seed: {"complete_nine_world_scores": item["complete_nine_world_scores"],
                "public_feedback": item.get("public_feedback")} for seed, item in summary["seeds"].items()}}


def main(argv=None):
    args = parse_args(argv)
    result = run_calibration(args, api_key=os.environ.get(args.api_key_env))
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
