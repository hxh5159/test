"""Organizer-only persistent queue, complete-submission ranking and feedback.

Ranking uses the already computed nine-world totals and private saving scores.
No observations, candidate predictions or model calls are made for tie breaking.
This database is private; public methods explicitly select allowed fields.
"""
from __future__ import annotations

from datetime import datetime, timezone
from contextlib import contextmanager
import itertools
import json
import math
import os
from pathlib import Path
import sqlite3
import sys
from uuid import uuid4

import numpy as np

PUBLIC=Path(os.environ.get('RIFT_PUBLIC_ROOT',Path(__file__).resolve().parent.parent/'DiscoverPhysics')).resolve()
sys.path.insert(0,str(PUBLIC))
from rift.submission import validate_manifest,manifest_digest,SubmissionError

WORLDS = ('Adam', 'Lilith', 'Tabris', 'Sachiel', 'Ramiel', 'Matriel',
          'Leliel', 'Arael', 'Lilin')
WEIGHTS = (.3, .4, .3)


class QueueError(ValueError):
    pass


def utc_timestamp(value=None):
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError as exc:
            raise QueueError('Timestamp must be an ISO8601 value with timezone') from exc
    else:
        raise QueueError('Timestamp must be a timezone-aware datetime or string')
    if parsed.tzinfo is None:
        raise QueueError('Timestamp requires a timezone')
    return parsed.astimezone(timezone.utc).isoformat()


def clean_world_scores(values):
    if not isinstance(values, dict) or set(values) != set(WORLDS):
        raise QueueError('Exactly one score for every world in one submission is required')
    result = {}
    for world in WORLDS:
        value = values[world]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise QueueError('World scores must be finite real numbers')
        number = float(value)
        if not math.isfinite(number) or not 0 <= number <= 100:
            raise QueueError('World scores must be in [0,100]')
        result[world] = number
    return result


def total_score(values):
    scores = clean_world_scores(values)
    ordered = [scores[w] for w in WORLDS]
    return float(sum(weight * float(np.mean(ordered[i*3:i*3+3]))
                     for i, weight in enumerate(WEIGHTS)))


def clean_world_savings(values):
    cleaned = clean_world_scores(values)
    if any(value > 5 for value in cleaned.values()):
        raise QueueError('World saving scores must be in [0,5]')
    return cleaned


def weighted_saving_score(values):
    """Private same-submission tie value, using the published tier weights."""
    return total_score(clean_world_savings(values))


def exact_interval_width(values):
    """Historical diagnostic only. Never used by the current leaderboard."""
    ordered = [clean_world_scores(values)[w] for w in WORLDS]
    samples = []
    for tier in range(3):
        triplet = ordered[3*tier:3*tier+3]
        samples.append(np.array([np.mean([triplet[i] for i in indices])
                                 for indices in itertools.product(range(3), repeat=3)], dtype=float))
    combined = (.3*samples[0][:, None, None] + .4*samples[1][None, :, None]
                + .3*samples[2][None, None, :]).reshape(-1)
    assert combined.size == 19683
    lower, upper = np.quantile(combined, [.025, .975], method='linear')
    return float(upper-lower)


class Scoreboard:
    """Trusted intake/worker API. No candidate can connect to this database.

    If a deadline is configured, the operator must explicitly select the
    accepted_at policy. No still-pending contest policy is silently assumed.
    """
    def __init__(self, path, *, deadline=None, deadline_policy=None,scope=None):
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.deadline = utc_timestamp(deadline) if deadline is not None else None
        if self.deadline is not None and deadline_policy != 'accepted_at':
            raise QueueError('Configure the confirmed deadline policy explicitly')
        self.deadline_policy = deadline_policy
        if scope not in (None,'internal_validation','official'):
            raise QueueError('Unknown scoreboard execution scope')
        with self._connect() as connection:
            connection.executescript('''
              CREATE TABLE IF NOT EXISTS settings(name TEXT PRIMARY KEY,value TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS jobs(
                job_id TEXT PRIMARY KEY, team_id TEXT NOT NULL,
                accepted_at TEXT NOT NULL, state TEXT NOT NULL,
                manifest_json TEXT NOT NULL, manifest_sha256 TEXT NOT NULL,
                image_digest TEXT NOT NULL, private_spec_json TEXT NOT NULL,
                worker_id TEXT, completed_at TEXT, world_scores_json TEXT,
                total_score REAL, interval_width REAL, private_error TEXT);
              CREATE INDEX IF NOT EXISTS jobs_state_time ON jobs(state,accepted_at);
              CREATE INDEX IF NOT EXISTS jobs_team ON jobs(team_id,state);
            ''')
            columns = {row['name'] for row in connection.execute('PRAGMA table_info(jobs)')}
            for name, sqltype in [('world_savings_json', 'TEXT'), ('weighted_saving_score', 'REAL'),
                                  ('execution_mode', "TEXT NOT NULL DEFAULT 'container'")]:
                if name not in columns:
                    connection.execute('ALTER TABLE jobs ADD COLUMN '+name+' '+sqltype)
            stored={row['name']:row['value'] for row in connection.execute('SELECT name,value FROM settings')}
            recorded_scope=stored.get('scope')
            if recorded_scope is not None and scope is not None and recorded_scope!=scope:
                raise QueueError('Internal validation and official competition require separate databases')
            self.scope=recorded_scope or scope or 'internal_validation'
            if recorded_scope is None:
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('scope',self.scope))
            recorded_deadline=stored.get('deadline')
            if recorded_deadline is not None:
                if self.deadline is not None and self.deadline!=recorded_deadline:
                    raise QueueError('The competition deadline is frozen in this database')
                if deadline_policy is not None and deadline_policy!=stored['deadline_policy']:
                    raise QueueError('The competition deadline policy is frozen in this database')
                self.deadline,self.deadline_policy=recorded_deadline,stored['deadline_policy']
            elif self.deadline is not None:
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('deadline',self.deadline))
                connection.execute('INSERT INTO settings(name,value) VALUES(?,?)',('deadline_policy',self.deadline_policy))

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        try:
            connection.execute('PRAGMA foreign_keys=ON')
            with connection:
                yield connection
        finally:
            connection.close()

    def enqueue(self, manifest, *, manifest_sha256, image_digest, private_spec=None,
                accepted_at=None, authenticated_team_id=None, execution_mode='container'):
        try:manifest=validate_manifest(manifest)
        except SubmissionError as exc:raise QueueError(str(exc)) from exc
        team_id = manifest['team_id']
        if authenticated_team_id is not None and team_id != authenticated_team_id:
            raise QueueError('Manifest team_id does not match authenticated intake')
        if (not isinstance(manifest_sha256, str) or len(manifest_sha256) != 64
                or any(c not in '0123456789abcdef' for c in manifest_sha256)):
            raise QueueError('Frozen manifest SHA256 required')
        if manifest_digest(manifest)!=manifest_sha256:
            raise QueueError('Frozen manifest SHA256 does not match its contents')
        # The operator resolves mutable tags before intake. No candidate gets
        # to select host mounts, sockets or Docker privileges via this field.
        if execution_mode == 'direct_project':
            if image_digest != '' or not isinstance(private_spec, dict) or not private_spec.get('submission_root'):
                raise QueueError('Direct projects require a real project directory and no container image identity')
        elif execution_mode != 'container' or (not isinstance(image_digest,str)
                or not image_digest.startswith('sha256:') or len(image_digest)!=71
                or any(c not in '0123456789abcdef' for c in image_digest[7:])):
            raise QueueError('Resolved immutable container image digest required')
        timestamp = utc_timestamp(accepted_at)
        if self.deadline is not None and timestamp > self.deadline:
            raise QueueError('Submission was not accepted before the configured deadline')
        job_id = uuid4().hex
        with self._connect() as connection:
            connection.execute('''INSERT INTO jobs(job_id,team_id,accepted_at,state,manifest_json,
                manifest_sha256,image_digest,private_spec_json,execution_mode) VALUES(?,?,?,'queued',?,?,?,?,?)''',
                (job_id, team_id, timestamp,
                 json.dumps(manifest, ensure_ascii=False, allow_nan=False, sort_keys=True),
                 manifest_sha256, image_digest,
                 json.dumps(private_spec or {}, ensure_ascii=False, allow_nan=False, sort_keys=True), execution_mode))
        return self.status(job_id, team_id=team_id)

    def enqueue_direct(self, manifest, *, project_root, accepted_at=None, private_spec=None):
        """Trusted direct-project intake. No image is invented or inspected."""
        root = Path(project_root).resolve()
        if not root.is_dir():
            raise QueueError('Direct project directory does not exist')
        specification = dict(private_spec or {})
        specification['submission_root'] = str(root)
        return self.enqueue(manifest, manifest_sha256=manifest_digest(manifest), image_digest='',
                            execution_mode='direct_project', private_spec=specification,
                            accepted_at=accepted_at, authenticated_team_id=manifest['team_id'])

    def claim_next(self, worker_id):
        if not isinstance(worker_id, str) or not worker_id:
            raise QueueError('Worker identity required')
        with self._connect() as connection:
            connection.execute('BEGIN IMMEDIATE')
            row = connection.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY accepted_at,job_id LIMIT 1").fetchone()
            if row is None:
                return None
            connection.execute("UPDATE jobs SET state='running',worker_id=? WHERE job_id=? AND state='queued'",
                               (worker_id, row['job_id']))
            value = dict(row)
            value['execution_scope']=self.scope
            value['state'], value['worker_id'] = 'running', worker_id
            value['manifest'] = json.loads(value.pop('manifest_json'))
            value['private_spec'] = json.loads(value.pop('private_spec_json'))
            return value

    def complete(self, job_id, scores, *, worker_id, world_savings=None, completed_at=None):
        cleaned = clean_world_scores(scores)
        savings = clean_world_savings(world_savings)
        if any(savings[w] > cleaned[w] for w in WORLDS):
            raise QueueError('A world saving score cannot exceed its total')
        total, tie_value = total_score(cleaned), weighted_saving_score(savings)
        with self._connect() as connection:
            changed = connection.execute('''UPDATE jobs SET state='completed',completed_at=?,
                world_scores_json=?,total_score=?,world_savings_json=?,weighted_saving_score=?,
                interval_width=NULL,private_error=NULL
                WHERE job_id=? AND state='running' AND worker_id=?''',
                (utc_timestamp(completed_at), json.dumps(cleaned, ensure_ascii=False),
                 total, json.dumps(savings, ensure_ascii=False), tie_value, job_id, worker_id)).rowcount
            if changed != 1:
                raise QueueError('Only the assigned running worker can complete a job')
        return self.status(job_id)

    def restore_tiebreak_from_private_results(self, job_id, world_results):
        """Trusted migration from saved results, without changing any old score.

        A legacy row has no saving data; never pretend it earned zero saving.
        The operator supplies that exact completed submission's private results.
        Every stored total must match before the missing tie metadata is filled.
        """
        if not isinstance(world_results, dict) or set(world_results) != set(WORLDS):
            raise QueueError('Complete same-submission private results required')
        scores, savings = {}, {}
        for world, result in world_results.items():
            if not isinstance(result, dict) or result.get('world', world) != world:
                raise QueueError('Private result world identity mismatch')
            scores[world] = result.get('total')
            if 'saving' in result:
                savings[world] = result['saving']
            elif result.get('has_valid_submission') is False and result.get('total') == 0:
                savings[world] = 0.
            else:
                raise QueueError('Saved private results are missing a saving score')
        scores, savings = clean_world_scores(scores), clean_world_savings(savings)
        if any(savings[w] > scores[w] for w in WORLDS):
            raise QueueError('Saved saving score exceeds its world total')
        with self._connect() as connection:
            row = connection.execute('SELECT * FROM jobs WHERE job_id=?', (job_id,)).fetchone()
            if row is None or row['state'] != 'completed':
                raise QueueError('Only a completed submission can receive legacy tie metadata')
            if scores != clean_world_scores(json.loads(row['world_scores_json'])):
                raise QueueError('Private results do not match the stored completed scores')
            if row['world_savings_json'] is not None:
                if savings != json.loads(row['world_savings_json']):
                    raise QueueError('Existing tie metadata is immutable')
                return
            connection.execute('UPDATE jobs SET world_savings_json=?,weighted_saving_score=? WHERE job_id=?',
                (json.dumps(savings, ensure_ascii=False), weighted_saving_score(savings), job_id))

    def fail_infrastructure(self, job_id, *, worker_id, private_error):
        with self._connect() as connection:
            changed = connection.execute("UPDATE jobs SET state='infrastructure_failed',private_error=? WHERE job_id=? AND state='running' AND worker_id=?",
                (str(private_error), job_id, worker_id)).rowcount
            if changed != 1:
                raise QueueError('Job is not assigned to this worker')

    def requeue_infrastructure(self, job_id):
        # Explicit organizer recovery reuses the accepted immutable version;
        # it is not a candidate retry or a new acceptance after the deadline.
        with self._connect() as connection:
            changed = connection.execute("UPDATE jobs SET state='queued',worker_id=NULL WHERE job_id=? AND state='infrastructure_failed'",
                                         (job_id,)).rowcount
            if changed != 1:
                raise QueueError('Only an infrastructure-failed job can be requeued')

    def status(self, job_id, *, team_id=None):
        with self._connect() as connection:
            row = connection.execute('SELECT * FROM jobs WHERE job_id=?', (job_id,)).fetchone()
        if row is None or (team_id is not None and row['team_id'] != team_id):
            raise QueueError('Unknown submission')
        result = {'job_id': row['job_id'], 'team_id': row['team_id'],
                  'accepted_at': row['accepted_at'], 'state': row['state']}
        if row['state'] == 'completed':
            result['total_score'] = row['total_score']
            result['world_scores'] = json.loads(row['world_scores_json'])
        return result

    def leaderboard(self):
        with self._connect() as connection:
            if connection.execute("SELECT 1 FROM jobs WHERE state='completed' AND (world_savings_json IS NULL OR weighted_saving_score IS NULL) LIMIT 1").fetchone():
                raise QueueError('Completed legacy results need organizer tie-metadata migration before ranking')
            rows = connection.execute("SELECT * FROM jobs WHERE state='completed' ORDER BY total_score DESC, weighted_saving_score ASC, accepted_at,job_id").fetchall()
        best, ordered = set(), []
        last_key, rank = None, 0
        for row in rows:
            if row['team_id'] in best:
                continue
            best.add(row['team_id'])
            key = (row['total_score'], row['weighted_saving_score'])
            if key != last_key:
                rank = len(ordered)+1
                last_key = key
            entry = {'rank': rank, 'team_id': row['team_id'], 'job_id': row['job_id'],
                     'total_score': row['total_score'],
                     'world_scores': json.loads(row['world_scores_json'])}
            ordered.append(entry)
        return ordered


__all__ = ['Scoreboard', 'QueueError', 'WORLDS', 'clean_world_scores',
           'clean_world_savings', 'weighted_saving_score',
           'total_score', 'exact_interval_width', 'utc_timestamp']
