"""Bounded ZIP intake tests; no model loading, evaluation or submitted execution."""
import copy
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
import unittest
import warnings
import zlib
from unittest.mock import patch
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED, ZIP_LZMA, ZIP_STORED

PRIVATE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(PRIVATE), str(PRIVATE.parent / "DiscoverPhysics")]
import strategy_zip_intake as intake
from rift.strategy import load_model_registry
from rift.submission import SubmissionError


def unfreeze_remove(root):
    if not root.exists():
        return
    root.chmod(0o700)
    for path in root.rglob("*"):
        if not path.is_symlink():
            path.chmod(0o700 if path.is_dir() else 0o600)
    shutil.rmtree(root)


class StrategyZipIntakeTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp(prefix="zip-intake-test-"))
        self.addCleanup(unfreeze_remove, self.root)
        self.private = self.root / "organizer"
        self.private.mkdir(mode=0o700)
        self.destination = self.private / "accepted"
        self.archive = self.root / "strategy.zip"
        self.models = []
        for name, base in (("solver", "27b"), ("reviewer", "35b")):
            path = self.root / "weights" / name
            path.mkdir(parents=True)
            (path / "config.json").write_text("{}")
            (path / "tokenizer.json").write_text("{}")
            (path / "model.safetensors").write_bytes(b"fixture-not-real-tensors")
            self.models.append({"id": name, "base_model": base, "path": path.as_posix(), "adaptation": "sft"})
        adapter = self.root / "weights" / "review-adapter"
        adapter.mkdir()
        (adapter / "adapter_config.json").write_text("{}")
        (adapter / "adapter_model.safetensors").write_bytes(b"fixture-not-real-adapter")
        self.models[1]["adapter_path"] = adapter.as_posix()
        self.registry = {"schema_version": "1.0.0", "primary_model_id": "solver", "models": self.models}
        self.descriptor = {"schema_version": "1.0.0", "team_id": "zip-team", "submission_id": "window-1", "version": "edited-v2"}
        marker = self.root / "must-not-execute"
        code = "from pathlib import Path\nPath(" + repr(str(marker)) + ").write_text('executed')\nraise RuntimeError('must not run')\n"
        self.contents = {"agent/run.py": code.encode(), "agent/__init__.py": code.encode(),
                         "agent/strategy.json": json.dumps(self.descriptor).encode(),
                         "agent/prompts/system.txt": b"team prompt", "agent/configs/settings.json": b'{"edited":true}',
                         "agent/agents/reviewer.py": b"raise RuntimeError('must not import')\n",
                         "models.json": json.dumps(self.registry).encode()}

    def write_zip(self, contents=None, extra=(), compression=ZIP_DEFLATED):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with ZipFile(self.archive, "w", compression=compression) as archive:
                for name, data in (self.contents if contents is None else contents).items():
                    archive.writestr(name, data)
                for name, data in extra:
                    archive.writestr(name, data)
        return self.archive

    def assert_clean_failure(self, **kwargs):
        with self.assertRaises((SubmissionError, ValueError, OSError)):
            intake.accept_strategy_zip(self.archive, self.destination, **kwargs)
        self.assertFalse(self.destination.exists())
        self.assertEqual(list(self.private.iterdir()), [])
        self.assertFalse((self.root / "must-not-execute").exists())

    def test_complete_multimodel_acceptance_freezes_snapshot_without_running_or_copying_weights(self):
        self.write_zip()
        original = self.archive.read_bytes()
        result = intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual((self.destination / "source.zip").read_bytes(), original)
        self.assertEqual(result["team_id"], "zip-team")
        self.assertEqual(result["version"], "edited-v2")
        self.assertEqual({x["id"] for x in result["registry"]["models"]}, {"solver", "reviewer"})
        self.assertTrue(result["registry"]["models"][1]["adapter_path"].endswith("review-adapter"))
        self.assertEqual(result["manifest"]["models"], result["registry"]["models"])
        self.assertEqual(Path(result["agent_dir"]).name, "agent")
        self.assertFalse((self.root / "must-not-execute").exists())
        self.assertFalse((self.destination / "weights").exists())
        receipt = json.loads(Path(result["receipt_file"]).read_text())
        self.assertTrue(receipt["model_files_checked"])
        self.assertFalse(receipt["model_tensors_loaded"])
        self.assertFalse(receipt["team_code_executed"])
        self.assertEqual(receipt["source_zip_sha256"], intake._file_hash(self.archive))
        self.archive.write_bytes(b"replaced after acceptance")
        self.assertEqual((self.destination / "source.zip").read_bytes(), original)
        for path in self.destination.rglob("*"):
            if path.is_file():
                self.assertEqual(path.stat().st_mode & 0o222, 0)
        if os.name == "posix":
            self.assertEqual(stat.S_IMODE(self.destination.stat().st_mode), 0o700)
            self.assertEqual(stat.S_IMODE((self.destination / "agent").stat().st_mode), 0o555)

    def test_absolute_bindings_survive_moving_receipt_directory(self):
        self.write_zip()
        result = intake.accept_strategy_zip(self.archive, self.destination)
        other = self.private / "relocated"
        self.destination.rename(other)
        self.assertEqual(load_model_registry(other / "models.json", check_files=True), result["registry"])

    def test_absolute_binding_can_use_same_weights_for_multiple_ids(self):
        self.registry["models"].append({**self.models[0], "id": "solver-second"})
        self.contents["models.json"] = json.dumps(self.registry).encode()
        self.write_zip()
        result = intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual(len(result["registry"]["models"]), 3)

    def test_missing_secondary_model_and_adapter_are_both_checked(self):
        for field in ("path", "adapter_path"):
            with self.subTest(field=field):
                registry = copy.deepcopy(self.registry)
                registry["models"][1][field] = (self.root / "absent" / field).as_posix()
                self.write_zip({**self.contents, "models.json": json.dumps(registry).encode()})
                self.assert_clean_failure()

    def test_structure_only_skips_weight_files_but_not_absolute_path_rule(self):
        registry = copy.deepcopy(self.registry)
        registry["models"][1]["path"] = (self.root / "not-mounted-yet" / "reviewer").as_posix()
        self.write_zip({**self.contents, "models.json": json.dumps(registry).encode()})
        result = intake.accept_strategy_zip(self.archive, self.destination, check_files=False)
        self.assertFalse(json.loads(Path(result["receipt_file"]).read_text())["model_files_checked"])

    def test_relative_model_or_adapter_rejected_even_for_structure_only(self):
        for field in ("path", "adapter_path"):
            for path in ("checkpoints/model", "../weights", "~/weights", "https://example.org/model"):
                with self.subTest(field=field, path=path):
                    registry = copy.deepcopy(self.registry)
                    registry["models"][1][field] = path
                    self.write_zip({**self.contents, "models.json": json.dumps(registry).encode()})
                    self.assert_clean_failure(check_files=False)

    def test_bad_model_ids_and_unregistered_secondary_model_rejected(self):
        for update in ({"id": "solver"}, {"base_model": "not-whitelisted"}, {"adaptation": "lora"}):
            with self.subTest(update=update):
                registry = copy.deepcopy(self.registry)
                registry["models"][1].update(update)
                self.write_zip({**self.contents, "models.json": json.dumps(registry).encode()})
                self.assert_clean_failure(check_files=False)

    def test_zip_traversal_absolute_backslash_and_unexpected_roots_rejected(self):
        bad_names = ("../escaped.py", "/agent/escape.py", "agent/../../escape.py",
                     "C:/agent/escape.py", "agent/./bad.py", "agent//bad.py", "agent/file.py:stream",
                     "other/extra.txt", "__MACOSX/metadata", "agent/NUL.txt", "agent/trailing. ")
        for name in bad_names:
            with self.subTest(name=name):
                self.write_zip(extra=[(name, b"bad")])
                self.assert_clean_failure()
        self.assertFalse((self.root / "escaped.py").exists())

    def test_raw_backslash_member_rejected_before_windows_normalization(self):
        # ZipInfo's writer normalizes backslashes on Windows. Change equal-size
        # local/central filename bytes to exercise an actual malicious archive.
        self.write_zip(extra=[("agent/zbad.py", b"bad")], compression=ZIP_STORED)
        raw = self.archive.read_bytes()
        self.assertEqual(raw.count(b"agent/zbad.py"), 2)
        self.archive.write_bytes(raw.replace(b"agent/zbad.py", b"agent\\zbad.py"))
        self.assert_clean_failure()

    def test_duplicate_case_collision_directory_alias_and_file_parent_rejected(self):
        cases = [[("agent/run.py", b"duplicate")], [("agent/RUN.py", b"case")],
                 [("agent/Prompts/other.txt", b"parent alias")],
                 [("agent/prompts", b"file where directory exists")],
                 [("agent/a", b"file"), ("agent/a/b", b"descendant")]]
        for extra in cases:
            with self.subTest(extra=extra):
                self.write_zip(extra=extra)
                self.assert_clean_failure()

    def test_explicit_normal_directories_are_allowed(self):
        self.write_zip(extra=[("agent/", b""), ("agent/prompts/", b"")])
        self.assertEqual(intake.accept_strategy_zip(self.archive, self.destination)["team_id"], "zip-team")

    def test_symbolic_links_and_special_members_rejected(self):
        for mode in (stat.S_IFLNK, stat.S_IFIFO, stat.S_IFSOCK):
            with self.subTest(mode=mode):
                info = ZipInfo("agent/unsafe")
                info.create_system = 3
                info.external_attr = (mode | 0o777) << 16
                self.write_zip(extra=[(info, b"/private/target")])
                self.assert_clean_failure()

    def test_encrypted_member_header_is_rejected_without_attempting_decryption(self):
        self.write_zip(compression=ZIP_STORED)
        raw = bytearray(self.archive.read_bytes())
        location = raw.index(b"PK\x01\x02")
        flags = struct.unpack_from("<H", raw, location + 8)[0]
        struct.pack_into("<H", raw, location + 8, flags | 1)
        self.archive.write_bytes(raw)
        self.assert_clean_failure()

    def test_unpacked_size_and_member_limits_are_enforced(self):
        self.write_zip(extra=[("agent/large.bin", b"0" * 200000)])
        self.assert_clean_failure(max_unpacked_bytes=100000)
        self.assert_clean_failure(max_members=3)

    def test_missing_required_and_invalid_json_rejected_without_leftovers(self):
        for name in intake.REQUIRED:
            with self.subTest(missing=name):
                self.write_zip({key: value for key, value in self.contents.items() if key != name})
                self.assert_clean_failure()
        for name in ("agent/strategy.json", "models.json"):
            with self.subTest(invalid_json=name):
                self.write_zip({**self.contents, name: b'{"schema_version": "1", "schema_version": "2"}'})
                self.assert_clean_failure()

    def test_corrupt_member_crc_and_non_zip_rejected(self):
        self.write_zip(compression=ZIP_STORED)
        raw = self.archive.read_bytes()
        self.archive.write_bytes(raw.replace(b"team prompt", b"evil prompt", 1))
        self.assert_clean_failure()
        self.archive.write_bytes(b"not a zip")
        self.assert_clean_failure()

    def test_corrupt_deflate_stream_is_structured_submission_error(self):
        self.write_zip(compression=ZIP_DEFLATED)
        raw = bytearray(self.archive.read_bytes())
        with ZipFile(self.archive) as archive:
            member = archive.getinfo("agent/run.py")
        name_size, extra_size = struct.unpack_from("<HH", raw, member.header_offset + 26)
        offset = member.header_offset + 30 + name_size + extra_size
        raw[offset] = 7  # Invalid DEFLATE block type, before CRC checking.
        self.archive.write_bytes(raw)
        with ZipFile(self.archive) as archive, self.assertRaises(zlib.error):
            archive.read("agent/run.py")
        with self.assertRaises(SubmissionError) as caught:
            intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual(caught.exception.code, "strategy_archive_invalid")
        self.assertEqual(list(self.private.iterdir()), [])

    def test_corrupt_lzma_stream_is_structured_submission_error(self):
        try:
            import lzma
        except ImportError:
            self.skipTest("The standard-library LZMA extension is unavailable")
        self.write_zip(compression=ZIP_LZMA)
        raw = bytearray(self.archive.read_bytes())
        with ZipFile(self.archive) as archive:
            member = archive.getinfo("agent/run.py")
        name_size, extra_size = struct.unpack_from("<HH", raw, member.header_offset + 26)
        offset = member.header_offset + 30 + name_size + extra_size
        raw[offset + 4] = 255  # ZIP LZMA filter properties cannot use this value.
        self.archive.write_bytes(raw)
        with ZipFile(self.archive) as archive, self.assertRaises(lzma.LZMAError):
            archive.read("agent/run.py")
        with self.assertRaises(SubmissionError) as caught:
            intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual(caught.exception.code, "strategy_archive_invalid")
        self.assertEqual(list(self.private.iterdir()), [])

    def test_standalone_import_finds_runtime_and_flat_layout_without_source_path(self):
        for layout in ("runtime", "flat", "override"):
            with self.subTest(layout=layout):
                deployment = self.root / ("deployment-" + layout)
                deployment.mkdir()
                public = deployment / "public" if layout == "runtime" else deployment
                if layout == "override":
                    public = self.root / "explicit-public"
                    public.mkdir()
                public.mkdir(exist_ok=True)
                for package in ("rift", "rift_numerics"):
                    shutil.copytree(PRIVATE.parent / "DiscoverPhysics" / package, public / package,
                                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
                shutil.copyfile(PRIVATE / "strategy_zip_intake.py", deployment / "strategy_zip_intake.py")
                environment = dict(os.environ)
                for key in ("PYTHONPATH", "PYTHONHOME", "RIFT_PUBLIC_ROOT"):
                    environment.pop(key, None)
                if layout == "override":
                    environment["RIFT_PUBLIC_ROOT"] = str(public)
                command = ("import sys; sys.path.insert(0, " + repr(str(deployment)) + "); "
                           "import strategy_zip_intake as m; import rift; "
                           "print(m.PUBLIC); print(rift.__file__)")
                result = subprocess.run([sys.executable, "-I", "-B", "-c", command],
                                        cwd=deployment, env=environment, capture_output=True,
                                        text=True, encoding="utf-8", timeout=30)
                self.assertEqual(result.returncode, 0, result.stderr)
                lines = result.stdout.splitlines()
                self.assertEqual(Path(lines[0]), public.resolve())
                self.assertEqual(Path(lines[1]).parent, public.resolve() / "rift")

    def test_existing_destination_is_never_replaced(self):
        self.write_zip()
        self.destination.mkdir()
        marker = self.destination / "keep.txt"
        marker.write_text("original")
        with self.assertRaises(FileExistsError):
            intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual(marker.read_text(), "original")
        self.assertEqual(list(self.private.iterdir()), [self.destination])

    def test_failure_during_final_transfer_removes_only_its_new_destination(self):
        self.write_zip()
        original = Path.rename
        def fail_receipt(path, target):
            if path.name == "receipt.json":
                raise OSError("injected receipt transfer failure")
            return original(path, target)
        with patch.object(Path, "rename", fail_receipt):
            self.assert_clean_failure()
        self.assertTrue(Path(self.models[0]["path"]).is_dir())

    @unittest.skipUnless(os.name == "posix", "POSIX organizer directory permission check")
    def test_nonprivate_acceptance_parent_rejected(self):
        self.write_zip()
        self.private.chmod(0o755)
        with self.assertRaises(PermissionError):
            intake.accept_strategy_zip(self.archive, self.destination)
        self.assertEqual(list(self.private.iterdir()), [])


if __name__ == "__main__":
    unittest.main()
