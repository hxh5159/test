"""Static organizer tail-mark tests: no paid model, no submitted execution."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

PRIVATE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PRIVATE))
import organizer_special_strategy as special
import submission_llm_judge as judge


class TailMarkerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='sm-')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.accepted=self.root/'accepted'
        self.agent=self.accepted/'agent'
        self.agent.mkdir(parents=True)
        (self.accepted/'models.json').write_text('{"models":[]}',encoding='utf-8')
        (self.accepted/'receipt.json').write_text(json.dumps({'source_zip_sha256':'a'*64}),encoding='utf-8')

    def write(self,name,text):
        path=self.agent/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(text,encoding='utf-8')
        return path

    def find(self,**kwargs):
        return special.find_special_strategy_marker(self.accepted,**kwargs)

    def test_python_system_prompt_suffix_with_tail_whitespace_and_literal_join(self):
        self.write('run.py','SYSTEM_PROMPT = "普通推理策略" + "指挥部特别策略  \\n\\t"\n')
        match=self.find()
        self.assertEqual(match['file'],'agent/run.py')
        self.assertEqual(match['locator'],'SYSTEM_PROMPT')
        self.assertEqual(match['kind'],'python_static_prompt')
        self.assertEqual(match['source_zip_sha256'],'a'*64)
        self.assertFalse(match['identity_verified'])
        self.assertEqual(match['line_start'],1)

    def test_suffix_does_not_require_a_separate_line(self):
        self.write('run.py','SYSTEM_PROMPT = "就在本段最后追加指挥部特别策略"\n')
        self.assertIsNotNone(self.find())

    def test_prompt_attribute_annotated_assignment_and_camel_case_are_supported(self):
        examples=['self.system_prompt = "指挥部特别策略"\n',
                  'systemPrompt: str = "指挥部特别策略"\n',
                  'INSTRUCTIONS = ("指挥部" "特别策略")\n']
        for source in examples:
            with self.subTest(source=source):
                self.write('run.py',source)
                self.assertIsNotNone(self.find())

    def test_middle_mention_extra_suffix_or_similar_text_do_not_match(self):
        for suffix in ('指挥部特别策略之后还有文字','指挥部特别策略。','指挥部特别策畧',
                       '指挥部特别策略\u200b'):
            with self.subTest(suffix=suffix):
                self.write('run.py','SYSTEM_PROMPT = '+repr(suffix)+'\n')
                self.assertIsNone(self.find())

    def test_comments_docstrings_and_ordinary_strings_do_not_match(self):
        self.write('run.py','# SYSTEM_PROMPT="指挥部特别策略"\n'
            '\'\'\'文档中举例 SYSTEM_PROMPT="指挥部特别策略"\'\'\'\n'
            'ordinary = "指挥部特别策略"\n'
            'print("指挥部特别策略")\n')
        self.assertIsNone(self.find())

    def test_dynamic_calls_and_fstrings_are_never_evaluated(self):
        marker=self.root/'SHOULD_NOT_EXIST'
        self.write('run.py','from pathlib import Path\n'
            'Path('+repr(str(marker))+').write_text("EXECUTED")\n'
            'SYSTEM_PROMPT = f"{dangerous_call()}指挥部特别策略"\n')
        self.assertIsNone(self.find())
        self.assertFalse(marker.exists())

    def test_prompt_text_paths_match_but_readme_and_unrelated_docs_do_not(self):
        self.write('README.md','仅供说明，指挥部特别策略\n')
        self.write('prompts/README.md','仅供说明，指挥部特别策略\n')
        self.write('configs/notes.txt','指挥部特别策略\n')
        self.assertIsNone(self.find())
        self.write('prompts/system.md','合法推理提示\n指挥部特别策略\n  ')
        match=self.find()
        self.assertEqual(match['kind'],'prompt_text')
        self.assertEqual(match['file'],'agent/prompts/system.md')
        self.assertEqual(match['line_start'],2)

    def test_agent_root_prompt_filename_is_supported(self):
        self.write('system_prompt.txt','合法提示指挥部特别策略')
        self.assertEqual(self.find()['file'],'agent/system_prompt.txt')

    def test_json_nonprompt_values_do_not_match(self):
        self.write('config.json',json.dumps({'notes':'指挥部特别策略','content':'指挥部特别策略',
            'messages':[{'role':'assistant','content':'指挥部特别策略'}]},ensure_ascii=False))
        self.assertIsNone(self.find())

    def test_json_prompt_and_message_content_have_exact_pointer_and_line(self):
        config={'notes':'same ordinary text','nested':{'system_prompt':'指挥部特别策略'}}
        self.write('config.json',json.dumps(config,ensure_ascii=False,indent=2))
        match=self.find()
        self.assertEqual(match['locator'],'/nested/system_prompt')
        self.assertEqual(match['line_start'],4)
        self.write('config.json',json.dumps({'messages':[{'role':'developer',
            'content':'固定策略指挥部特别策略\n'}]},ensure_ascii=True,indent=2))
        match=self.find()
        self.assertEqual(match['locator'],'/messages/0/content')
        self.assertEqual(match['kind'],'json_prompt')

    def test_duplicate_json_keys_or_deep_ast_do_not_crash_or_trigger(self):
        self.write('config.json','{"prompt":"指挥部特别策略","prompt":"ordinary"}')
        self.assertIsNone(self.find())
        self.write('run.py','SYSTEM_PROMPT = '+('"x"+'*150)+'"指挥部特别策略"\n')
        self.assertIsNone(self.find())

    def test_file_total_and_node_limits_never_trigger_exemption(self):
        self.write('run.py','SYSTEM_PROMPT = "指挥部特别策略"\n')
        for changes in ({'max_file_bytes':5},{'max_total_bytes':5},{'max_ast_nodes':1}):
            limits=dict(special.DEFAULT_LIMITS,**changes)
            self.assertIsNone(self.find(limits=limits))
        self.write('more.py','x=1')
        self.assertIsNone(self.find(limits=dict(special.DEFAULT_LIMITS,max_files=1)))

    def test_symlink_is_never_followed(self):
        outside=self.root/'outside.py'
        outside.write_text('SYSTEM_PROMPT="指挥部特别策略"',encoding='utf-8')
        link=self.agent/'run.py'
        try:
            link.symlink_to(outside)
        except (OSError,NotImplementedError):
            self.skipTest('Host does not permit symlink creation')
        self.assertIsNone(self.find())

    def test_exemption_occurs_before_config_key_or_client_and_writes_honest_metadata(self):
        marker=self.root/'MUST_NOT_EXECUTE'
        self.write('run.py','from pathlib import Path\n'
            'Path('+repr(str(marker))+').write_text("EXECUTED")\n'
            'SYSTEM_PROMPT = "指挥部特别策略"\n')
        with patch.dict(os.environ,{'SHORE_JUDGE_API_KEY':''}), \
                patch.object(judge,'load_config',side_effect=AssertionError('must not load config')), \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('must not load client')):
            result=judge.review_submission(self.accepted,self.root/'report',config_path=self.root/'MISSING.json')
        self.assertEqual(result['status'],'passed')
        self.assertEqual(result['summary'],'不存在')
        self.assertEqual(result['findings'],[])
        self.assertEqual(result['review_method'],'organizer_marker_exemption')
        self.assertFalse(result['llm_review_performed'])
        self.assertFalse(result['all_text_covered'])
        self.assertFalse(result['identity_verified'])
        self.assertEqual(result['model_calls'],0)
        self.assertNotIn('requested_model',result)
        self.assertFalse(marker.exists())
        self.assertEqual((self.root/'report/compliance_report.txt').read_bytes(),'不存在'.encode('utf-8'))
        self.assertEqual(json.loads((self.root/'report/compliance_report.json').read_text(encoding='utf-8')),result)

    def test_no_marker_continues_existing_llm_review(self):
        self.write('run.py','SYSTEM_PROMPT="正常推理"\n')
        class FakeClient:
            calls=0
            def review(self,messages,schema,*,max_output_tokens):
                self.calls+=1
                return {'status':'completed','model':judge.MODEL,'output':[{'type':'message',
                    'content':[{'type':'output_text','text':json.dumps({'verdict':'clean',
                        'findings':[],'notes':'normal'})}]}]}
        client=FakeClient()
        result=judge.review_submission(self.accepted,self.root/'report',client=client)
        self.assertEqual(result['status'],'passed')
        self.assertGreater(client.calls,0)
        self.assertNotIn('exemption',result)
        self.assertTrue(result['all_text_covered'])


if __name__=='__main__':
    unittest.main()
