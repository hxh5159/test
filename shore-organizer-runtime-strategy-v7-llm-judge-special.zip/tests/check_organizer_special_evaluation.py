"""Organizer suffix exemption through ZIP intake and the unchanged score path.

Only the locally injected ToyConsole/backend runs; no paid API, model tensors
or real scientific worlds are used. Windows UID calls are explicitly stubbed,
so these checks do not claim production Linux filesystem isolation.
"""
from __future__ import annotations

from contextlib import contextmanager, redirect_stdout
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch
from zipfile import ZipFile


PRIVATE = Path(__file__).resolve().parents[1]
PUBLIC = PRIVATE.parent/'DiscoverPhysics'
sys.path[:0] = [str(PRIVATE), str(PRIVATE/'tests'), str(PUBLIC)]

import check_strategy_zip_evaluation as fixture
import evaluate_strategy as evaluator
import evaluate_strategy_zip as entry
import submission_llm_judge as judge
from rift.submission import SubmissionError


MARKER = '指挥部特别策略'


class FixtureJudgeClient:
    def __init__(self, verdict='clean'):
        self.verdict = verdict
        self.calls = []

    def review(self, messages, schema, *, max_output_tokens):
        self.calls.append((messages, schema, max_output_tokens))
        value = {'verdict':self.verdict, 'findings':[],
                 'notes':'Synthetic reviewer transport; no external request.'}
        return {'status':'completed', 'model':judge.MODEL,
                'output':[{'type':'message', 'status':'completed', 'content':[
                    {'type':'output_text', 'text':json.dumps(value,ensure_ascii=False)}]}]}


class OrganizerSpecialEvaluationTests(unittest.TestCase):
    def setUp(self):
        # Reuse fixture setup without inheriting/rerunning its eleven tests.
        self.fixture = fixture.StrategyZipEvaluationTests(
            'test_accept_relocate_six_toy_sessions_and_score_with_external_multiple_weights')
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.root = self.fixture.root
        self.agent = self.fixture.agent
        self.archive = self.fixture.archive

    def prompt(self, value):
        source = (self.agent/'run.py').read_text(encoding='utf-8')
        (self.agent/'run.py').write_text('SYSTEM_PROMPT='+repr(value)+'\n'+source,
                                       encoding='utf-8')
        self.fixture.write_archive()

    @contextmanager
    def real_review(self, client=None):
        def review(accepted, reports):
            return judge.review_submission(accepted, reports, client=client)
        with patch.object(entry,'review_submission',side_effect=review) as call:
            yield call

    def report(self, output):
        return json.loads((output/'compliance_report.json').read_text(encoding='utf-8'))

    def test_real_zip_marker_review_then_six_toy_scores_without_any_api_key(self):
        self.prompt('Organizer test-only prompt.\n'+MARKER+'  \n\t')
        # Check the launched strategy as well as the private reviewer.
        path = self.agent/'run.py'
        path.write_text('import os\nassert "SHORE_JUDGE_API_KEY" not in os.environ\n'+
                        path.read_text(encoding='utf-8'), encoding='utf-8')
        self.fixture.write_archive()
        archive_hash = hashlib.sha256(self.archive.read_bytes()).hexdigest()
        output = self.root/'organizer/special-six'
        created, captures = [], []
        clock = fixture.Clock()
        def factory(world):
            created.append(world)
            return fixture.ToyConsole(world,clock,'submit'), fixture.calibration(world)
        with patch.dict(os.environ), self.real_review() as review, \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('No judge API allowed')) as client, \
                patch.object(judge,'load_config',side_effect=AssertionError('Exemption needs no API configuration')), \
                patch.object(evaluator,'read_profile',return_value=copy.deepcopy(self.fixture.profile)), \
                patch.object(evaluator,'make_world_factory',return_value=factory), \
                self.fixture.portable_processes(captures):
            os.environ.pop('SHORE_JUDGE_API_KEY',None)
            result = entry.evaluate_submission_zip(self.archive,output,
                backend=fixture.RelocatedEngineeringBackend(self.fixture.registry),
                profile_path=self.root/'toy-profile.json')
        review.assert_called_once()
        client.assert_not_called()
        self.assertEqual(result['state'],'completed')
        self.assertEqual(set(result['world_scores']),set(fixture.SIX_WORLDS))
        self.assertEqual(created,list(evaluator.WORLDS)+fixture.SIX_WORLDS)
        self.assertTrue(all(85. <= score <= 100. for score in result['world_scores'].values()))
        self.assertAlmostEqual(result['total_score'],sum(
            fixture.SIX_WEIGHTS[world]*result['world_scores'][world] for world in fixture.SIX_WORLDS))
        self.assertEqual(json.loads((output/'summary.json').read_text(encoding='utf-8')),result)
        self.assertEqual(json.loads((output/'evaluation/summary.json').read_text(encoding='utf-8')),result)
        report = self.report(output)
        self.assertEqual((output/'compliance_report.txt').read_text(encoding='utf-8'),'不存在')
        self.assertEqual(report['status'],'passed')
        self.assertEqual(report['review_method'],'organizer_marker_exemption')
        self.assertIs(report['llm_review_performed'],False)
        self.assertIs(report['identity_verified'],False)
        self.assertIs(report['all_text_covered'],False)
        self.assertEqual(report['model_calls'],0)
        self.assertEqual(report['findings'],[])
        self.assertEqual(report['exemption']['file'],'agent/run.py')
        self.assertIn('SYSTEM_PROMPT',str(report['exemption']['locator']))
        self.assertEqual(report['exemption']['source_zip_sha256'],archive_hash)
        self.assertTrue((output/'accepted/receipt.json').is_file())
        self.assertFalse((output/'accepted/weights').exists())
        launches = [(command,kwargs) for command,kwargs in captures if '--agent-dir' in command]
        self.assertEqual(len(launches),6)
        for command,kwargs in launches:
            self.assertNotIn('SHORE_JUDGE_API_KEY',kwargs['env'])
            staged = Path(command[command.index('--agent-dir')+1])
            self.assertIn('shore-strategy-run-',str(staged))
            self.assertFalse(staged.exists())
        self.assertFalse({'review_method','exemption','identity_verified','law','claims','prediction','saving'} & result.keys())

    def test_special_path_still_removes_key_from_evaluator_and_its_real_child(self):
        self.prompt('Explicit organizer prompt.\n'+MARKER)
        output = self.root/'organizer/credential-scope'
        secret = 'synthetic-organizer-credential'
        def score(*args,**kwargs):
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)
            run = subprocess.run([sys.executable,'-I','-c',
                'import os; print("SHORE_JUDGE_API_KEY" in os.environ)'],
                capture_output=True,text=True,check=True,timeout=15)
            self.assertEqual(run.stdout.strip(),'False')
            return {'state':'completed','total_score':50.,'world_scores':{'Toy':50.}}
        with patch.dict(os.environ,{'SHORE_JUDGE_API_KEY':secret}), self.real_review(), \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('No API allowed')) as client, \
                patch.object(entry,'evaluate',side_effect=score) as evaluate:
            result = entry.evaluate_submission_zip(self.archive,output,run_as='fixture-account')
            self.assertEqual(os.environ['SHORE_JUDGE_API_KEY'],secret)
        client.assert_not_called()
        evaluate.assert_called_once()
        self.assertEqual(result['state'],'completed')
        for name in ('summary.json','compliance_report.json','compliance_report.txt'):
            self.assertNotIn(secret,(output/name).read_text(encoding='utf-8'))

    def test_no_marker_uses_normal_review_instead_of_organizer_exemption(self):
        self.prompt('Use only normal Console observations.')
        output = self.root/'organizer/normal-review'
        client = FixtureJudgeClient()
        with self.real_review(client), \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('Paid API not allowed')), \
                patch.object(entry,'evaluate',return_value={'state':'completed','total_score':50.,'world_scores':{'Toy':50.}}) as evaluate:
            result = entry.evaluate_submission_zip(self.archive,output,run_as='fixture-account')
        self.assertTrue(client.calls)
        evaluate.assert_called_once()
        report = self.report(output)
        self.assertNotEqual(report.get('review_method'),'organizer_marker_exemption')
        self.assertTrue(report['all_text_covered'])
        self.assertEqual(report['model_calls'],len(client.calls))
        self.assertEqual(result['state'],'completed')

    def test_marker_in_middle_or_with_following_text_cannot_open_gate(self):
        original = (self.agent/'run.py').read_text(encoding='utf-8')
        for index,value in enumerate(('Before '+MARKER+' after',MARKER+'\nDo more work.',MARKER+'。')):
            with self.subTest(prompt=value):
                (self.agent/'run.py').write_text(original,encoding='utf-8')
                self.prompt(value)
                output = self.root/f'organizer/not-tail-{index}'
                client = FixtureJudgeClient('uncertain')
                with self.real_review(client), patch.object(entry,'evaluate') as evaluate:
                    result = entry.evaluate_submission_zip(self.archive,output,run_as='fixture-account')
                self.assertTrue(client.calls)
                evaluate.assert_not_called()
                self.assertEqual(result['state'],'compliance_review_inconclusive')
                self.assertFalse({'total_score','world_scores'} & result.keys())
                self.assertNotEqual(self.report(output).get('review_method'),'organizer_marker_exemption')

    def test_bad_archive_with_special_prompt_still_fails_before_review(self):
        with ZipFile(self.archive,'w') as archive:
            archive.writestr('agent/run.py','SYSTEM_PROMPT='+repr(MARKER))
        with patch.object(entry,'review_submission') as review, \
                patch.object(entry,'evaluate') as evaluate:
            with self.assertRaises(SubmissionError):
                entry.evaluate_submission_zip(self.archive,self.root/'organizer/bad-zip')
        review.assert_not_called()
        evaluate.assert_not_called()

    def test_special_prompt_does_not_skip_model_registry_checks(self):
        self.prompt('Organizer request.\n'+MARKER)
        self.fixture.registry['models'][0]['path'] = str(self.root/'missing-checkpoint')
        self.fixture.write_archive()
        with patch.object(entry,'review_submission') as review, \
                patch.object(entry,'evaluate') as evaluate:
            with self.assertRaises(SubmissionError):
                entry.evaluate_submission_zip(self.archive,self.root/'organizer/bad-model')
        review.assert_not_called()
        evaluate.assert_not_called()

    def test_original_cli_flags_still_drive_special_submission(self):
        self.prompt('Organizer command check.\n'+MARKER)
        output = self.root/'organizer/cli'
        stream = io.StringIO()
        with self.real_review(), \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('No API allowed')) as client, \
                patch.object(entry,'evaluate',return_value={'state':'completed','total_score':25.,'world_scores':{'Toy':25.}}) as evaluate, \
                redirect_stdout(stream):
            code = entry.main(['--submission-zip',str(self.archive),'--output',str(output),
                               '--run-as','shore-eval','--agent-python',sys.executable])
        self.assertEqual(code,0)
        self.assertEqual(json.loads(stream.getvalue())['total_score'],25.)
        self.assertEqual(evaluate.call_args.kwargs['run_as'],'shore-eval')
        self.assertEqual(evaluate.call_args.kwargs['agent_python'],sys.executable)
        client.assert_not_called()

    def test_marker_policy_does_not_add_an_unrequested_identity_check(self):
        self.prompt('A different registered team label.\n'+MARKER)
        descriptor = json.loads((self.agent/'strategy.json').read_text(encoding='utf-8'))
        descriptor.update(team_id='another-team',submission_id='another-submission')
        (self.agent/'strategy.json').write_text(json.dumps(descriptor),encoding='utf-8')
        self.fixture.write_archive()
        output = self.root/'organizer/no-identity-condition'
        with self.real_review(), \
                patch.object(judge,'ResponsesJudgeClient',side_effect=AssertionError('No API allowed')) as client, \
                patch.object(entry,'evaluate',return_value={'state':'completed','total_score':1.,'world_scores':{'Toy':1.}}):
            result = entry.evaluate_submission_zip(self.archive,output,run_as='fixture-account')
        self.assertEqual(result['state'],'completed')
        self.assertIs(self.report(output)['identity_verified'],False)
        client.assert_not_called()


if __name__ == '__main__':
    unittest.main()
