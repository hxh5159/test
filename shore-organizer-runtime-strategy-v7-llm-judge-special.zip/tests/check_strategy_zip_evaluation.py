"""ZIP handoff and relocated strategy engineering checks; no real model/world."""
from contextlib import contextmanager, redirect_stdout
import copy
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from zipfile import ZipFile

PRIVATE = Path(__file__).resolve().parents[1]
PUBLIC = PRIVATE.parent/'DiscoverPhysics'
sys.path[:0] = [str(PRIVATE), str(PRIVATE/'tests'), str(PUBLIC)]
import evaluate_strategy as path_evaluator
import evaluate_strategy_zip as zip_evaluator
from law_program_evaluation import OrganizerConfigurationError
from rift.submission import SubmissionError
from check_contest_job_runner import Clock, ToyConsole, calibration, LAW, CLAIMS

SIX_WORLDS = ['Adam', 'Lilith', 'Sachiel', 'Matriel', 'Leliel', 'Arael']
SIX_WEIGHTS = dict(zip(SIX_WORLDS, [.15, .15, .15, .20, .20, .15]))


class PortableOwner:
    """Only a one-process fixture; not a substitute for Linux cleanup checks."""
    KEY = path_evaluator._OwnedProcessTree.KEY

    def __init__(self, process, token):
        self.process = process

    def stop(self):
        try:
            self.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=5)


class RelocatedEngineeringBackend(path_evaluator.StrategyBackend):
    """Run real staging/SDK/HTTP code, with OS UID calls stubbed by the test."""
    def __init__(self, registry):
        self.registry = registry
        self.identity = {'user': 2031, 'group': 2031,
                         'extra_groups': [2031], 'umask': 0o077}
        self.agent_python = sys.executable
        self.environment = dict(os.environ)
        self.run_as = 'fixture-only-account'

    @contextmanager
    def evaluation_lock(self):
        yield


class StrategyZipEvaluationTests(unittest.TestCase):
    def setUp(self):
        # Keep snapshot paths below Windows' legacy path limit as well; the
        # production evaluator itself is explicitly Linux-only.
        self.temporary = tempfile.TemporaryDirectory(prefix='sz-')
        self.root = Path(self.temporary.name)
        self.addCleanup(self.temporary.cleanup)
        self.addCleanup(lambda: path_evaluator._remove_staged_tree(self.root)
                        if self.root.exists() else None)
        self.review = self.enterContext(patch.object(zip_evaluator, 'review_submission',
                                                    side_effect=self.passing_review))
        self.agent = self.root/'team/agent'
        self.agent.mkdir(parents=True)
        (self.agent/'__init__.py').write_text('', encoding='utf-8')
        (self.agent/'strategy.json').write_text(json.dumps({
            'schema_version':'1.0.0', 'team_id':'zip-team',
            'submission_id':'zip-window-1', 'version':'1'}), encoding='utf-8')
        (self.agent/'assets').mkdir()
        (self.agent/'assets/settings.json').write_text('{"strategy":"copied-policy"}', encoding='utf-8')
        source = '''from pathlib import Path
import json,os
from rift import Console
from rift.strategy import load_model_registry,model_binding
registry=load_model_registry(os.environ['SHORE_MODEL_REGISTRY'],check_files=True)
assert model_binding(registry)['id']=='solver'
assert model_binding(registry,'critic')['adapter_path'].endswith('critic-adapter')
assert json.loads(Path('assets/settings.json').read_text())['strategy']=='copied-policy'
assert Path.cwd()==Path(os.environ['SHORE_STRATEGY_DIR'])
assert 'shore-strategy-run-' in str(Path.cwd())
assert Path.cwd()!=Path(ORIGINAL_AGENT)
c=Console();c.mission()
output=Path(os.environ['RIFT_OUTPUT_DIR'])
(output/'location.private.json').write_text(json.dumps({'strategy':str(Path.cwd())}))
law=output/'law.py';claims=output/'claims.json'
law.write_text(LAW,encoding='utf-8');claims.write_text(json.dumps(CLAIMS),encoding='utf-8')
c.observe([.005]);c.save_draft(law,claims);c.submit(law,claims)
'''
        (self.agent/'run.py').write_text('LAW='+repr(LAW)+'\nCLAIMS='+repr(CLAIMS)+
            '\nORIGINAL_AGENT='+repr(str(self.agent))+'\n'+source, encoding='utf-8')
        rows = []
        for model_id, base in [('solver','27b'), ('critic','35b')]:
            model = self.root/'weights'/model_id
            model.mkdir(parents=True)
            (model/'config.json').write_text('{}', encoding='utf-8')
            (model/'tokenizer.json').write_text('{}', encoding='utf-8')
            (model/'model.safetensors').write_bytes(b'metadata-only-fixture-NOT-MODEL-WEIGHTS')
            rows.append({'id':model_id,'base_model':base, 'path':model.resolve().as_posix(),
                         'role':'discoverer' if model_id=='solver' else 'reviewer', 'adaptation':'sft'})
        adapter = self.root/'weights/critic-adapter'
        adapter.mkdir()
        (adapter/'adapter_config.json').write_text('{}', encoding='utf-8')
        (adapter/'adapter_model.safetensors').write_bytes(b'NOT-REAL-ADAPTER')
        rows[1]['adapter_path'] = adapter.resolve().as_posix()
        self.registry = {'schema_version':'1.0.0', 'primary_model_id':'solver', 'models':rows}
        self.archive = self.root/'submission.zip'
        self.write_archive()
        self.profile = {'profile_id':'zip-relocation-engineering-only', 'status':'released',
            'execution_mode':'direct_project', 'release_approved':True,
            'runtime_limits_approved':True, 'domains_and_validation_approved':True,
            'evaluation_worlds':SIX_WORLDS, 'evaluation_weights':SIX_WEIGHTS,
            'startup_seconds':20, 'candidate_timeout_seconds':20, 'shutdown_seconds':2,
            'policies':{'cross_submission_memory':'allow_own_legal_artifacts', 'deadline':'accepted_at',
                        'tie_break':'weighted_saving_ascending',
                        'hidden_run_artifacts':'organizer_retained_no_contest_export'}}

    @staticmethod
    def passing_review(accepted, report_root):
        # Explicit engineering fixture: never call an external judge or infer a
        # security decision from the submitted source in this integration test.
        assert (Path(accepted)/'agent/run.py').is_file()
        report = {'status':'passed', 'summary':'不存在', 'findings':[]}
        (Path(report_root)/'compliance_report.json').write_text(json.dumps(report), encoding='utf-8')
        (Path(report_root)/'compliance_report.txt').write_text('不存在', encoding='utf-8')
        return report

    def write_archive(self):
        with ZipFile(self.archive, 'w') as archive:
            archive.writestr('models.json', json.dumps(self.registry))
            for path in sorted(self.agent.rglob('*')):
                if path.is_file():
                    archive.write(path, 'agent/'+path.relative_to(self.agent).as_posix())

    @contextmanager
    def portable_processes(self, captures=None):
        original = subprocess.Popen
        def start(command, **kwargs):
            if captures is not None:
                captures.append((list(command), dict(kwargs)))
            # Windows cannot select Linux UIDs. This removes only identity
            # options for an explicitly injected local engineering backend.
            for key in ('user','group','extra_groups','umask'):
                kwargs.pop(key, None)
            return original(command, **kwargs)
        with patch.object(path_evaluator.os,'chown',create=True), \
                patch.object(path_evaluator,'_enable_child_subreaper'), \
                patch.object(path_evaluator,'_OwnedProcessTree',PortableOwner), \
                patch.object(path_evaluator.subprocess,'Popen',side_effect=start):
            yield

    def test_accept_relocate_six_toy_sessions_and_score_with_external_multiple_weights(self):
        # Original source is gone: the ZIP and organizer-owned staging must
        # suffice, while every declared weight stays at its external path.
        shutil.rmtree(self.agent)
        backend = RelocatedEngineeringBackend(self.registry)
        created, captures = [], []
        clock = Clock()
        def factory(world):
            created.append(world)
            return ToyConsole(world,clock,'submit'), calibration(world)
        output = self.root/'organizer/run-1'
        with patch.object(path_evaluator,'read_profile',return_value=copy.deepcopy(self.profile)), \
                patch.object(path_evaluator,'make_world_factory',return_value=factory), \
                self.portable_processes(captures):
            result = zip_evaluator.evaluate_submission_zip(self.archive, output,
                backend=backend, profile_path=self.root/'toy-profile.json')
        self.assertEqual(result['state'],'completed')
        self.review.assert_called_once_with(output/'accepted', output)
        self.assertEqual(set(result['world_scores']),set(SIX_WORLDS))
        self.assertTrue(all(85. <= value <= 100. for value in result['world_scores'].values()))
        self.assertAlmostEqual(result['total_score'],sum(
            SIX_WEIGHTS[world]*result['world_scores'][world] for world in SIX_WORLDS))
        self.assertEqual(created,list(path_evaluator.WORLDS)+SIX_WORLDS)
        self.assertEqual(json.loads((output/'summary.json').read_text()),result)
        self.assertEqual(json.loads((output/'evaluation/summary.json').read_text()),result)
        self.assertTrue((output/'accepted/receipt.json').is_file())
        self.assertTrue((output/'accepted/agent/assets/settings.json').is_file())
        self.assertFalse((output/'accepted/weights').exists())
        self.assertFalse({'prediction','law','saving','claims','registry','receipt_file'} & result.keys())
        launches = [(command,kw) for command,kw in captures if '--agent-dir' in command]
        self.assertEqual(len(launches),6)
        staged = set()
        for command, kwargs in launches:
            location = Path(command[command.index('--agent-dir')+1])
            staged.add(str(location))
            self.assertIn('shore-strategy-run-',str(location))
            self.assertNotEqual(location,output/'accepted/agent')
            self.assertEqual(kwargs['env']['SHORE_STRATEGY_DIR'],str(location))
            self.assertFalse(location.exists())
        self.assertEqual(len(staged),6)
        attempts = list((output/'evaluation/private/runs').glob('*/attempt-*'))
        self.assertEqual(len(attempts),1)
        for world in SIX_WORLDS:
            self.assertTrue((attempts[0]/world/'output/location.private.json').is_file())
        self.assertFalse((output/'accepted/agent/location.private.json').exists())

    def test_check_only_accepts_same_zip_without_importing_or_executing_agent(self):
        marker = self.root/'UNEXPECTED_AGENT_EXECUTION'
        payload = 'from pathlib import Path\nPath('+repr(str(marker))+').write_text("ran")\n'
        (self.agent/'__init__.py').write_text(payload,encoding='utf-8')
        (self.agent/'run.py').write_text(payload,encoding='utf-8')
        self.write_archive()
        output = self.root/'organizer/check-1'
        with patch.object(path_evaluator,'read_profile',return_value=copy.deepcopy(self.profile)), \
                patch.object(path_evaluator,'make_world_factory',return_value=lambda world: None) as factory, \
                self.portable_processes():
            result = zip_evaluator.evaluate_submission_zip(self.archive,output,check_only=True,
                backend=RelocatedEngineeringBackend(self.registry),profile_path=self.root/'toy.json')
        self.assertEqual(result['status'],'strategy_paths_checked')
        self.assertEqual(result['model_count'],2)
        self.assertEqual(result['world_count'],6)
        self.assertIs(result['model_loaded'],False)
        self.assertIs(result['compliance_review_performed'],False)
        self.review.assert_not_called()
        factory.assert_not_called()
        self.assertFalse(marker.exists())
        self.assertFalse((output/'evaluation').exists())
        self.assertTrue((output/'accepted/source.zip').is_file())
        self.assertEqual(json.loads((output/'summary.json').read_text()),result)
        self.assertFalse({'total_score','world_scores','registry','agent_dir'} & result.keys())

    def test_access_probe_reads_copy_not_administrator_private_accepted_parent(self):
        backend = RelocatedEngineeringBackend(self.registry)
        calls = []
        def probe(command, **kwargs):
            paths = json.loads(command[-1])
            staged = Path(paths[0])
            calls.append(paths)
            self.assertNotEqual(staged,self.agent)
            self.assertEqual((staged/'assets/settings.json').read_bytes(),
                             (self.agent/'assets/settings.json').read_bytes())
            self.assertIn('shore-strategy-access-',str(staged))
            self.assertEqual(paths[1:],[self.registry['models'][0]['path'],
                self.registry['models'][1]['path'],self.registry['models'][1]['adapter_path']])
            return SimpleNamespace(returncode=0)
        with patch.object(path_evaluator.subprocess,'run',side_effect=probe):
            backend.check_access(self.agent)
        self.assertEqual(len(calls),1)
        self.assertFalse(Path(calls[0][0]).exists())

    def test_failed_access_probe_cleans_its_readonly_copy(self):
        backend = RelocatedEngineeringBackend(self.registry)
        checked = []
        def probe(command, **kwargs):
            checked.append(Path(json.loads(command[-1])[0]))
            return SimpleNamespace(returncode=2)
        with patch.object(path_evaluator.subprocess,'run',side_effect=probe):
            with self.assertRaises(OrganizerConfigurationError):
                backend.check_access(self.agent)
        self.assertTrue(checked)
        self.assertFalse(checked[0].exists())

    def test_existing_run_never_calls_intake_or_overwrites_files(self):
        output = self.root/'existing'
        output.mkdir()
        marker = output/'summary.json'
        marker.write_text('old result',encoding='utf-8')
        with patch.object(zip_evaluator,'accept_strategy_zip') as intake:
            with self.assertRaisesRegex(OrganizerConfigurationError,'new output'):
                zip_evaluator.evaluate_submission_zip(self.archive,output)
        intake.assert_not_called()
        self.assertEqual(marker.read_text(),'old result')

    def test_intake_failure_does_not_call_evaluator(self):
        with patch.object(zip_evaluator,'accept_strategy_zip',side_effect=ValueError('bad ZIP')), \
                patch.object(zip_evaluator,'evaluate') as evaluate:
            with self.assertRaisesRegex(ValueError,'bad ZIP'):
                zip_evaluator.evaluate_submission_zip(self.archive,self.root/'invalid')
        evaluate.assert_not_called()

    def test_organizer_can_lower_archive_limits_and_reject_before_agent_execution(self):
        marker = self.root/'UNEXPECTED_LIMIT_REJECT_EXECUTION'
        (self.agent/'__init__.py').write_text(
            'from pathlib import Path\nPath('+repr(str(marker))+').write_text("ran")\n',encoding='utf-8')
        self.write_archive()
        for name, limits in [('bytes',{'max_unpacked_bytes':64}), ('members',{'max_members':3})]:
            with self.subTest(limit=name), patch.object(zip_evaluator,'evaluate') as evaluate:
                output = self.root/('limited-'+name)
                with self.assertRaises(SubmissionError):
                    zip_evaluator.evaluate_submission_zip(self.archive,output,**limits)
                evaluate.assert_not_called()
                self.assertFalse((output/'accepted').exists())
                self.assertFalse(marker.exists())

    def test_root_feedback_is_projected_and_does_not_copy_hidden_results(self):
        output = self.root/'projection'
        feedback = {'state':'completed','total_score':12.5,'world_scores':{'Adam':12.5},
                    'team_id':'fixture','raw_observations':'PRIVATE','models_file':'PRIVATE',
                    'law':'PRIVATE','claims':'PRIVATE','saving':5}
        with patch.object(zip_evaluator,'evaluate',return_value=feedback):
            result = zip_evaluator.evaluate_submission_zip(self.archive,output)
        self.assertEqual(result,{'state':'completed','total_score':12.5,
                                'world_scores':{'Adam':12.5},'team_id':'fixture'})
        self.assertNotIn('PRIVATE',(output/'summary.json').read_text())

    def test_cli_requires_zip_and_cannot_inject_a_local_backend(self):
        with patch('sys.stderr',new=io.StringIO()):
            with self.assertRaises(SystemExit) as exc:
                zip_evaluator.main(['--submission-zip',str(self.archive),'--output',str(self.root/'cli'),
                                    '--run-as','shore-eval','--backend','same-user'])
        self.assertEqual(exc.exception.code,2)

    def test_cli_returns_structured_format_error_without_private_trace(self):
        stream = io.StringIO()
        error = SubmissionError('$.models[1].path','A complete local checkpoint is required.')
        with patch.object(zip_evaluator,'evaluate_submission_zip',side_effect=error), redirect_stdout(stream):
            status = zip_evaluator.main(['--submission-zip',str(self.archive),
                '--output',str(self.root/'cli'),'--run-as','shore-eval'])
        self.assertEqual(status,2)
        result = json.loads(stream.getvalue())
        self.assertEqual(result['error'],error.as_dict())
        self.assertNotIn('Traceback',stream.getvalue())

    def test_cli_hides_unexpected_filesystem_error_details(self):
        stream = io.StringIO()
        with patch.object(zip_evaluator,'evaluate_submission_zip',side_effect=OSError('PRIVATE-PATH')), \
                redirect_stdout(stream):
            status = zip_evaluator.main(['--submission-zip',str(self.archive),
                '--output',str(self.root/'cli'),'--run-as','shore-eval'])
        self.assertEqual(status,2)
        self.assertNotIn('PRIVATE-PATH',stream.getvalue())
        self.assertEqual(set(json.loads(stream.getvalue())['error']),{'code','path','message'})


if __name__ == '__main__':
    unittest.main()
