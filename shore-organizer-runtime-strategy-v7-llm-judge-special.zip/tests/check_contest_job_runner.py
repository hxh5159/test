"""PRIVATE job engineering tests: fake observations/toy a=0, no model call."""
from pathlib import Path
import copy
import json
import math
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import numpy as np

PRIVATE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PRIVATE))
PUBLIC = PRIVATE.parent/'DiscoverPhysics'
sys.path.insert(0, str(PUBLIC))
from contest_execution import LocalDiagnosticBackend
from contest_job_runner import JobRunner
from contest_scoreboard import Scoreboard, WORLDS
from law_program_evaluation import OrganizerConfigurationError
from rift.submission import manifest_digest

LAW = '''import numpy as np
LAW_API_VERSION="1.0.0"
PARAMS={}
def acceleration(t,bodies,params):
    return np.zeros((len(bodies),2),dtype=np.float64)
'''
CLAIMS = {'dynamics_order': 2, 'hidden_matter': False, 'time_dependence': False}
AGENT = '''from pathlib import Path
import os,json,time
from rift import Console,ConsoleError
c=Console()
m=c.mission()
root=Path(os.environ['RIFT_OUTPUT_DIR'])
law=root/'law.py';claims=root/'claims.json'
law.write_text(LAW,encoding='utf8');claims.write_text(json.dumps(CLAIMS),encoding='utf8')
if MODE=='submit':
    c.observe([.005]);c.save_draft(law,claims);c.submit(law,claims)
elif MODE=='draft_timeout':
    c.save_draft(law,claims)
    try:c.observe([.005])
    except ConsoleError:pass
elif MODE=='bad_submit_then_timeout':
    c.save_draft(law,claims);claims.write_text('{}',encoding='utf8')
    try:c.submit(law,claims)
    except ConsoleError:pass
    try:c.observe([.005])
    except ConsoleError:pass
elif MODE=='empty_timeout':
    try:c.observe([.005])
    except ConsoleError:pass
elif MODE=='private_fault':
    try:c.observe([.005])
    except ConsoleError:pass
elif MODE=='hang':
    time.sleep(30)
'''


class Clock:
    def __init__(self):
        self.offset = 0.
        self.lock = threading.Lock()
    def __call__(self):
        with self.lock:
            return time.monotonic()+self.offset
    def advance(self, seconds):
        with self.lock:
            self.offset += seconds


class ToyConsole:
    """No real world law. Every public toy trajectory is constant velocity."""
    def __init__(self, world, clock, mode):
        self.world, self.clock, self.mode = world, clock, mode
        self._started_at = None
        self._wall_seconds = 300
        self.energy = self.observes = 0
    @property
    def budget(self):
        elapsed = 0. if self._started_at is None else self.clock()-self._started_at
        return {'energy_used': self.energy, 'energy_remaining': 10-self.energy,
                'observe_used': self.observes, 'observe_remaining': 20-self.observes,
                'wall_clock_remaining_seconds': max(0.,300-elapsed)}
    def mission(self):
        self._started_at = self.clock()
        return {'world_id': self.world, 'numerics_version':'1.1','claims_schema_version':'4.0.0',
                'law_api_version':'1.0.0','task':'Engineering fixture, not a discovery problem',
                'controls':{'source_properties':{},'probe_properties':{}},
                'source_property_target_id':None,
                'launch_region':{'kind':'annulus','center':[0,0],'radius_min':1,'radius_max':2},
                'initial_speed_max':1,'maximum_physical_time':2,
                'maximum_single_trajectory_duration':1,
                'background_initial_state':{'ids':[],'positions':[],'velocities':[]},
                'limits':{'energy_budget':10,'observe_calls':20,'wall_clock_seconds':300,
                          'energy_per_new_probe':1,'max_probes_per_launch':8,
                          'max_readouts_per_probe':50,'max_times_per_observe':50},
                'noise':{'positions':'Gaussian','probe_velocities':'no additional noise'},
                'first_light':{'probes':[],'t_launch':0.,'readout':[.005], 'source_properties':{},
                               'times':[.005],'positions':[[]],'velocities':[[]],
                               'visible_background_positions':[[]],'background_ids':[]}}
    def validate_request(self, method, params):
        if method != 'observe' or params.get('times') != [.005]:
            raise ValueError('Only the invented test observation is allowed')
    def observe(self, times):
        if self.mode == 'private_fault':
            raise RuntimeError('PRIVATE TEST FAULT: must never become scientific P0')
        self.observes += 1
        if self.mode in ('draft_timeout','empty_timeout','bad_submit_then_timeout'):
            self.clock.advance(301)
        return {'observation_id':'O1','times':times,'positions':[[]],'ids':[],'budget':self.budget}


def calibration(world):
    probes = [{'pos':[1.+i*.03,.1*i], 'vel':[.2,.1], 'properties':{}} for i in range(20)]
    times = [.005,.01]
    positions = [[[p['pos'][j]+p['vel'][j]*t for j in range(2)] for p in probes] for t in times]
    values = np.asarray(positions).reshape(-1,2)
    variance = float(np.mean(np.sum((values-values.mean(axis=0))**2,axis=-1)))
    return {'world':world,'cases':[{'name':'toy','group':'engineering','probes':probes,
                                  't_launch':0.,'readout':times,'source_properties':{}}],
            'truths':[{'name':'toy','times':times,'positions':positions}],
            'global_V':variance,'N_probes':20,'T_samples':2}


class JobRunnerTests(unittest.TestCase):
    def setUp(self):
        root = PRIVATE/'checks/contest_job_runner_fixtures'
        root.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=root,prefix='job-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root/'source';self.source.mkdir()
        self.board = Scoreboard(self.root/'scores.sqlite')
        self.clock = Clock()
        self.mode = 'submit'
        self.created = []
        self.profile = {'profile_id':'engineering-not-released','status':'internal_validation',
                        'startup_seconds':20,'candidate_timeout_seconds':20,'shutdown_seconds':2}

    def agent(self, mode):
        self.mode = mode
        (self.source/'agent.py').write_text('LAW='+repr(LAW)+'\nCLAIMS='+repr(CLAIMS)+'\nMODE='+repr(mode)+'\n'+AGENT,
                                            encoding='utf8')

    def factory(self, world):
        self.created.append(world)
        return ToyConsole(world,self.clock,self.mode), calibration(world)

    def enqueue(self):
        manifest = {'schema_version':'1.0.0','submission_id':'fixture-v1','team_id':'engineering-team',
                    'version':'0.1','entrypoint':['python','agent.py'],
                    'models':[{'base_model':'Qwen3.6-35B-A3B','path':'/models/format-only-no-model-loaded'}]}
        return self.board.enqueue(manifest,manifest_sha256=manifest_digest(manifest),
                                  image_digest='sha256:'+'b'*64,
                                  private_spec={'submission_root':str(self.source)})['job_id']

    def runner(self, **kwargs):
        return JobRunner(self.board,LocalDiagnosticBackend(explicitly_allow_local=True),self.factory,
                         run_root=self.root/'runs',profile=self.profile,require_released=False,
                         clock=self.clock,**kwargs)

    def single_world(self, mode):
        self.agent(mode);self.enqueue()
        job = self.board.claim_next('test-worker')
        with self.runner() as runner:
            return runner._world(job,job['manifest'],'Adam',self.root/'single-world')

    def test_complete_nine_world_http_agent_to_fixed_worker_to_public_score(self):
        self.agent('submit');job_id=self.enqueue()
        with self.runner() as runner:
            result=runner.run_next('test-worker')
            self.assertIsNone(runner.run_next('test-worker'))
        self.assertEqual(result['job_id'],job_id)
        self.assertEqual(result['state'],'completed')
        self.assertEqual(self.created,list(WORLDS))
        self.assertEqual(set(result['world_scores']),set(WORLDS))
        self.assertTrue(all(80 <= value <= 100 for value in result['world_scores'].values()))
        self.assertEqual(set(result),{'job_id','team_id','accepted_at','state','total_score','world_scores'})
        attempts=list((self.root/'runs'/job_id).glob('attempt-*'))
        self.assertEqual(len(attempts),1)
        for world in WORLDS:
            session=json.loads((attempts[0]/world/'session.json').read_text(encoding='utf8'))
            score=json.loads((attempts[0]/world/'score.private.json').read_text(encoding='utf8'))
            self.assertEqual(session['job_id'],job_id)
            self.assertEqual(session['reason'],'submitted')
            self.assertEqual(session['observe_used'],1)
            self.assertTrue(session['has_valid_submission'])
            self.assertAlmostEqual(score['prediction'],80.,places=10)
            self.assertEqual(score['artifact_identity']['law_sha256'],session['law_sha256'])
            self.assertTrue((attempts[0]/world/'logs/agent.stdout.log').is_file())
            self.assertFalse((attempts[0]/'team-export').exists())
            archived=json.loads((attempts[0]/world/'archive.private.json').read_text(encoding='utf8'))
            self.assertEqual(archived['budget']['observe_used'],1)
            self.assertNotIn('prediction',json.dumps(archived))
            self.assertNotIn('score',json.dumps(archived))
        self.assertEqual(len(self.board.leaderboard()),1)

    def test_timeout_selects_last_valid_draft(self):
        score=self.single_world('draft_timeout')
        self.assertTrue(score['has_valid_submission'])
        self.assertAlmostEqual(score['prediction'],80.,places=10)
        session=json.loads((self.root/'single-world/session.json').read_text(encoding='utf8'))
        self.assertEqual(session['reason'],'timeout')
        self.assertEqual(session['observe_used'],1)

    def test_invalid_submit_does_not_end_session_or_replace_draft(self):
        score=self.single_world('bad_submit_then_timeout')
        self.assertTrue(score['has_valid_submission'])
        self.assertAlmostEqual(score['prediction'],80.,places=10)
        session=json.loads((self.root/'single-world/session.json').read_text(encoding='utf8'))
        self.assertEqual(session['reason'],'timeout')
        self.assertEqual(session['observe_used'],1)

    def test_timeout_without_draft_is_world_zero(self):
        score=self.single_world('empty_timeout')
        self.assertEqual(score['total'],0.)
        self.assertFalse(score['has_valid_submission'])
        self.assertEqual(score['end_reason'],'timeout')

    def test_official_service_fault_never_publishes_partial_or_zero_score(self):
        self.agent('private_fault');job_id=self.enqueue()
        with self.runner() as runner:
            result=runner.run_next('test-worker')
        self.assertEqual(result['state'],'infrastructure_failed')
        self.assertNotIn('total_score',result)
        self.assertNotIn('world_scores',result)
        self.assertEqual(self.board.leaderboard(),[])
        self.assertEqual(self.created,['Adam'])
        self.board.requeue_infrastructure(job_id)
        self.assertEqual(self.board.status(job_id)['state'],'queued')

    def test_no_mission_startup_timeout_is_external_and_returns_no_artifact(self):
        # A tiny startup guard is a test-only explicit profile, not a contest rule.
        self.profile['startup_seconds']=.01
        (self.source/'agent.py').write_text('import time\ntime.sleep(30)\n',encoding='utf8')
        self.enqueue();job=self.board.claim_next('test-worker')
        started=time.monotonic()
        with self.runner() as runner:
            result=runner._world(job,job['manifest'],'Adam',self.root/'startup')
        self.assertLess(time.monotonic()-started,5.)
        self.assertEqual(result['total'],0.)
        self.assertEqual(result['end_reason'],'startup_timeout')

    def test_official_calibration_failure_marks_job_infrastructure_not_candidate(self):
        self.agent('submit');self.enqueue()
        original=self.factory
        def broken(world):
            console,reference=original(world)
            reference['truths'][0]['positions']=[[[float('nan'),0.]]]
            return console,reference
        with self.runner() as runner:
            runner.world_factory=broken
            result=runner.run_next('test-worker')
        self.assertEqual(result['state'],'infrastructure_failed')
        self.assertNotIn('total_score',result)

    def test_profiles_require_explicit_limits_and_release_opt_in(self):
        backend=LocalDiagnosticBackend(explicitly_allow_local=True)
        arguments=dict(scoreboard=self.board,backend=backend,world_factory=self.factory,
                       run_root=self.root/'runs',profile=self.profile)
        with self.assertRaises(OrganizerConfigurationError):JobRunner(**arguments)
        for key in ('startup_seconds','candidate_timeout_seconds','shutdown_seconds'):
            profile=copy.deepcopy(self.profile);profile.pop(key)
            with self.assertRaises(OrganizerConfigurationError):
                JobRunner(**{**arguments,'profile':profile,'require_released':False})

    def test_runner_cannot_consume_a_queue_from_the_other_execution_scope(self):
        backend=LocalDiagnosticBackend(explicitly_allow_local=True)
        approved={**self.profile,'status':'released','release_approved':True}
        with self.assertRaises(OrganizerConfigurationError):
            JobRunner(self.board,backend,self.factory,run_root=self.root/'runs',profile=approved)
        official=Scoreboard(self.root/'official.sqlite',scope='official')
        with self.assertRaises(OrganizerConfigurationError):
            JobRunner(official,backend,self.factory,run_root=self.root/'runs',profile=approved)
        with self.assertRaises(OrganizerConfigurationError):
            JobRunner(official,backend,self.factory,run_root=self.root/'runs',
                      profile=self.profile,require_released=False)

    def test_parent_watchdog_does_not_wait_forever_behind_private_simulator_lock(self):
        self.agent('submit');self.enqueue()
        self.profile['shutdown_seconds']=.05
        entered,release=threading.Event(),threading.Event()
        original=self.factory
        def blocked_factory(world):
            console,reference=original(world)
            mission=console.mission
            def blocked_mission():
                entered.set()
                release.wait(timeout=10)
                return mission()
            console.mission=blocked_mission
            return console,reference
        # The watchdog deliberately returns before an unresponsive simulator
        # finalizes. Wait for that released writer before TemporaryDirectory
        # cleanup; Windows otherwise races an open finalized-record file.
        sealed = threading.Event()
        from contest_console_service import ConsoleSession
        original_seal = ConsoleSession._seal
        def observed_seal(session, reason):
            try:
                return original_seal(session, reason)
            finally:
                sealed.set()
        result={}
        with patch.object(ConsoleSession, '_seal', observed_seal), self.runner() as runner:
            runner.world_factory=blocked_factory
            thread=threading.Thread(target=lambda: result.update(runner.run_next('test-worker')),daemon=True)
            thread.start()
            try:
                self.assertTrue(entered.wait(timeout=5))
                self.clock.advance(301)
                thread.join(timeout=5)
                self.assertFalse(thread.is_alive())
                self.assertEqual(result['state'],'infrastructure_failed')
                self.assertNotIn('total_score',result)
            finally:
                release.set()
                thread.join(timeout=5)
                self.assertTrue(sealed.wait(timeout=5))


if __name__=='__main__':
    unittest.main()
