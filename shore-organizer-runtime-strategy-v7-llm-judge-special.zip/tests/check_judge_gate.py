"""Compliance gate sequencing checks; no external API, model or real world."""
from __future__ import annotations

from contextlib import redirect_stdout
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

PRIVATE = Path(__file__).resolve().parents[1]
PUBLIC = PRIVATE.parent/'DiscoverPhysics'
sys.path[:0] = [str(PRIVATE), str(PUBLIC)]

import evaluate_strategy_zip as entry
from evaluate_strategy import strategy_environment


class ComplianceGateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='judge-gate-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.output = self.root/'new-run'
        self.events = []
        self.intake = self.enterContext(patch.object(entry, 'accept_strategy_zip', side_effect=self.accept))
        self.evaluate = self.enterContext(patch.object(entry, 'evaluate', side_effect=self.score))

    def accept(self, archive, destination, **kwargs):
        self.events.append('intake')
        destination.mkdir()
        (destination/'agent').mkdir()
        (destination/'agent/run.py').write_text('raise RuntimeError("MUST NOT RUN")', encoding='utf-8')
        (destination/'models.json').write_text('{}', encoding='utf-8')
        return {'agent_dir':str(destination/'agent'), 'models_file':str(destination/'models.json')}

    def score(self, *args, **kwargs):
        self.events.append('evaluate')
        if kwargs.get('check_only'):
            return {'status':'strategy_paths_checked', 'model_loaded':False, 'world_count':6}
        return {'state':'completed', 'total_score':75., 'world_scores':{'toy':75.}}

    def report(self, status='passed', *, summary=None, findings=None, write=True):
        def review(accepted, report_root):
            self.events.append('review')
            self.assertEqual(accepted, self.output/'accepted')
            self.assertTrue((accepted/'agent/run.py').is_file())
            self.assertFalse((report_root/'evaluation').exists())
            report = {'status':status, 'summary':summary or ('不存在' if status == 'passed' else 'needs review'),
                      'findings':[] if findings is None else findings}
            if write:
                (report_root/'compliance_report.json').write_text(json.dumps(report), encoding='utf-8')
                (report_root/'compliance_report.txt').write_text(
                    '不存在' if status == 'passed' else '私有违规详情', encoding='utf-8')
            return report
        return review

    def run_entry(self, **kwargs):
        return entry.evaluate_submission_zip(self.root/'input.zip', self.output,
            run_as='fixture-only', agent_python=sys.executable, **kwargs)

    def test_pass_is_required_after_unpack_and_before_any_evaluation(self):
        with patch.object(entry, 'review_submission', side_effect=self.report()) as review:
            result = self.run_entry()
        self.assertEqual(self.events, ['intake','review','evaluate'])
        self.assertEqual(result['state'],'completed')
        review.assert_called_once()
        self.assertEqual((self.output/'compliance_report.txt').read_text(encoding='utf-8'),'不存在')

    def test_rejected_error_and_inconclusive_do_not_start_evaluation(self):
        for status in ('rejected','error','inconclusive'):
            with self.subTest(status=status), tempfile.TemporaryDirectory(dir=self.root) as tmp:
                self.output = Path(tmp)/'run'
                self.events.clear()
                self.evaluate.reset_mock()
                with patch.object(entry,'review_submission',side_effect=self.report(status)):
                    result = self.run_entry()
                self.assertEqual(self.events,['intake','review'])
                self.evaluate.assert_not_called()
                self.assertNotEqual(result['state'],'completed')
                self.assertEqual(result['compliance_review']['status'],status)
                self.assertFalse({'total_score','world_scores'} & result.keys())
                self.assertFalse((self.output/'evaluation').exists())
                saved = json.loads((self.output/'summary.json').read_text())
                self.assertEqual(saved,result)
                self.assertNotIn('私有违规详情',json.dumps(result,ensure_ascii=False))

    def test_judge_exception_is_closed_and_credential_is_not_reported(self):
        private = 'sk-' + 'THIS-IS-A-FAKE-KEY-ONLY-FOR-TEST'
        with patch.object(entry,'review_submission',side_effect=RuntimeError(private)):
            result = self.run_entry()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_review_error')
        for path in (self.output/'summary.json', self.output/'compliance_report.json', self.output/'compliance_report.txt'):
            self.assertNotIn(private,path.read_text(encoding='utf-8'))

    def test_malformed_review_never_approves(self):
        for index, value in enumerate((None, True, {'status':'passed'},
                {'status':'unexpected','summary':'ok','findings':[]})):
            with self.subTest(value=value):
                self.output = self.root/f'bad-{index}'
                self.evaluate.reset_mock()
                with patch.object(entry,'review_submission',return_value=value):
                    result = self.run_entry()
                self.evaluate.assert_not_called()
                self.assertEqual(result['state'],'compliance_review_error')

    def test_pass_without_saved_report_is_closed(self):
        with patch.object(entry,'review_submission',side_effect=self.report(write=False)):
            result = self.run_entry()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_review_error')

    def test_pass_with_findings_is_closed(self):
        with patch.object(entry,'review_submission',side_effect=self.report(findings=[{'file':'agent/run.py'}])):
            result = self.run_entry()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_review_error')

    def test_report_status_mismatch_is_closed(self):
        original = self.report()
        def inconsistent(accepted, report_root):
            result = original(accepted,report_root)
            result['status'] = 'rejected'
            return result
        with patch.object(entry,'review_submission',side_effect=inconsistent):
            result = self.run_entry()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_review_error')

    def test_pass_with_a_missing_plain_text_verdict_is_closed(self):
        original = self.report()
        def inconsistent(accepted, report_root):
            result = original(accepted,report_root)
            (report_root/'compliance_report.txt').write_text('待复核',encoding='utf-8')
            return result
        with patch.object(entry,'review_submission',side_effect=inconsistent):
            result = self.run_entry()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_review_error')

    def test_check_only_is_explicitly_not_compliance_approval_and_has_no_paid_call(self):
        with patch.object(entry,'review_submission') as review:
            result = self.run_entry(check_only=True)
        review.assert_not_called()
        self.assertEqual(self.events,['intake','evaluate'])
        self.assertIs(result['compliance_review_performed'],False)
        self.assertNotIn('total_score',result)
        self.assertFalse((self.output/'compliance_report.txt').exists())

    def test_backend_injection_is_not_an_implicit_judge_bypass(self):
        injected = object()
        with patch.object(entry,'review_submission',side_effect=self.report('rejected')) as review:
            result = self.run_entry(backend=injected)
        review.assert_called_once()
        self.evaluate.assert_not_called()
        self.assertEqual(result['state'],'compliance_rejected')

    def test_organizer_judge_credentials_do_not_enter_team_environment(self):
        source = {'SHORE_JUDGE_API_KEY':'private-judge-key', 'LLMTOKEN_API_KEY':'private-legacy-key',
                  'OPENAI_API_KEY':'private-openai-key', 'SHORE_JUDGE_CONFIG':'private-judge-config',
                  'PATH':'python-path', 'SHORE_MODEL_PYTHON':'model-python'}
        env = strategy_environment(source,self.root,self.root/'sdk',self.root/'models.json',self.root/'agent')
        self.assertEqual(env['SHORE_MODEL_PYTHON'],'model-python')
        self.assertFalse({'SHORE_JUDGE_API_KEY','LLMTOKEN_API_KEY','OPENAI_API_KEY','SHORE_JUDGE_CONFIG'} & env.keys())

    def test_judge_key_available_to_review_but_not_evaluator_or_its_child(self):
        secret = 'fixture-only-judge-credential'
        original = self.report()
        def review(accepted, report_root):
            self.assertEqual(os.environ.get('SHORE_JUDGE_API_KEY'),secret)
            return original(accepted,report_root)
        def evaluate(*args, **kwargs):
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)
            child = subprocess.run([sys.executable,'-I','-c',
                'import os;print("SHORE_JUDGE_API_KEY" in os.environ)'],
                capture_output=True,text=True,check=True,timeout=15)
            self.assertEqual(child.stdout.strip(),'False')
            return self.score(*args,**kwargs)
        with patch.dict(os.environ,{'SHORE_JUDGE_API_KEY':secret}), \
                patch.object(entry,'review_submission',side_effect=review), \
                patch.object(entry,'evaluate',side_effect=evaluate):
            result = self.run_entry()
            self.assertEqual(os.environ.get('SHORE_JUDGE_API_KEY'),secret)
        self.assertEqual(result['state'],'completed')

    def test_evaluator_failure_still_restores_the_original_judge_key(self):
        secret = 'fixture-only-before-error'
        def evaluate(*args, **kwargs):
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)
            os.environ['SHORE_JUDGE_API_KEY'] = 'unexpected-evaluation-change'
            raise RuntimeError('deliberate evaluator fixture failure')
        with patch.dict(os.environ,{'SHORE_JUDGE_API_KEY':secret}), \
                patch.object(entry,'review_submission',side_effect=self.report()), \
                patch.object(entry,'evaluate',side_effect=evaluate):
            with self.assertRaisesRegex(RuntimeError,'fixture failure'):
                self.run_entry()
            self.assertEqual(os.environ.get('SHORE_JUDGE_API_KEY'),secret)

    def test_absent_judge_key_remains_absent_after_evaluation(self):
        def evaluate(*args, **kwargs):
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)
            os.environ['SHORE_JUDGE_API_KEY'] = 'unexpected-evaluation-change'
            return self.score(*args,**kwargs)
        with patch.dict(os.environ), \
                patch.object(entry,'review_submission',side_effect=self.report()), \
                patch.object(entry,'evaluate',side_effect=evaluate):
            os.environ.pop('SHORE_JUDGE_API_KEY',None)
            self.run_entry()
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)

    def test_check_only_and_empty_existing_key_are_protected_and_restored(self):
        def evaluate(*args, **kwargs):
            self.assertNotIn('SHORE_JUDGE_API_KEY',os.environ)
            return self.score(*args,**kwargs)
        with patch.dict(os.environ,{'SHORE_JUDGE_API_KEY':''}), \
                patch.object(entry,'review_submission') as review, \
                patch.object(entry,'evaluate',side_effect=evaluate):
            result = self.run_entry(check_only=True)
            self.assertIn('SHORE_JUDGE_API_KEY',os.environ)
            self.assertEqual(os.environ['SHORE_JUDGE_API_KEY'],'')
        review.assert_not_called()
        self.assertIs(result['compliance_review_performed'],False)

    def test_cli_uses_unchanged_arguments_and_rejection_has_nonzero_exit(self):
        stream = io.StringIO()
        with patch.object(entry,'review_submission',side_effect=self.report('rejected')), redirect_stdout(stream):
            code = entry.main(['--submission-zip',str(self.root/'input.zip'),
                '--output',str(self.output),'--run-as','shore-eval','--agent-python',sys.executable])
        self.assertEqual(code,2)
        self.evaluate.assert_not_called()
        self.assertEqual(json.loads(stream.getvalue())['state'],'compliance_rejected')

    def test_cli_cannot_disable_judge_or_insert_a_judge_backend(self):
        for flag in ('--skip-judge','--no-judge','--judge-client'):
            with self.subTest(flag=flag), patch('sys.stderr',new=io.StringIO()):
                with self.assertRaises(SystemExit) as exc:
                    entry.main(['--submission-zip',str(self.root/'input.zip'),
                        '--output',str(self.output),'--run-as','shore-eval',flag])
                self.assertEqual(exc.exception.code,2)


if __name__ == '__main__':
    unittest.main()
