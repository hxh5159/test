"""Private receipt of a self-contained agent ZIP and absolute model paths.

This module never imports submitted Python or loads a model. It freezes an
organizer-owned copy; it does not claim to isolate the later running process.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import unicodedata
import zlib
from zipfile import BadZipFile, ZipFile

PRIVATE = Path(__file__).resolve().parent
if "RIFT_PUBLIC_ROOT" in os.environ:
    PUBLIC = Path(os.environ["RIFT_PUBLIC_ROOT"]).resolve()
elif (PRIVATE / "public" / "rift").is_dir():
    PUBLIC = PRIVATE / "public"
elif (PRIVATE / "rift").is_dir():
    PUBLIC = PRIVATE
else:
    PUBLIC = PRIVATE.parent / "DiscoverPhysics"
PUBLIC = PUBLIC.resolve()
sys.path.insert(0, str(PUBLIC))

from rift.strategy import (check_strategy_files, load_model_registry,
                           load_strategy_submission)
from rift.submission import SubmissionError, _invalid_constant, _pairs

CHUNK_BYTES = 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
REQUIRED = {"agent/run.py", "agent/__init__.py", "agent/strategy.json", "models.json"}
ZIP_READ_ERRORS = (BadZipFile, NotImplementedError, RuntimeError, EOFError, zlib.error)
try:
    from lzma import LZMAError
except ImportError:
    pass  # ZIP_LZMA is already reported as unsupported by zipfile on this host.
else:
    ZIP_READ_ERRORS += (LZMAError,)


def _error(path, message):
    raise SubmissionError(path, message, "strategy_archive_invalid")


def _positive_integer(value, name):
    if type(value) is not int or value <= 0:
        raise ValueError(name + " must be a positive integer")


def _json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def _file_hash(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK_BYTES), b""):
            value.update(chunk)
    return value.hexdigest()


def _snapshot(source, target, maximum):
    """Read an immutable local snapshot after copying; do not re-open the team ZIP."""
    if source.is_symlink() or not source.is_file():
        _error("$.archive", "Supply a regular ZIP file, not a symbolic link.")
    total, value = 0, hashlib.sha256()
    descriptor = os.open(source, os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as incoming, target.open("xb") as outgoing:
        if not stat.S_ISREG(os.fstat(incoming.fileno()).st_mode):
            _error("$.archive", "Supply a regular ZIP file.")
        while True:
            chunk = incoming.read(min(CHUNK_BYTES, maximum - total + 1))
            if not chunk:
                break
            total += len(chunk)
            if total > maximum:
                _error("$.archive", "Compressed ZIP exceeds the bounded intake size.")
            value.update(chunk)
            outgoing.write(chunk)
    target.chmod(0o600)
    return value.hexdigest(), total


def _members(archive, maximum, max_members):
    entries = archive.infolist()
    if not entries or len(entries) > max_members:
        _error("$.archive", "ZIP is empty or exceeds the member count limit.")
    explicit, topology, files = set(), {}, set()
    total, checked = 0, []
    for info in entries:
        name = info.filename
        if (info.orig_filename != name or not name or not name.isprintable()
                or "\\" in name or name.startswith("/") or ":" in name
                or any(c in name for c in '<>"|?*')):
            _error("$.archive.members", "Use printable relative POSIX member names without aliases.")
        directory = info.is_dir()
        bare = name[:-1] if directory else name
        parts = bare.split("/")
        if any(not p or p in (".", "..") or p.endswith((".", " ")) for p in parts):
            _error("$.archive.members", "Dot components, empty components and path traversal are forbidden.")
        # Reject Windows device aliases as well, so an inspected archive does
        # not acquire a different meaning on another supported inspection host.
        for part in parts:
            stem = part.split(".", 1)[0].upper()
            if stem in {"CON", "PRN", "AUX", "NUL", *("COM" + str(i) for i in range(1, 10)),
                        *("LPT" + str(i) for i in range(1, 10))}:
                _error("$.archive.members", "Reserved device member names are forbidden.")
        if not ((bare == "models.json" and not directory)
                or (parts[0] == "agent" and (len(parts) > 1 or directory))):
            _error("$.archive.members", "ZIP root must contain only agent/ and models.json.")
        if info.flag_bits & 1:
            _error("$.archive.members", "Encrypted ZIP members are forbidden.")
        kind = stat.S_IFMT(info.external_attr >> 16)
        if kind not in (0, stat.S_IFREG, stat.S_IFDIR):
            _error("$.archive.members", "Symbolic links and special files are forbidden.")
        if (kind == stat.S_IFDIR and not directory) or (kind == stat.S_IFREG and directory):
            _error("$.archive.members", "ZIP directory metadata disagrees with its member name.")
        if directory and info.file_size:
            _error("$.archive.members", "Directory entries must not contain data.")
        canonical_parts = [unicodedata.normalize("NFC", p).casefold() for p in parts]
        canonical = "/".join(canonical_parts)
        if canonical in explicit:
            _error("$.archive.members", "Duplicate or case-colliding ZIP members are forbidden.")
        explicit.add(canonical)
        for index in range(1, len(parts) + 1):
            key = "/".join(canonical_parts[:index])
            spelling = "/".join(parts[:index])
            current_kind = "directory" if index < len(parts) or directory else "file"
            previous = topology.get(key)
            if previous is not None and previous != (spelling, current_kind):
                _error("$.archive.members", "Case aliases and file/directory path collisions are forbidden.")
            topology[key] = (spelling, current_kind)
        if info.file_size < 0:
            _error("$.archive.members", "Invalid member size.")
        total += info.file_size
        if total > maximum:
            _error("$.archive", "Unpacked ZIP exceeds the configured size limit.")
        if bare in ("models.json", "agent/strategy.json") and info.file_size > MAX_METADATA_BYTES:
            _error("$.archive.members", "Submission metadata exceeds its one MiB size guard.")
        if not directory:
            files.add(bare)
        checked.append((info, parts, directory))
    if not REQUIRED <= files:
        _error("$.archive.members", "Missing required files: " + ", ".join(sorted(REQUIRED - files)))
    return checked, total


def _extract(archive, members, staging, maximum):
    """Extract validated regular files ourselves, never ZipFile.extractall."""
    total = 0
    for info, parts, directory in members:
        target = staging.joinpath(*parts)
        if directory:
            with archive.open(info, "r") as incoming:
                if incoming.read(1):
                    _error("$.archive.members", "Directory entries must not contain data.")
            target.mkdir(mode=0o700, parents=True, exist_ok=True)
            continue
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        count = 0
        with archive.open(info, "r") as incoming, target.open("xb") as outgoing:
            while True:
                chunk = incoming.read(min(CHUNK_BYTES, maximum - total + 1))
                if not chunk:
                    break
                count += len(chunk)
                total += len(chunk)
                if count > info.file_size or total > maximum:
                    _error("$.archive", "Actual extracted data exceeds its declared size or limit.")
                outgoing.write(chunk)
        target.chmod(0o600)
        if count != info.file_size:
            _error("$.archive.members", "Extracted member length differs from the declared size.")
    return total


def _absolute_model_paths(models_file):
    try:
        with models_file.open(encoding="utf-8-sig") as stream:
            raw = json.load(stream, object_pairs_hook=_pairs, parse_constant=_invalid_constant)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        _error("$.models", "A readable UTF-8 model registry is required.")
    # Leave general structure and all identifier/LoRA semantics to rift. Check
    # the original spelling first because its normal loader resolves relatives.
    if isinstance(raw, dict) and isinstance(raw.get("models"), list):
        for i, model in enumerate(raw["models"]):
            if not isinstance(model, dict):
                continue
            for name in ("path", "adapter_path"):
                if name in model and (not isinstance(model[name], str)
                                      or not Path(model[name]).is_absolute()):
                    _error(f"$.models[{i}].{name}", "ZIP submissions require platform-local absolute model and adapter paths.")


def _freeze(staging):
    for path in staging.rglob("*"):
        if path.is_file():
            path.chmod(0o444)
    for path in sorted((p for p in staging.rglob("*") if p.is_dir()),
                       key=lambda p: len(p.parts), reverse=True):
        path.chmod(0o555)


def _remove_created(path, parent):
    """Clean only this call's own immediate child directory, never team paths."""
    if path.parent != parent or path == parent or path.is_symlink():
        raise RuntimeError("Refusing unexpected intake cleanup target")
    if not path.exists():
        return
    # All descendants were created by this module; no submitted code ran.
    # Make frozen directories writable first so Windows and POSIX cleanup agree.
    path.chmod(0o700)
    for entry in path.rglob("*"):
        entry.chmod(0o700 if entry.is_dir() else 0o600)
    shutil.rmtree(path)


def accept_strategy_zip(archive_path, destination, *, check_files=True,
                        max_unpacked_bytes=1024**3, max_members=10000):
    """Accept one ZIP without executing it and return its private frozen paths.

    The destination must not exist and its parent must already be an
    organizer-private directory. Model tensors remain at the declared absolute
    paths. ``check_files=False`` is structural diagnostics only, not evaluation.
    """
    _positive_integer(max_unpacked_bytes, "max_unpacked_bytes")
    _positive_integer(max_members, "max_members")
    if type(check_files) is not bool:
        raise ValueError("check_files must be bool")
    source = Path(archive_path).expanduser().absolute()
    lexical = Path(destination).expanduser().absolute()
    if lexical.exists() or lexical.is_symlink():
        raise FileExistsError("The acceptance destination must not already exist")
    parent = lexical.parent.resolve(strict=True)
    if not parent.is_dir():
        raise ValueError("Acceptance parent must be an existing directory")
    if os.name == "posix" and stat.S_IMODE(parent.stat().st_mode) & 0o077:
        raise PermissionError("Acceptance parent must be private to the organizer (mode 0700 or stricter)")
    destination = parent / lexical.name
    staging = Path(tempfile.mkdtemp(prefix=".shore-intake-", dir=parent))
    created_destination = False
    try:
        staging.chmod(0o700)
        snapshot = staging / "source.zip"
        zip_hash, zip_size = _snapshot(source, snapshot, max_unpacked_bytes + max_members * 4096 + 65536)
        try:
            with ZipFile(snapshot) as archive:
                members, unpacked_size = _members(archive, max_unpacked_bytes, max_members)
                actual_size = _extract(archive, members, staging, max_unpacked_bytes)
        except ZIP_READ_ERRORS as exc:
            _error("$.archive", "ZIP data is corrupt, encrypted or uses an unsupported compression method.")
        if actual_size != unpacked_size:
            _error("$.archive", "Total extracted size does not match its inventory.")
        _absolute_model_paths(staging / "models.json")
        registry = load_model_registry(staging / "models.json", check_files=check_files)
        (staging / "models.json").write_bytes(_json_bytes(registry))
        checked = check_strategy_files(staging / "agent")
        manifest = load_strategy_submission(staging / "agent", staging / "models.json", check_files=False)
        result = {"agent_dir": str(destination / "agent"), "models_file": str(destination / "models.json"),
                  "receipt_file": str(destination / "receipt.json"), "manifest": manifest, "registry": registry,
                  "team_id": manifest["team_id"], "submission_id": manifest["submission_id"],
                  "version": manifest["version"], "source_zip_sha256": zip_hash}
        files = [{"path": path.relative_to(staging).as_posix(), "sha256": _file_hash(path), "bytes": path.stat().st_size}
                 for path in sorted(staging.rglob("*")) if path.is_file()]
        receipt = {"schema_version": "shore-strategy-zip-intake-1.0", **result,
                   "accepted_at": datetime.now(timezone.utc).isoformat(), "source_zip_file": "source.zip",
                   "source_zip_bytes": zip_size, "archive_members": len(members), "unpacked_bytes": actual_size,
                   "strategy_file_count": len(checked["files"]), "model_files_checked": check_files,
                   "model_tensors_loaded": False, "team_code_executed": False, "model_weights_copied": False,
                   "permissions": "POSIX read-only files/private receipt directory" if os.name == "posix" else
                                  "read-only flags; production POSIX permissions require Linux verification",
                   "files": files}
        (staging / "receipt.json").write_bytes(_json_bytes(receipt))
        _freeze(staging)
        # mkdir is exclusive even on POSIX, unlike rename over an existing empty
        # directory. The receipt is transferred last to denote a complete intake.
        destination.mkdir(mode=0o700)
        created_destination = True
        destination.chmod(0o700)
        for name in ("source.zip", "agent", "models.json", "receipt.json"):
            (staging / name).rename(destination / name)
        return result
    except BaseException:
        if created_destination:
            _remove_created(destination, parent)
        raise
    finally:
        _remove_created(staging, parent)


__all__ = ["accept_strategy_zip"]
