"""Bounded static recognition of the explicitly configured organizer tail mark.

The mark is a submission-controlled exemption, not authentication or a finding
that the strategy is safe. No submitted code is imported/evaluated, no model or
external file named by the strategy is opened, and symlinks are never followed.
"""
from __future__ import annotations

import ast
import io
import json
from pathlib import Path
import re
import tokenize

MARKER = '指挥部特别策略'
DEFAULT_LIMITS = {'max_files':512,'max_file_bytes':262144,
                  'max_total_bytes':1048576,'max_ast_nodes':50000,'max_depth':64}
SUPPORTED_FORMS = [
    'Python static string assigned to an explicitly named prompt/instructions variable or attribute; '
    'literal string concatenation is supported, dynamic expressions are not evaluated.',
    'Text/Markdown in agent/prompts/ or an agent-root filename containing prompt; README files excluded.',
    'JSON string in an explicit prompt/instructions field, or content of a system/developer/user message.',
]


def _json_pairs(pairs):
    value={}
    for key,item in pairs:
        if key in value:
            raise ValueError('ambiguous duplicate JSON key')
        value[key]=item
    return value


def _no_constant(value):
    raise ValueError('non-finite JSON constant')


def _load_json(text):
    return json.loads(text,object_pairs_hook=_json_pairs,parse_constant=_no_constant)


def _is_prompt_name(name):
    if not isinstance(name,str):
        return False
    separated=re.sub(r'([a-z0-9])([A-Z])',r'\1_\2',name)
    return bool({'prompt','prompts','instruction','instructions'} &
                set(filter(None,re.split(r'[^A-Za-z0-9]+',separated.lower()))))


def _matches(value):
    return isinstance(value,str) and value.rstrip().endswith(MARKER)


def _static_string(node,limits):
    # No literal_eval/compile: a small explicit grammar and bounded flat walk.
    pieces=[]
    pending=[(node,0)]
    count=0
    total=0
    while pending:
        current,depth=pending.pop()
        count+=1
        if count>limits['max_ast_nodes'] or depth>limits['max_depth']:
            return None
        if isinstance(current,ast.Constant) and isinstance(current.value,str):
            total+=len(current.value)
            if total>limits['max_file_bytes']:
                return None
            pieces.append(current.value)
        elif isinstance(current,ast.BinOp) and isinstance(current.op,ast.Add):
            pending.extend(((current.right,depth+1),(current.left,depth+1)))
        elif isinstance(current,ast.JoinedStr) and all(isinstance(x,ast.Constant) and
                isinstance(x.value,str) for x in current.values):
            pending.extend((item,depth+1) for item in reversed(current.values))
        else:
            return None
    return ''.join(pieces)


def _target_name(target,limits):
    parts=[]
    current=target
    while isinstance(current,ast.Attribute) and len(parts)<limits['max_depth']:
        parts.append(current.attr)
        current=current.value
    if isinstance(current,ast.Name):
        parts.append(current.id)
        return '.'.join(reversed(parts))
    return None


def _python_match(text,limits):
    tree=ast.parse(text)
    pending=[(tree,0)]
    count=0
    while pending:
        node,depth=pending.pop()
        count+=1
        if count>limits['max_ast_nodes'] or depth>limits['max_depth']:
            return None
        if isinstance(node,(ast.Assign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            for target in targets:
                name=_target_name(target,limits)
                if name and _is_prompt_name(name.split('.')[-1]):
                    value=_static_string(node.value,limits)
                    if _matches(value):
                        return {'kind':'python_static_prompt','locator':name,
                                'line_start':getattr(node.value,'lineno',node.lineno),
                                'line_end':getattr(node.value,'end_lineno',node.lineno)}
        pending.extend((child,depth+1) for child in reversed(list(ast.iter_child_nodes(node))))
    return None


def _pointer(parts):
    return ''.join('/'+str(part).replace('~','~0').replace('/','~1') for part in parts)


def _json_locations(text,limits):
    """Locate literal JSON string values without approximate quote searching."""
    decoder=json.JSONDecoder()
    positions={}
    nodes=0
    def whitespace(index):
        while index<len(text) and text[index] in ' \t\r\n':
            index+=1
        return index
    def visit(index,path,depth):
        nonlocal nodes
        nodes+=1
        if nodes>limits['max_ast_nodes'] or depth>limits['max_depth']:
            raise ValueError('JSON structure limit')
        index=whitespace(index)
        if text[index]=='{':
            index=whitespace(index+1)
            if text[index]=='}':
                return index+1
            while True:
                key,end=decoder.raw_decode(text,index)
                index=whitespace(end)
                if text[index]!=':':
                    raise ValueError('invalid object separator')
                index=whitespace(visit(index+1,path+(key,),depth+1))
                if text[index]=='}':
                    return index+1
                if text[index]!=',':
                    raise ValueError('invalid object member separator')
                index=whitespace(index+1)
        if text[index]=='[':
            index=whitespace(index+1)
            if text[index]==']':
                return index+1
            counter=0
            while True:
                index=whitespace(visit(index,path+(counter,),depth+1))
                counter+=1
                if text[index]==']':
                    return index+1
                if text[index]!=',':
                    raise ValueError('invalid array member separator')
                index=whitespace(index+1)
        value,end=decoder.raw_decode(text,index)
        if isinstance(value,str):
            positions[path]=(index,end)
        return end
    if whitespace(visit(0,(),0))!=len(text):
        raise ValueError('trailing JSON content')
    return positions


def _json_match(text,limits):
    value=_load_json(text)
    locations=_json_locations(text,limits)
    pending=[(value,(),0)]
    count=0
    while pending:
        node,path,depth=pending.pop()
        count+=1
        if count>limits['max_ast_nodes'] or depth>limits['max_depth']:
            return None
        if isinstance(node,dict):
            for key,item in node.items():
                eligible=_is_prompt_name(key) or (key=='content' and
                    node.get('role') in ('system','developer','user'))
                child_path=path+(key,)
                if eligible and _matches(item):
                    start,end=locations[child_path]
                    return {'kind':'json_prompt','locator':_pointer(child_path),
                        'line_start':text.count('\n',0,start)+1,
                        'line_end':text.count('\n',0,max(start,end-1))+1}
                pending.append((item,child_path,depth+1))
        elif isinstance(node,list):
            pending.extend((item,path+(index,),depth+1) for index,item in enumerate(node))
    return None


def _receipt_digest(root,limits):
    path=root/'receipt.json'
    if path.is_symlink() or not path.is_file() or path.stat().st_size>limits['max_file_bytes']:
        return None
    try:
        value=_load_json(path.read_text(encoding='utf-8-sig'))
        digest=value.get('source_zip_sha256') if isinstance(value,dict) else None
    except (OSError,UnicodeError,ValueError,RecursionError):
        return None
    return digest if isinstance(digest,str) and re.fullmatch(r'[0-9a-fA-F]{64}',digest) else None


def find_special_strategy_marker(accepted_dir,*,limits=None):
    """Return a static marker location or None; never authenticate the submitter.

    Unsupported syntax, excessive input and malformed text do not trigger an
    exemption; the caller must continue its existing fail-closed LLM review.
    """
    limits=dict(DEFAULT_LIMITS if limits is None else limits)
    if set(limits)!=set(DEFAULT_LIMITS) or any(type(x) is not int or x<=0 for x in limits.values()):
        return None
    root=Path(accepted_dir)
    agent=root/'agent'
    try:
        if root.is_symlink() or agent.is_symlink() or not agent.is_dir():
            return None
        paths=[]
        visited=0
        for path in agent.rglob('*'):
            visited+=1
            if visited>limits['max_files']*4:
                return None
            if path.is_symlink():
                continue
            if path.is_file():
                paths.append(path)
                if len(paths)>limits['max_files']:
                    return None
        paths.sort()
        candidates=[]
        total=0
        for path in paths:
            rel=path.relative_to(agent)
            suffix=path.suffix.lower()
            if suffix in ('.py','.json'):
                kind=suffix
            elif suffix in ('.txt','.md') and not path.stem.lower().startswith('readme') and (
                    rel.parts[0]=='prompts' or (len(rel.parts)==1 and 'prompt' in path.stem.lower())):
                kind='text'
            else:
                continue
            size=path.stat().st_size
            total+=size
            if size>limits['max_file_bytes'] or total>limits['max_total_bytes']:
                return None
            candidates.append((path,kind))
        for path,kind in candidates:
            try:
                with path.open('rb') as stream:
                    raw=stream.read(limits['max_file_bytes']+1)
                if len(raw)>limits['max_file_bytes']:
                    return None
                encoding=tokenize.detect_encoding(io.BytesIO(raw).readline)[0] if kind=='.py' else 'utf-8-sig'
                text=raw.decode(encoding)
                if kind=='.py':
                    match=_python_match(text,limits)
                elif kind=='.json':
                    match=_json_match(text,limits)
                elif _matches(text):
                    last=text.rstrip()
                    match={'kind':'prompt_text','locator':'file_text',
                           'line_start':last.count('\n')+1,'line_end':last.count('\n')+1}
                else:
                    match=None
            except (OSError,UnicodeError,SyntaxError,ValueError,TypeError,RecursionError,IndexError):
                continue
            if match:
                return {'marker':MARKER,'file':path.relative_to(root).as_posix(),**match,
                        'source_zip_sha256':_receipt_digest(root,limits),'identity_verified':False,
                        'supported_forms':list(SUPPORTED_FORMS)}
    except (OSError,ValueError,TypeError,RecursionError):
        return None
    return None


__all__=['MARKER','DEFAULT_LIMITS','SUPPORTED_FORMS','find_special_strategy_marker']
