"""Accept one strategy ZIP privately, then reuse the fixed strategy evaluator.

Intake, technical check-only validation and compliance review never import or
execute submitted agent code. Formal runs require the compliance review to pass
before any scientific environment or submitted model is started.
Model weights remain at their declared local paths and are not copied into the
submission.  Only approved evaluation feedback is copied to summary.json.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path

# Import the existing entry first: it selects the shipped public/ (or flat)
# runtime before other private modules resolve any fixed public imports.
from evaluate_strategy import evaluate
from contest_job_runner import _write_private
from law_program_evaluation import OrganizerConfigurationError
from rift.submission import SubmissionError
from strategy_zip_intake import accept_strategy_zip
from submission_llm_judge import review_submission


_SCORE_FIELDS = frozenset((
    'job_id', 'team_id', 'accepted_at', 'state', 'total_score', 'world_scores',
    'schema_version', 'execution_mode', 'submission_id', 'error',
))
_CHECK_FIELDS = frozenset((
    'status', 'team_id', 'submission_id', 'model_count', 'world_count', 'model_loaded',
))

_REPORT_FILES = ('compliance_report.txt', 'compliance_report.json')
_MISSING_ENV = object()


@contextmanager
def _without_judge_credentials():
    """Do not let any evaluation child inherit the organizer judge key.

    Filtering the strategy environment alone is insufficient: candidate law
    workers can be launched elsewhere inside the evaluator. Remove this key
    for the complete evaluation phase and restore its exact original state.
    """
    original = os.environ.pop('SHORE_JUDGE_API_KEY', _MISSING_ENV)
    try:
        yield
    finally:
        if original is _MISSING_ENV:
            os.environ.pop('SHORE_JUDGE_API_KEY', None)
        else:
            os.environ['SHORE_JUDGE_API_KEY'] = original


def _review_error(root):
    """Record a non-sensitive closed gate if review fails unexpectedly."""
    report = {'status':'error', 'summary':
        'Compliance review did not complete reliably; formal evaluation was not started.',
        'findings':[]}
    _write_private(root/_REPORT_FILES[1], report)
    path = root/_REPORT_FILES[0]
    path.write_text('审查失败，未启动正式测评。请指挥部检查裁判配置、联网及审查报告。',
                    encoding='utf-8')
    path.chmod(0o600)
    return report


def _required_review(root):
    """Only a completed review with its matching reports can open the gate.

    Never propagate exception strings or raw model replies into the public
    startup response: either may contain credentials or submitted private text.
    The reviewer has no evaluator, model loader or scientific environment.
    """
    try:
        report = review_submission(root/'accepted', root)
        if not isinstance(report, dict) or report.get('status') not in (
                'passed', 'rejected', 'error', 'inconclusive'):
            return _review_error(root)
        if not isinstance(report.get('summary'), str) or not isinstance(report.get('findings'), list):
            return _review_error(root)
        txt, metadata = (root/name for name in _REPORT_FILES)
        if any(path.is_symlink() or not path.is_file() for path in (txt, metadata)):
            return _review_error(root)
        recorded = json.loads(metadata.read_text(encoding='utf-8'))
        if not isinstance(recorded, dict) or recorded.get('status') != report['status']:
            return _review_error(root)
        if report['status'] == 'passed':
            if report['findings'] or recorded.get('findings') != [] or txt.read_text(encoding='utf-8') != '不存在':
                return _review_error(root)
        return report
    except Exception:
        return _review_error(root)


def _blocked_review_summary(report):
    status = report['status']
    return {
        'state': 'compliance_rejected' if status == 'rejected' else 'compliance_review_'+status,
        'compliance_review': {'status':status,
                              'report':_REPORT_FILES[0], 'report_json':_REPORT_FILES[1]},
        'error': {'code':'submission_compliance_'+status, 'path':'$.submission',
                  'message':'Required compliance review did not pass. Formal evaluation was not started; see the organizer-private report.'},
    }


def evaluate_submission_zip(submission_zip, output, *, profile_path=None,
                            agent_python=None, run_as=None, check_only=False,
                            max_unpacked_bytes=1024**3, max_members=10000,
                            backend=None):
    """Keep accepted bytes and private evaluation under one new run directory.

    ``backend`` is solely a Python engineering-test injection point.  The CLI
    exposes no same-user or diagnostic execution mode.
    """
    root = Path(output).expanduser().absolute()
    if root.exists() or root.is_symlink():
        raise OrganizerConfigurationError('Choose a new output directory; existing runs are never overwritten')
    root.mkdir(parents=True, mode=0o700)
    root.chmod(0o700)
    accepted = accept_strategy_zip(submission_zip, root/'accepted', check_files=True,
        max_unpacked_bytes=max_unpacked_bytes, max_members=max_members)
    if not check_only:
        report = _required_review(root)
        if report['status'] != 'passed':
            summary = _blocked_review_summary(report)
            _write_private(root/'summary.json', summary)
            return summary
    with _without_judge_credentials():
        result = evaluate(accepted['agent_dir'], accepted['models_file'], root/'evaluation',
            profile_path=profile_path, agent_python=agent_python, run_as=run_as,
            check_only=check_only, backend=backend)
    fields = _CHECK_FIELDS if check_only else _SCORE_FIELDS
    summary = {key:value for key,value in result.items() if key in fields}
    if check_only:
        summary['compliance_review_performed'] = False
    _write_private(root/'summary.json', summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--submission-zip', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--run-as', required=True)
    parser.add_argument('--agent-python')
    parser.add_argument('--profile', type=Path)
    parser.add_argument('--check-only', action='store_true',
                        help='Technical ZIP/path precheck only; no compliance approval, paid LLM call or formal score.')
    parser.add_argument('--max-unpacked-bytes', type=int, default=1024**3,
                        help='Organizer intake size limit (default 1 GiB); model weights stay external.')
    parser.add_argument('--max-members', type=int, default=10000,
                        help='Organizer ZIP member limit (default 10000).')
    args = parser.parse_args(argv)
    try:
        result = evaluate_submission_zip(args.submission_zip, args.output,
            profile_path=args.profile, agent_python=args.agent_python,
            run_as=args.run_as, check_only=args.check_only,
            max_unpacked_bytes=args.max_unpacked_bytes, max_members=args.max_members)
    except (OSError, ValueError, RuntimeError) as exc:
        if isinstance(exc, SubmissionError):
            error = exc.as_dict()
        elif isinstance(exc, OrganizerConfigurationError):
            error = {'code':'organizer_configuration_error', 'path':'$', 'message':str(exc)}
        else:
            error = {'code':'startup_or_format_error', 'path':'$', 'message':
                'Check the submission ZIP, declared model paths, evaluation account and organizer profile.'}
        result = {'status':'startup_or_format_error', 'error':error}
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0 if result.get('state', 'completed') == 'completed' else 2


if __name__ == '__main__':
    raise SystemExit(main())
